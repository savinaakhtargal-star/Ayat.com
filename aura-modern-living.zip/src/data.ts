import { Product, Review } from "./types";

export const PRODUCTS: Product[] = [
  {
    id: "prod_1",
    name: "Aura Premium Heavyweight Cotton Tee",
    tagline: "Generously structured heavyweight combed cotton with absolute drape.",
    price: 210,
    rating: 4.9,
    reviewCount: 38,
    category: "Tees & Vests",
    image: "https://images.unsplash.com/photo-1521572267360-ee0c2909d518?auto=format&fit=crop&w=800&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1521572267360-ee0c2909d518?auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1583743814966-8936f5b7be1a?auto=format&fit=crop&w=800&q=80"
    ],
    description: "The Aura Heavyweight Tee sets a new standard for essential luxury wear. Crafted from dense, 280GSM organic cotton fibers, it holds a clean, sculptural silhouette without cling. Detailed with dropped shoulder frames and blind-stitched hems, this piece elevates laid-back styling into a sophisticated modernist statement.",
    details: [
      "Crafted from 280GSM dense organic long-staple combed cotton",
      "Thicker, shape-retaining ribbed mock-neck collar",
      "Modern boxy silhouette with generous dropped shoulder seams",
      "Clean blind-stitched sleeves and bottom hem detailing",
      "Pre-shrunk and silicone-washed for an incredibly soft texture"
    ],
    specifications: [
      { label: "Fabric Weight", value: "280 GSM (Heavyweight structure)" },
      { label: "Composition", value: "100% Certified Organic Cotton" },
      { label: "Fit Profile", value: "Relaxed Boxy / Contemporary" },
      { label: "Origin", value: "Sustainably woven in Portugal" },
      { label: "Care Instructions", value: "Machine wash cold, lay flat to dry" },
      { label: "Warranty", value: "1-year seamless build guarantee" }
    ],
    stock: 24,
    isPopular: true
  },
  {
    id: "prod_2",
    name: "Ora Ribbed Fitted Gengi Vest",
    tagline: "Ultra-soft cotton-bamboo double ribbing for seamless athletic contouring.",
    price: 320,
    rating: 4.8,
    reviewCount: 42,
    category: "Tees & Vests",
    image: "https://images.unsplash.com/photo-1503342217505-b0a15ec3261c?auto=format&fit=crop&w=800&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1503342217505-b0a15ec3261c?auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1618354691373-d851c5c3a990?auto=format&fit=crop&w=800&q=80"
    ],
    description: "The Ora Gengi Ribbed Vest transitions dynamically from active lounge-layering to a sharp independent silhouette. Manufactured using an exceptional blend of organic cotton and long-fiber bamboo, its 2x2 rib pattern breathes effortlessly, adapting to body shape while managing moisture flawlessly throughout warm climates.",
    details: [
      "Highly premium 2x2 double-ribbed custom knit structure",
      "Blend of organic cotton and renewable bamboo pulp fibers",
      "Sleek side seam-less finish to ensure comfortable skin contact",
      "Perfectly contoured neck and arm scoop lines",
      "Reinforced double-needle lockbinding on every edge"
    ],
    specifications: [
      { label: "Elastic Stretch", value: "Naturally active elastic stretch (zero synthetics)" },
      { label: "Material Blend", value: "65% Organic Cotton, 35% Bamboo Rayon" },
      { label: "Fabric Weight", value: "220 GSM (Light-medium premium thickness)" },
      { label: "Cut Styling", value: "Contour-fitted scoop neck lounge vest" },
      { label: "Atmosphere Control", value: "Naturally antibacterial and thermoregulating" },
      { label: "Color Treatment", value: "Non-toxic organic plant pigment" }
    ],
    stock: 35,
    isPopular: true
  },
  {
    id: "prod_3",
    name: "Aura Tailored Poplin Linen Shirt",
    tagline: "Crisp French-style architectural tailoring using organic relaxed linen yarns.",
    price: 660,
    rating: 4.9,
    reviewCount: 29,
    category: "Shirts",
    image: "https://images.unsplash.com/photo-1596755094514-f87e34085b2c?auto=format&fit=crop&w=800&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1596755094514-f87e34085b2c?auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1620012253295-c05518e993be?auto=format&fit=crop&w=800&q=80"
    ],
    description: "Merging modern geometric crispness with summer-ready breeze, the Aura Poplin Linen shirt features hidden collar support and clean concealed seams. Ideal for sharp corporate profiles or casual weekend luxury, this Belgian linen keeps you dry and perfectly styled in higher humidity environments.",
    details: [
      "Woven from grade-A flax fiber linen sustainably harvested in Belgium",
      "Semi-stiff hidden button-down collar for structured front layout",
      "Concealed front button placket for neat minimalist visual aesthetic",
      "Tailored slim-straight bottom line wearable tucked or untucked",
      "Precision lock-stitched seams running 18 stitches per inch"
    ],
    specifications: [
      { label: "Yarn Count", value: "Premium 40 lea French linen thread" },
      { label: "Material Composition", value: "100% Belgian Flax Organic Linen" },
      { label: "Button Types", value: "100% Sustainable mother of pearl buttons" },
      { label: "Cuff Design", value: "Double-button adjustable angled cuffs" },
      { label: "Moisture Absorbency", value: "Excellent moisture dissipation rating" },
      { label: "Finish Type", value: "Warm sand washed for soft finish" }
    ],
    stock: 14,
    isPopular: false
  },
  {
    id: "prod_4",
    name: "Ora Bespoke Sartorial Wool Suit",
    tagline: "Unparalleled double-breasted woolen blazers and matching slim-straight trousers.",
    price: 1200,
    rating: 5.0,
    reviewCount: 48,
    category: "Suits",
    image: "https://images.unsplash.com/photo-1594938298603-c8148c4dae35?auto=format&fit=crop&w=800&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1594938298603-c8148c4dae35?auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1593032465175-481ac7f401a0?auto=format&fit=crop&w=800&q=80"
    ],
    description: "Our signature suit represents the absolute zenith of modern evening elegance. Meticulously hand-tailored from Super 110s Australian Merino virgin wool, the blazer boasts a modern double-breasted skeleton with natural lightweight shoulder pads. A complete half-canvas lining adapts beautifully to your body posture over time, projecting an exceptionally sleek and architectural silhouette.",
    details: [
      "Tailored from Super 110s virgin Merino wool fleece",
      "Signature half-canvas internal structure providing lifetime shape retention",
      "Real textured horn buttons hand-sewn with premium cross loops",
      "Fully lined with luxury breathable anti-static Bemberg Cupro material",
      "Interior safe wallet zip-gates and smart devices storage slits"
    ],
    specifications: [
      { label: "Suit Framework", value: "Structured double-breasted coat & trouser outfit" },
      { label: "Fabric Material", value: "100% Australian Merino Virgin Wool" },
      { label: "Canvas Grade", value: "Premium horsehair and cotton half-canvas structure" },
      { label: "Lining Layer", value: "100% Premium Bemberg Cupro fiber" },
      { label: "Pocket Styling", value: "Elegant jet pockets with folding rectangular flaps" },
      { label: "Hem Finish", value: "Unfinished leg cuffs allowing customized length sewing" }
    ],
    stock: 8,
    isPopular: true
  },
  {
    id: "prod_5",
    name: "Aura Italian Cotton Classic Poplin Shirt",
    tagline: "Crease-resistant formal shirting for sharp lines and comfortable wear.",
    price: 1500,
    rating: 4.7,
    reviewCount: 30,
    category: "Shirts",
    image: "https://images.unsplash.com/photo-1620012253295-c05518e993be?auto=format&fit=crop&w=800&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1620012253295-c05518e993be?auto=format&fit=crop&w=800&q=80"
    ],
    description: "The Aura Cotton Poplin shirt is engineered for daily professional high-density wear. Spun from ultra-fine double-ply Italian combed cotton threads, it offers an exceptionally silky hand-feel while keeping neat, anti-wrinkle crisp lines throughout a demanding 12-hour corporate schedule.",
    details: [
      "100% double-ply Italian long-staple cotton",
      "Crease-resistant treatment resisting daily crumples",
      "Removable solid brass collar stays for perfect points retention",
      "Angled neat mitred barrel cuffs",
      "Subtle modern tonal stitching throughout"
    ],
    specifications: [
      { label: "Thread Count", value: "120s Double-ply combed yarns" },
      { label: "Material", value: "100% Supima Long-staple Cotton" },
      { label: "Weave Style", value: "Broadcloth Poplin weave" },
      { label: "Collar Shape", value: "Semi-spread structured collar" },
      { label: "Button Placket", value: "Minimal clean open front panels" },
      { label: "Origin", value: "Designed in Milan, stitched in Portugal" }
    ],
    stock: 22,
    isPopular: false
  },
  {
    id: "prod_6",
    name: "Ora Smart Technical Stretch Suit",
    tagline: "Laser-cut stretch tech-fabrics blended into a contemporary evening blazer set.",
    price: 550,
    rating: 4.8,
    reviewCount: 19,
    category: "Suits",
    image: "https://images.unsplash.com/photo-1507679799987-c73779587ccf?auto=format&fit=crop&w=800&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1507679799987-c73779587ccf?auto=format&fit=crop&w=800&q=80"
    ],
    description: "The Ora Technical Suit combines modern active utility with formal codes. Utilising high-density Japanese nylon and premium elastane knit structures, it yields 360-degree stretch performance. Resistant to wrinkles, water droplet splashes, and friction, this suit is built for frequent airport transits and modern active commutes.",
    details: [
      "Four-way active stretch Japanese nylon technical yarn",
      "Durable water-repelling (DWR) coating shields light rain and spots",
      "Concealed passport and boarding-pass secure zip pockets",
      "Wrinkle-free structural stretch paneling (ideal for packing)",
      "Breathable ventilated action mesh shoulder linings"
    ],
    specifications: [
      { label: "Material Blends", value: "82% Technical Nylon, 18% High-grade Spandex" },
      { label: "Suit Style", value: "Travel-optimized unstructured blazer and pants set" },
      { label: "Waterproofing", value: "Hydrophobic exterior surface finish" },
      { label: "Wash Type", value: "Easy home machine wash (gentle cycle)" },
      { label: "Weight", value: "Lightweight 1.25 lbs packable set" },
      { label: "Pocket Hardware", value: "Waterproof thin Japanese YKK zippers" }
    ],
    stock: 12,
    isPopular: true
  },
  {
    id: "prod_7",
    name: "Aura Premium Ribbed Muscle Gengi",
    tagline: "High-density organic ribbed cotton with comfortable athletic chest fit.",
    price: 450,
    rating: 4.6,
    reviewCount: 16,
    category: "Tees & Vests",
    image: "https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?auto=format&fit=crop&w=800&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?auto=format&fit=crop&w=800&q=80"
    ],
    description: "Densely ribbed for absolute shape memory retention, this athletic Gengi undershirt is designed with slightly wider shoulders and high-contour chest definitions. An exceptional lounge piece or styling layer that resists wearing thin or stretching out over repeated washes.",
    details: [
      "Thicker custom heavy-rib organic cotton yarns",
      "5% premium Spandex blends to avoid sagging/stretching",
      "Deeper back athletic curve cuts for seamless posture",
      "Specially dyed with fade-resistant rich slate black pigment",
      "Flatlock comfort seams preventing any skin irritation during active wear"
    ],
    specifications: [
      { label: "Yarn Style", value: "Heavy-duty 1x1 ribbed elastic stitch" },
      { label: "Material Composition", value: "95% Organic Combed Cotton, 5% Lycra Spandex" },
      { label: "Fabric Density", value: "240 GSM ribbed cotton weave" },
      { label: "Collar & Sleeves", value: "Deep athletic crew scooped layout" },
      { label: "Antibacterial", value: "Odor-resistant natural wash finish" },
      { label: "Body length", value: "Tuck-friendly extended body hemline" }
    ],
    stock: 45,
    isPopular: false
  },
  {
    id: "prod_8",
    name: "Ora Heavy Hooded Fleece Jacket",
    tagline: "Extremely heavy 450GSM loopback cotton with clean structured panels.",
    price: 185,
    rating: 4.8,
    reviewCount: 22,
    category: "Premium Casuals",
    image: "https://images.unsplash.com/photo-1556911220-e15b29be8c8f?auto=format&fit=crop&w=800&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1556911220-e15b29be8c8f?auto=format&fit=crop&w=800&q=80"
    ],
    description: "Built like armor against chilly nights, our heavy hooded fleece is woven from raw 450GSM organic French terry cotton. Ditching bulky drawcords and sloppy pouches, it features clean side slots and a generous double-walled hood that stays upright and structurally architectural.",
    details: [
      "Dense, ultra-heavyweight 450GSM French terry weave",
      "Double-layered structural hood holding its clean form",
      "Concealed side-seam handwarmers instead of center panel pockets",
      "Stiff-knit rib panels under the arms for premium range of movement",
      "Tailored minimal modern profile without dangling drawcords"
    ],
    specifications: [
      { label: "Fabric Substance", value: "450 GSM Loopback organic cotton" },
      { label: "Hood Spec", value: "Seamless double-walled structured fleece hood" },
      { label: "Pockets Design", value: "Invisible side-entry lined slots" },
      { label: "Ribbing", value: "Heavyweight 100% cotton spandex elastomeric cuffs" },
      { label: "Color Profile", value: "Eco-friendly low-reactivity warm oat and charcoal" },
      { label: "Thread Count", value: "Triple lock-knit durable stitching panels" }
    ],
    stock: 19,
    isPopular: false
  },
  {
    id: "prod_9",
    name: "Aura Breton Vacation Stripe Shirt",
    tagline: "Short-sleeve luxury modal striped shirt with comfortable camp collar.",
    price: 125,
    rating: 4.9,
    reviewCount: 15,
    category: "Shirts",
    image: "https://images.unsplash.com/photo-1602810318383-e386cc2a3ccf?auto=format&fit=crop&w=800&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1602810318383-e386cc2a3ccf?auto=format&fit=crop&w=800&q=80"
    ],
    description: "Taking cues from mid-century coastal holiday silhouettes, the Aura vacation shirt blends organic silk and premium Tencel Modal. Highly cooling to the touch, and featuring an elegant camp collar with real wood corozo buttons, it's the ultimate warm-weather weekend statement.",
    details: [
      "Highly cooling luxury blend of 70% Tencel Modal and 30% Mulberry Silk",
      "Laid-back open camp collar styling",
      "Sustainable premium corozo nut custom buttons",
      "Neat split outer side seam bottoms allowing loose drape",
      "Highly breathable and naturally fluid fabric motion"
    ],
    specifications: [
      { label: "Material", value: "70% Eco-Tencel Modal, 30% Pure Mulberry Silk" },
      { label: "Collar Type", value: "Camp / Cuban open collar format" },
      { label: "Button Materials", value: "Sustainable organic vegetable ivory / Corozo" },
      { label: "Weave Pattern", value: "Fluid matte-finished jersey stripe" },
      { label: "Wash Instructions", value: "Dry clean prioritized OR delicate hand-wash" },
      { label: "Origin", value: "Handwoven in Florence, Italy" }
    ],
    stock: 15,
    isPopular: true
  },
  {
    id: "prod_10",
    name: "Ora Peak-Lapel Woolen Suit Overcoat",
    tagline: "Magnificent double-breasted clean longcoat in dense Italian wool.",
    price: 690,
    rating: 4.8,
    reviewCount: 18,
    category: "Suits",
    image: "https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=crop&w=800&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=crop&w=800&q=80"
    ],
    description: "The peak of sartorial outerwear lines. Carefully crafted from 680GSM thick Italian Melton wool panels, this structured long overcoat has sharp padded shoulders, wide dramatic peak lapels, and double-breasted horn closures. Designed to fit comfortably and coordinate beautifully over complete tailored suit layers.",
    details: [
      "Thick premium 680GSM winter-proof Italian Melton wool",
      "Sharp structured shoulders with timeless bespoke peak lapels",
      "High-grade hand-carved buffalo horn buttons",
      "Twin vertical interior chest security pocket gates",
      "Deep slate charcoal tone coordinating with diverse wardrobes"
    ],
    specifications: [
      { label: "Coat Thickness", value: "680 GSM (Heavy winter wool fabric)" },
      { label: "Material Blend", value: "90% Virgin Australian Wool, 10% Soft Cashmere" },
      { label: "Lining Layer", value: "Full satin-feel anti-friction Cupro layout" },
      { label: "Lapel Width", value: "4.2\" classic proportion peak lapel" },
      { label: "Pocket Layout", value: "Dual flap waist pockets, one sleek chest bar slot" },
      { label: "Back Vent", value: "Deep single-vent with reinforcing flap folds" }
    ],
    stock: 10,
    isPopular: true
  },
  {
    id: "prod_11",
    name: "Ora Supima Soft Comfort Crewneck",
    tagline: "Silky long-staple Supima under-layers with seamless crew contours.",
    price: 48,
    rating: 5.0,
    reviewCount: 11,
    category: "Tees & Vests",
    image: "https://images.unsplash.com/photo-1523381210434-271e8be1f52b?auto=format&fit=crop&w=800&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1523381210434-271e8be1f52b?auto=format&fit=crop&w=800&q=80"
    ],
    description: "Supple, feather-light, and engineered with absolute seamless back seams, the Supima Cotton Crewneck is the perfect foundation layer under suits or structured shirts. Offering dynamic heat regulation and an incredibly silky touch against the skin.",
    details: [
      "100% Premium certified long-staple USA Supima cotton",
      "Interlock knit pattern keeps structure even after 100 washes",
      "Friction-less printed clothing tag details inside neck",
      "Fitted sleeves displaying refined muscle curves",
      "Breathable lightweight build wearable year-round"
    ],
    specifications: [
      { label: "Cotton Grade", value: "USA-Certified Long-staple Supima Cotton" },
      { label: "Yarn Count", value: "80s Superfine single interlock yarns" },
      { label: "Weave Density", value: "160 GSM lightweight layers" },
      { label: "Neck Trim", value: "Ultra-thin seamless bound trim" },
      { label: "Fading Rate", value: "Guaranteed high dye penetration index" },
      { label: "Shrinkage", value: "Pre-washed for <0.5% maximum dimensional shift" }
    ],
    stock: 50,
    isPopular: false
  },
  {
    id: "prod_12",
    name: "Aura Premium Organic Cotton Hooded Jacket",
    tagline: "Relaxed-fit zip jackets for effortless streetwear comfort.",
    price: 195,
    rating: 4.7,
    reviewCount: 31,
    category: "Premium Casuals",
    image: "https://images.unsplash.com/photo-1556821840-3a63f95609a7?auto=format&fit=crop&w=800&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1556821840-3a63f95609a7?auto=format&fit=crop&w=800&q=80"
    ],
    description: "Relaxed, functional, and beautiful. Built directly using heavyweight organic Turkish fleece cotton, it boasts a custom silver double-zipper with heavy-duty metal sliders. Fully lined, warm, and highly versatile as quick streetwear layers.",
    details: [
      "Made from organic Turkish double-loop cotton fleece",
      "Bespoke matte-silver double zipper handles for varied layouts",
      "Slightly elastic waistband and cuffs with active spandex",
      "Hand-warming kangaroo pockets with secure inner phone chambers",
      "Reinforced hood structure that holds clean curves"
    ],
    specifications: [
      { label: "Fleece Thickness", value: "380 GSM medium-heavy weight" },
      { label: "Material Composition", value: "100% GOTS-Certified Turkish Organic Cotton" },
      { label: "Zipper Grade", value: "Premium YKK heavy metal double sliders" },
      { label: "Sizing Frame", value: "Comfortably relaxed / unisex sizing profiles" },
      { label: "Hood Detailing", value: "Clean seam lining with no drawcords" },
      { label: "Durable Threading", value: "Heavy-gauge reinforced flatlock sewing lines" }
    ],
    stock: 25,
    isPopular: false
  },
  {
    id: "prod_13",
    name: "Aura Cashmere Cable-Knit Crewneck",
    tagline: "Unbelievably soft grade-A Mongolian cashmere with structured heritage cable braids.",
    price: 320,
    rating: 4.9,
    reviewCount: 14,
    category: "Premium Casuals",
    image: "https://images.unsplash.com/photo-1620799140408-edc6dcb6d633?auto=format&fit=crop&w=800&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1620799140408-edc6dcb6d633?auto=format&fit=crop&w=800&q=80"
    ],
    description: "Our Cashmere Cable-Knit Crewneck is the ultimate statement of cold-weather luxury. Exclusively crafted of 100% long-staple grade-A cashmere fibers gathered from certified pasture farms in Inner Mongolia, this sweater combines the exquisite softness of organic cashmere with the architectural solidity of traditional fisherman knit patterns. Exceptionally lightweight yet delivering three times the warming insulation of sheep woolen garments.",
    details: [
      "Knit using 100% certified organic grade-A long-staple cashmere fibers",
      "Traditional fisherman heritage cable-knit layout with modern relaxed proportions",
      "Dense, double-ply yarn weave avoiding early pilling or shedding",
      "Hand-linked seamless sleeves and shoulder joins for fluid neck contours",
      "Perfectly balanced ribbed cuffs and wide bottom waistbands"
    ],
    specifications: [
      { label: "Material Composition", value: "100% Certified Mongolian Cashmere" },
      { label: "Yarn Density", value: "12-Gauge double-ply luxury construct" },
      { label: "Fabric Weight", value: "320g (Lightweight yet heavy thermal rating)" },
      { label: "Fit Profile", value: "Straight-relaxed silhouette" },
      { label: "Care Instructions", value: "Delicate hand wash cold or professional dry clean ONLY" },
      { label: "Sourcing Profile", value: "GOTS-certified sustainable and humane animal farms" }
    ],
    stock: 18,
    isPopular: true
  },
  {
    id: "prod_14",
    name: "Ora Tailored Pleated Woolen Trousers",
    tagline: "Exquisite double-pleated Italian wool trousers with continuous straight-drape leg lines.",
    price: 210,
    rating: 4.8,
    reviewCount: 20,
    category: "Suits",
    image: "https://images.unsplash.com/photo-1594633312681-425c7b97ccd1?auto=format&fit=crop&w=800&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1594633312681-425c7b97ccd1?auto=format&fit=crop&w=800&q=80"
    ],
    description: "The Ora Double-Pleated Trousers redefine formal and relaxed tailored guidelines. Constructed from fine Italian worsted cool wool, they present an elegant high-waisted rise with structured double pleats that create a beautiful, geometric straight-line fold down the leg. Detailed with an adjustable side waistcoat clasp and a clean watch pocket.",
    details: [
      "Custom woven Italian worsted cool wool (suitable for multi-season comfort)",
      "Traditional high-waisted fit with sophisticated front double-pleat structure",
      "Adjustable metal buckle side-tabs replacing heavy belt loops for minimalist waist finishes",
      "Internal linen button fly with formal dual hook-and-bar closures",
      "Ample 2.5-inch hidden bottom cuffs allowing flexible tailoring extensions"
    ],
    specifications: [
      { label: "Fabric Material", value: "100% Italian Worsted Virgin Wool" },
      { label: "Pocket Layout", value: "Dual deep slant side pockets, one flush front coin-gate, two rear button-closed vents" },
      { label: "Inner Finish", value: "Half-lined with soft organic viscose to the knee to avoid wool itch" },
      { label: "Fit Profile", value: "Classic Straight Leg with elegant drape" },
      { label: "Origin", value: "Tailored in Naples, Italy" },
      { label: "Crease Performance", value: "Excellent resilient fiber memory (resists creasing)" }
    ],
    stock: 15,
    isPopular: true
  },
  {
    id: "prod_15",
    name: "Aura Silk-Linen Trench Duster",
    tagline: "Lightweight and flowy silk-linen duster jacket for fluid layered silhouettes.",
    price: 460,
    rating: 5.0,
    reviewCount: 16,
    category: "Premium Casuals",
    image: "https://images.unsplash.com/photo-1591047139829-d91aecb6caea?auto=format&fit=crop&w=800&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1591047139829-d91aecb6caea?auto=format&fit=crop&w=800&q=80"
    ],
    description: "Conceived for perfect modern layering transitions. The Trench Duster is woven from a luxury blend of long-fiber Belgian flax linen and soft organic mulberry silk. The inclusion of silk infuses a subtle, premium luster and soft, fluid bounce into the fabric, completely neutralizing the hard stiffness of raw linen. Features generous front patch pockets and a flexible tie belt.",
    details: [
      "Unique weave blend of 65% French Linen and 35% Organic Mulberry Silk",
      "Unstructured, lightweight design offering a dramatic, fluid wind-drape movement",
      "Deep dropped-shoulder sleeves easy to roll up or layer over knitwear",
      "Sleek notch lapels and optional double-face matching fabric wrap-belt",
      "Sartorial French seams throughout the inner panels to avoid fraying"
    ],
    specifications: [
      { label: "Material Composition", value: "65% French Flax Linen, 35% Mulberry Silk" },
      { label: "Coating", value: "Uncoated (natural breathability focus)" },
      { label: "Fabric Weight", value: "185 GSM (Fetherweight fluid outerwear)" },
      { label: "Belt Design", value: "Self-tie closure strap with invisible side belt loops" },
      { label: "Pockets", value: "Extremely spacious front patch utility pockets" },
      { label: "Length", value: "Full-length duster (falls below calf plane)" }
    ],
    stock: 12,
    isPopular: false
  }
];

export const REVIEWS: { [productId: string]: Review[] } = {
  prod_1: [
    {
      id: "rev_1",
      userName: "Alexander S.",
      rating: 5,
      date: "May 12, 2026",
      comment: "Absolutely changed my daily essentials. The heavy 280GSM cotton holds a beautifully crisp boxy frame and hasn't shrunk a single bit. Simply unmatched."
    },
    {
      id: "rev_2",
      userName: "Elena R.",
      rating: 5,
      date: "Apr 28, 2026",
      comment: "Incredibly thick and luxurious. The mock-neck collar has amazing tension and stays neat and sharp under my casual blazers."
    },
    {
      id: "rev_3",
      userName: "Marcus K.",
      rating: 4,
      date: "Mar 15, 2026",
      comment: "Very premium heavyweight feel. I only wish they had earthy beige colors, but the black and slate are exceptionally classy."
    }
  ],
  prod_2: [
    {
      id: "rev_4",
      userName: "Sophia Thorne",
      rating: 5,
      date: "May 25, 2026",
      comment: "The double ribbed bamboo cotton is incredibly soft and behaves beautifully. Perfect fit, outstanding length so it never rides up!"
    },
    {
      id: "rev_5",
      userName: "Daniel Chen",
      rating: 4,
      date: "May 02, 2026",
      comment: "Extremely breathable Gengi. Great under suits during humid days. Keeps you cool and dries fast."
    }
  ],
  prod_3: [
    {
      id: "rev_6",
      userName: "Beatrice V.",
      rating: 5,
      date: "Jun 01, 2026",
      comment: "The Belgian linen feels like a premium breeze. Very crisp hidden collar stay keeps me looking extremely neat during humid meetings. Highly recommended!"
    }
  ],
  prod_4: [
    {
      id: "rev_7",
      userName: "Jonathan F.",
      rating: 5,
      date: "May 19, 2026",
      comment: "An absolute masterclass in tailoring. The Australian Merino wool has an gorgeous natural drape. Double-breasted look feels very sharp and contemporary."
    }
  ]
};

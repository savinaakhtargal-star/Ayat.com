import { useState, useEffect } from "react";
import { Product, CartItem } from "./types";
import { PRODUCTS } from "./data";
import { useLocalization } from "./context/LocalizationContext";
import { ProductCard } from "./components/ProductCard";
import { ProductDetails } from "./components/ProductDetails";
import { CartDrawer } from "./components/CartDrawer";
import { FavoritesDrawer } from "./components/FavoritesDrawer";
import { CheckoutModal } from "./components/CheckoutModal";
import { ToastContainer, ToastMessage } from "./components/Toast";
import { SocialHub } from "./components/SocialHub";
import { StaffDeskModal } from "./components/StaffDeskModal";
import {
  ShoppingBag,
  Heart,
  Search,
  SlidersHorizontal,
  ChevronDown,
  ArrowRight,
  Info,
  Sparkles,
  MessageSquare,
  Facebook,
  ShieldCheck,
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

export default function App() {
  const { language, setLanguage, currency, setCurrency, formatPrice, t } = useLocalization();

  // Global States
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [isDetailOpen, setIsDetailOpen] = useState(false);
  
  const [cart, setCart] = useState<CartItem[]>(() => {
    const saved = localStorage.getItem("aura_cart");
    return saved ? JSON.parse(saved) : [];
  });
  const [isCartOpen, setIsCartOpen] = useState(false);

  const [favorites, setFavorites] = useState<Product[]>(() => {
    const saved = localStorage.getItem("aura_favorites");
    return saved ? JSON.parse(saved) : [];
  });
  const [isFavoritesOpen, setIsFavoritesOpen] = useState(false);

  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [isStaffOpen, setIsStaffOpen] = useState(false);

  // Search, Filter, Sort
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string>("All");
  const [sortBy, setSortBy] = useState<string>("popular");

  // Toasts
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  // Local storage syncing
  useEffect(() => {
    localStorage.setItem("aura_cart", JSON.stringify(cart));
  }, [cart]);

  useEffect(() => {
    localStorage.setItem("aura_favorites", JSON.stringify(favorites));
  }, [favorites]);

  // Toast helper
  const addToast = (text: string, type: "success" | "info" | "heart" = "success") => {
    const newToast: ToastMessage = {
      id: Math.random().toString(),
      text,
      type,
    };
    setToasts((prev) => [...prev, newToast]);
  };

  const removeToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  // Add Item
  const handleAddToCart = (product: Product, quantity: number = 1) => {
    setCart((prev) => {
      const existing = prev.find((item) => item.product.id === product.id);
      if (existing) {
        // limit quantity depending on stock limit
        const updatedQty = Math.min(existing.quantity + quantity, product.stock);
        if (updatedQty === existing.quantity) {
          addToast(`Maximum stock of ${product.name} reached`, "info");
        }
        return prev.map((item) =>
          item.product.id === product.id ? { ...item, quantity: updatedQty } : item
        );
      }
      return [...prev, { product, quantity }];
    });
    // Auto-open Cart Drawer so they can directly see the quantity and stepper numbers
    setIsCartOpen(true);
    // Closely close detail drawer if it was open
    setIsDetailOpen(false);
  };

  // Update Cart quantities
  const handleUpdateCartQuantity = (productId: string, quantity: number) => {
    if (quantity <= 0) {
      handleRemoveCartItem(productId);
      return;
    }
    const prod = PRODUCTS.find((p) => p.id === productId);
    if (prod && quantity > prod.stock) {
      addToast(`Only ${prod.stock} items of this stock are available`, "info");
      return;
    }
    setCart((prev) =>
      prev.map((item) =>
        item.product.id === productId ? { ...item, quantity } : item
      )
    );
  };

  // Remove Item
  const handleRemoveCartItem = (productId: string) => {
    const item = cart.find((i) => i.product.id === productId);
    setCart((prev) => prev.filter((i) => i.product.id !== productId));
    if (item) {
      addToast(`Removed ${item.product.name} from bag`, "info");
    }
  };

  // Save Bookmarks
  const handleToggleFavorite = (product: Product) => {
    const exists = favorites.find((f) => f.id === product.id);
    if (exists) {
      setFavorites((prev) => prev.filter((f) => f.id !== product.id));
      addToast(`Removed ${product.name} from savings`, "info");
    } else {
      setFavorites((prev) => [...prev, product]);
      addToast(`Saved ${product.name} to Collection`, "heart");
    }
  };

  const handleOrderSuccess = (createdOrder?: any) => {
    if (createdOrder) {
      const stored = localStorage.getItem("aura_orders");
      const currentOrders = stored ? JSON.parse(stored) : [];
      localStorage.setItem("aura_orders", JSON.stringify([...currentOrders, createdOrder]));
      addToast(`Order placed successfully! Checked under ID: ${createdOrder.id}`, "success");
    } else {
      addToast("Order placed successfully!", "success");
    }
    setCart([]);
  };

  // Detail Drawer display helper
  const handleViewDetails = (product: Product) => {
    setSelectedProduct(product);
    setIsDetailOpen(true);
  };

  const cartTotalQty = cart.reduce((acc, item) => acc + item.quantity, 0);

  // Filters logic
  const filteredProducts = PRODUCTS.filter((prod) => {
    const matchesCategory =
      selectedCategory === "All" || prod.category === selectedCategory;
    const matchesSearch =
      prod.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      prod.tagline.toLowerCase().includes(searchTerm.toLowerCase()) ||
      prod.description.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesCategory && matchesSearch;
  }).sort((a, b) => {
    if (sortBy === "price-low") return a.price - b.price;
    if (sortBy === "price-high") return b.price - a.price;
    if (sortBy === "rating") return b.rating - a.rating;
    return a.isPopular ? -1 : 1; // Default popular sort
  });

  // Categories
  const categories = ["All", "Suits", "Shirts", "Tees & Vests", "Premium Casuals"];

  return (
    <div id="app-root-container" className="min-h-screen bg-slate-50 font-sans text-slate-800 antialiased selection:bg-indigo-600 selection:text-white">
      {/* Top Banner Notice */}
      <div className="bg-slate-900 text-white text-[10.5px] sm:text-xs font-semibold py-2.5 px-4 text-center select-none uppercase tracking-widest flex flex-col md:flex-row items-center justify-center gap-1.5 border-b border-indigo-500/20 animate-fade-in">
        <div className="flex items-center gap-1.5">
          <Sparkles className="h-3.5 w-3.5 text-amber-400 shrink-0" />
          <span>{t("banner.freeShipping")}</span>
        </div>
        <span className="hidden md:inline text-slate-400">|</span>
        <span className="text-[9px] text-slate-400 normal-case">{t("banner.sub")}</span>
      </div>

      {/* Primary Header */}
      <header className="sticky top-0 z-40 bg-slate-50/80 backdrop-blur-md border-b border-slate-200 px-4 sm:px-8 py-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          {/* Brand Logo design */}
          <span className="text-sm font-black tracking-widest uppercase text-slate-900 select-none">
            EMR <span className="text-indigo-600">//</span> Studio
          </span>

          {/* Localization switcher console */}
          <div className="flex items-center gap-1.5 border-l border-slate-200 pl-3">
            {/* Language Switch */}
            <div className="flex bg-slate-100 rounded-md p-0.5 border border-slate-200/60">
              <button
                id="lang-btn-en"
                onClick={() => setLanguage("en")}
                className={`px-1.5 py-0.5 text-[9px] font-black rounded-xs transition-all ${
                  language === "en" ? "bg-white text-indigo-600 shadow-xs" : "text-slate-500 hover:text-slate-900 cursor-pointer"
                }`}
              >
                EN
              </button>
              <button
                id="lang-btn-bn"
                onClick={() => setLanguage("bn")}
                className={`px-1.5 py-0.5 text-[9px] font-black rounded-xs transition-all ${
                  language === "bn" ? "bg-white text-indigo-600 shadow-xs" : "text-slate-500 hover:text-slate-900 cursor-pointer"
                }`}
              >
                বাংলা
              </button>
            </div>

            {/* Currency Selector */}
            <div className="relative">
              <select
                id="currency-header-select"
                value={currency}
                onChange={(e) => setCurrency(e.target.value as any)}
                className="appearance-none bg-white border border-slate-200 rounded-md pl-1.5 pr-4.5 py-0.5 text-[9px] font-extrabold text-slate-750 hover:border-slate-300 focus:outline-hidden cursor-pointer"
              >
                <option value="USD">USD ($)</option>
                <option value="BDT">BDT (৳)</option>
                <option value="EUR">EUR (€)</option>
                <option value="GBP">GBP (£)</option>
              </select>
              <ChevronDown className="absolute right-0.5 top-1/2 -translate-y-1/2 h-2.5 w-2.5 text-slate-400 pointer-events-none" />
            </div>
          </div>
        </div>

        {/* Action Widgets */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Staff desk toggle button */}
          <button
            id="nav-staff-btn"
            onClick={() => setIsStaffOpen(true)}
            className="flex h-10 px-3.5 items-center justify-center gap-1.5 rounded-full border border-slate-900 bg-slate-900 text-white text-[10px] sm:text-xs font-black uppercase tracking-widest shadow-md hover:bg-slate-800 hover:border-slate-800 transition-all cursor-pointer shrink-0"
          >
            <ShieldCheck className="h-4 w-4 text-indigo-400 shrink-0" />
            <span>{t("staff.desk")}</span>
          </button>

          {/* Wishlists toggle button */}
          <button
            id="nav-favs-btn"
            onClick={() => setIsFavoritesOpen(true)}
            className="flex h-10 w-10 items-center justify-center rounded-full border border-slate-200 bg-white text-slate-600 shadow-xs hover:border-slate-300 hover:text-indigo-600 transition-all relative cursor-pointer"
          >
            <Heart className="h-4.5 w-4.5" />
            {favorites.length > 0 && (
              <span className="absolute -top-1 -right-1 flex h-4.5 w-4.5 items-center justify-center rounded-full bg-rose-500 text-[10px] font-black text-white ring-2 ring-white">
                {favorites.length}
              </span>
            )}
          </button>

          {/* Cart toggle button */}
          <button
            id="nav-cart-btn"
            onClick={() => setIsCartOpen(true)}
            className="flex h-10 px-4 items-center justify-center gap-2 rounded-full border border-slate-200 bg-indigo-600 text-white shadow-md hover:bg-indigo-700 transition-all relative shrink-0 cursor-pointer"
          >
            <ShoppingBag className="h-4.5 w-4.5" />
            <span className="text-xs font-bold tracking-wider uppercase hidden sm:inline">
              Bag
            </span>
            {cartTotalQty > 0 && (
              <span className="flex h-5 items-center justify-center px-1.5 rounded-full bg-white text-[10px] font-black text-indigo-600 ring-1 ring-indigo-600 ml-0.5">
                {cartTotalQty}
              </span>
            )}
          </button>
        </div>
      </header>

      {/* Prominent Direct Ordering Banner */}
      <div className="bg-emerald-50/90 backdrop-blur-xs border-b border-emerald-100 px-4 sm:px-8 py-3 text-center sm:text-left transition-all animate-fade-in select-none">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-3 text-emerald-955">
          <div className="flex flex-col sm:flex-row items-center gap-2 font-mono">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-505 bg-emerald-500"></span>
            </span>
            <div className="text-center sm:text-left">
              <span className="text-xs font-black uppercase tracking-wider text-emerald-900 block sm:inline-block sm:mr-2">
                সরাসরি অর্ডার করতে চান?
              </span>
              <span className="text-[10px] text-emerald-700 uppercase tracking-widest font-semibold border-t sm:border-t-0 sm:border-l border-emerald-300 pt-0.5 sm:pt-0 sm:pl-2.5 mt-0.5 sm:mt-0 block sm:inline-block">
                Want to place order directly?
              </span>
            </div>
          </div>
          <div className="flex items-center flex-wrap justify-center gap-2">
            <a
              id="header-order-whatsapp-btn"
              href="https://wa.me/8801871731341?text=Hello!%20I%20am%20interested%20in%20ordering%20from%20your%20store."
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 rounded-lg bg-emerald-600 px-3.5 py-1.5 text-[10px] font-black uppercase tracking-widest text-white shadow-xs hover:bg-emerald-700 transition-colors cursor-pointer"
            >
              <MessageSquare className="h-3.5 w-3.5" />
              WhatsApp: 01871731341
            </a>
            <a
              id="header-order-facebook-btn"
              href="https://www.facebook.com/itzashiqvai999"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 rounded-lg bg-blue-600 px-3.5 py-1.5 text-[10px] font-black uppercase tracking-widest text-white shadow-xs hover:bg-blue-700 transition-colors cursor-pointer"
            >
              <Facebook className="h-3.5 w-3.5" />
              Facebook Profile
            </a>
          </div>
        </div>
      </div>

      {/* Main Container */}
      <main className="max-w-7xl mx-auto px-4 sm:px-8 py-8 space-y-12">
        {/* Editorial Hero Highlight using generated scene */}
        <section className="relative overflow-hidden rounded-2xl border border-slate-200 bg-slate-900 shadow-xl">
          {/* Background image render with referrer policy */}
          <div className="absolute inset-0 z-0 opacity-45">
            <img
              src="https://images.unsplash.com/photo-1441986300917-64674bd600d8?auto=format&fit=crop&w=1600&q=80"
              alt="AURA Premium Wardrobe Exhibition"
              className="h-full w-full object-cover select-none pointer-events-none filter brightness-90"
              referrerPolicy="no-referrer"
            />
          </div>

          <div className="absolute inset-0 bg-gradient-to-r from-slate-950 via-slate-950/70 to-transparent z-1 pointer-events-none" />

          {/* Hero text */}
          <div className="relative z-10 max-w-lg p-8 sm:p-12 md:py-16 space-y-5 text-white">
            <span className="inline-block rounded-full bg-slate-800/80 px-3 py-1 text-[10px] font-bold tracking-widest text-indigo-305 uppercase">
              Now Available // Edition 04
            </span>
            <h1 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-white leading-tight">
              {language === "en" ? "Sartorial elegance meets structural comfort." : "অসাধারণ পোশাক শৈলী ও নিখুঁত আরামের অপূর্ব মিলন।"}
            </h1>
            <p className="text-xs sm:text-sm text-slate-350 leading-relaxed max-w-sm">
              {language === "en" 
                ? "Discover meticulously tailored suits, premium poplin shirts, combed rib Gengi tees, and luxurious lounge garments designed with architectural precision."
                : "আমাদের নিজস্ব কারিগরি ডিজাইনে তৈরি ব্লেজার স্যুট, প্রিমিয়াম সুতি কাপড়, উন্নত কম্বড রিঙ্গড গেঞ্জি এবং ঐতিহ্যবাহী সব পোশাকের চমৎকার সমাহার।"
              }
            </p>
            <div className="pt-2">
              <a
                href="#collection-grid"
                className="inline-flex items-center gap-2 rounded-lg bg-indigo-600 px-5 py-3 text-xs font-black uppercase tracking-wider text-white shadow-lg hover:bg-indigo-700 transition-colors"
              >
                {t("hero.cta")}
                <ArrowRight className="h-4 w-4" />
              </a>
            </div>
          </div>
        </section>

        {/* Delivery & Store Pickup Service Announcement */}
        <section className="bg-slate-50 border border-slate-200/80 rounded-2xl p-6 sm:p-8 grid grid-cols-1 md:grid-cols-2 gap-6 items-center">
          <div className="space-y-3">
            <span className="inline-flex items-center gap-1.5 rounded-full bg-indigo-100 px-3 py-1 text-[10px] font-bold text-indigo-700 uppercase tracking-wider">
              <Sparkles className="h-3 w-3 text-indigo-600 shrink-0" />
              EMR Clothing Service Facilities // আমাদের সেবাসমূহ
            </span>
            <h3 className="text-lg font-black text-slate-900 tracking-tight leading-tight">
              আমাদের পোশাক ক্রয়ের ও ডেলিভারির বিশেষ সুবিধাসমূহ
            </h3>
            <p className="text-xs text-slate-500 leading-relaxed font-normal">
              EMR Clothing কাস্টমারদের সর্বোচ্চ সন্তুষ্টি নিশ্চিত করতে আমরা দুটি বিশেষ সুবিধাজনক পদ্ধতিতে অর্ডার সরবরাহ করে থাকি। নিচে বিস্তারিত দেখে নিন:
            </p>
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Facility 1: In-store Pickup */}
            <div className="bg-white border border-slate-150 p-4.5 rounded-xl space-y-2 flex flex-col justify-between">
              <div className="space-y-1.5 grayscale-0">
                <span className="inline-block text-[9px] font-black uppercase tracking-widest text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded">
                  ১ম সুবিধা // নিজে এসে নিয়ে যাওয়া
                </span>
                <h4 className="text-xs font-bold text-slate-905">দোকানে দেখে যাচাই-বাছাইয়ের সুবিধা</h4>
                <p className="text-[11px] text-slate-500 leading-relaxed font-normal">
                  আমাদের দোকানে সরাসরি এসে কাপড় নিজ চোখে দেখে, নিখুঁতভাবে কাপড়ের মান, কুয়ালিটি ও ফিটিং যাচাই-বাছাই করে সন্তুষ্ট হয়ে নিজে নিয়ে যেতে পারবেন।
                </p>
              </div>
              <span className="text-[10px] text-indigo-600 font-extrabold flex items-center gap-1 pt-1">
                Verified Quality • দোকান থেকে সংগ্রহ
              </span>
            </div>

            {/* Facility 2: Delivery */}
            <div className="bg-white border border-slate-150 p-4.5 rounded-xl space-y-2 flex flex-col justify-between">
              <div className="space-y-1.5">
                <span className="inline-block text-[9px] font-black uppercase tracking-widest text-amber-700 bg-amber-50 px-2 py-0.5 rounded">
                  ২য় সুবিধা // ডেলিভারি রাইডার
                </span>
                <h4 className="text-xs font-bold text-slate-905">ডেলিভারির লোকের ব্যবস্থা</h4>
                <p className="text-[11px] text-slate-500 leading-relaxed font-normal">
                  যদি ডেলিভারি দেওয়ার মতো উপযুক্ত লোক বা রাইডারের ব্যবস্থা করা সম্ভব হয়, তবে আমরা সর্বোচ্চ চেষ্টা করে আপনার ঠিকানায় হোম ডেলিভারি দেওয়ার ব্যবস্থা রাখবো।
                </p>
              </div>
              <span className="text-[10px] text-amber-700 font-extrabold flex items-center gap-1 pt-1">
                Reliable Effort • হোম ডেলিভারি ট্রাই
              </span>
            </div>
          </div>
        </section>

        {/* Catalog Feed Filter Panel Header */}
        <section id="collection-grid" className="scroll-mt-24 space-y-8">
          <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-6 border-b border-slate-200 pb-6">
            <div className="space-y-1.5">
              <h2 className="text-xl font-bold text-slate-900 tracking-tight uppercase">
                {language === "en" ? "The Sartorial Archive" : "সেরা পোশাক স্টোর কালেকশন"}
              </h2>
              <p className="text-xs text-slate-500 max-w-md">
                {language === "en" 
                  ? "Carefully tailored garments emphasizing clean lines, high-density organic textiles, and ultimate structural form."
                  : "আধুনিক ডিজাইন শৈলী ও শতভাগ আরামদায়ক উন্নত সুতি ফাইবারে বোনা চমৎকার নিখুঁত মানের সব পোশাকের সংগ্রহ।"
                }
              </p>
            </div>

            {/* Live Search and Sort Filters */}
            <div className="flex flex-wrap items-center gap-3">
              {/* Search Widget */}
              <div className="relative w-full sm:w-60">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
                <input
                  id="search-input"
                  type="text"
                  placeholder={t("search.placeholder")}
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full rounded-md border border-slate-200 bg-white pl-9 pr-4 py-2 text-xs font-semibold text-slate-805 shadow-2xs focus:border-indigo-600 focus:outline-hidden"
                />
              </div>

              {/* Sort Selector Dropdown */}
              <div className="relative flex items-center rounded-md border border-slate-200 bg-white px-3.5 py-2 shadow-2xs">
                <SlidersHorizontal className="h-3.5 w-3.5 text-slate-400 mr-2 shrink-0" />
                <select
                  id="sort-select"
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value)}
                  className="text-xs font-bold text-slate-700 bg-transparent tracking-wide appearance-none pr-6 cursor-pointer focus:outline-hidden"
                >
                  <option value="popular">{t("filter.popular")}</option>
                  <option value="price-low">{t("filter.priceLow")}</option>
                  <option value="price-high">{t("filter.priceHigh")}</option>
                  <option value="rating">{t("filter.rating")}</option>
                </select>
                <ChevronDown className="absolute right-3.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-slate-400 pointer-events-none" />
              </div>
            </div>
          </div>

          {/* Quick Categories Bar */}
          <div className="flex flex-wrap items-center gap-2">
            {categories.map((category) => {
              let label = category;
              if (category === "All") label = t("cat.all");
              if (category === "Suits") label = t("cat.suits");
              if (category === "Shirts") label = t("cat.shirts");
              if (category === "Tees & Vests") label = t("cat.tees");
              if (category === "Premium Casuals") label = t("cat.casuals");

              return (
                <button
                  key={category}
                  id={`cat-btn-${category}`}
                  onClick={() => setSelectedCategory(category)}
                  className={`rounded-full px-4.5 py-1.5 text-xs font-bold tracking-wide uppercase transition-all duration-200 cursor-pointer ${
                    selectedCategory === category
                      ? "bg-indigo-600 text-white shadow-md shadow-indigo-600/10"
                      : "bg-white text-slate-500 border border-slate-200 hover:border-slate-300 hover:text-slate-800"
                  }`}
                >
                  {label}
                </button>
              );
            })}
          </div>

          {/* Product Feed Grid */}
          <motion.div layout id="products-grid-feed" className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            <AnimatePresence mode="popLayout">
              {filteredProducts.map((prod) => (
                <ProductCard
                  key={prod.id}
                  product={prod}
                  onViewDetails={handleViewDetails}
                  onAddToCart={handleAddToCart}
                  onToggleFavorite={handleToggleFavorite}
                  isFavorite={!!favorites.find((fav) => fav.id === prod.id)}
                />
              ))}
            </AnimatePresence>
          </motion.div>

          {/* Empty State Feed */}
          {filteredProducts.length === 0 && (
            <div className="text-center py-20 rounded-2xl border border-dashed border-slate-200 bg-white">
              <Info className="h-8 w-8 text-slate-300 mx-auto" />
              <h3 className="mt-4 text-xs font-bold tracking-wider text-slate-800 uppercase">
                No articles matching your terms
              </h3>
              <p className="mt-1 text-[11px] text-slate-400">
                Attempt to clear your search details or select different categories tags.
              </p>
              <button
                id="reset-filters-btn"
                onClick={() => {
                  setSearchTerm("");
                  setSelectedCategory("All");
                  setSortBy("popular");
                }}
                className="mt-6 rounded-lg border border-slate-200 bg-white px-5 py-2.5 text-xs font-bold uppercase tracking-wider text-slate-700 hover:bg-slate-50 cursor-pointer"
              >
                Reset Filters
              </button>
            </div>
          )}
        </section>

        {/* Social Connection Hub */}
        <SocialHub />

        {/* Minimalist Interactive Newsletter & Support */}
        <section className="rounded-2xl bg-slate-100 border border-slate-200/60 p-8 sm:p-12 grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
          <div className="space-y-3.5">
            <span className="text-[10px] font-extrabold text-indigo-600 uppercase tracking-widest block">
              Join Our Journal
            </span>
            <h3 className="text-xl sm:text-2xl font-extrabold text-slate-900 tracking-tight uppercase leading-tight">
              Get notified of newly dropped garment batches.
            </h3>
            <p className="text-xs text-slate-500 leading-relaxed max-w-sm">
              We compile stories around slow fabric cultivation, bespoke tailoring methodologies, and sustainable materials. Zero spam, unsubscribe anytime.
            </p>
          </div>
          <div>
            <form
              id="newsletter-form"
              onSubmit={(e) => {
                e.preventDefault();
                addToast("Thank you for subscribing to AURA Journal!", "success");
                const form = e.currentTarget;
                form.reset();
              }}
              className="flex items-center gap-2.5"
            >
              <input
                id="newsletter-email"
                type="email"
                required
                placeholder="Enter email for news..."
                className="flex-1 rounded-md border border-slate-200 bg-white px-3.5 py-2.5 text-xs font-semibold text-slate-800 shadow-2xs focus:border-indigo-600 focus:outline-hidden"
              />
              <button
                id="newsletter-submit"
                type="submit"
                className="rounded-md bg-indigo-600 px-4 py-2.5 text-xs font-black uppercase tracking-wider text-white transition-all hover:bg-indigo-700 shrink-0 cursor-pointer"
              >
                Join
              </button>
            </form>
          </div>
        </section>
      </main>

      {/* Modern Aesthetic Footer */}
      <footer className="mt-12 bg-white border-t border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-8 py-12 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-8">
          {/* branding column */}
          <div className="space-y-4">
            <span className="text-sm font-black tracking-widest uppercase text-slate-900">
              AURA <span className="text-indigo-600">//</span> Modern Living
            </span>
            <p className="text-[11px] text-slate-400 leading-relaxed font-normal">
              Crafting premium luxury garments with architectural silhouettes. Made from certified organic cotton, fine Merino wool, and carbon-neutral linen yarns.
            </p>
          </div>

          {/* Quick links */}
          <div className="space-y-3">
            <h5 className="text-[10px] font-extrabold tracking-widest text-slate-400 uppercase">
              The Archives
            </h5>
            <div className="flex flex-col gap-2.5 text-xs text-slate-500 font-bold uppercase tracking-wider">
              <a href="#collection-grid" onClick={() => setSelectedCategory("Suits")} className="hover:text-indigo-600 transition-colors">Bespoke Suits</a>
              <a href="#collection-grid" onClick={() => setSelectedCategory("Shirts")} className="hover:text-indigo-600 transition-colors">Crisp Shirts</a>
              <a href="#collection-grid" onClick={() => setSelectedCategory("Tees & Vests")} className="hover:text-indigo-600 transition-colors">Gengis & Tees</a>
              <a href="#collection-grid" onClick={() => setSelectedCategory("Premium Casuals")} className="hover:text-indigo-600 transition-colors">Premium Casuals</a>
            </div>
          </div>

          {/* Help links */}
          <div className="space-y-3">
            <h5 className="text-[10px] font-extrabold tracking-widest text-slate-400 uppercase">
              AURA Services
            </h5>
            <div className="flex flex-col gap-2.5 text-xs text-slate-500 font-bold uppercase tracking-wider">
              <span className="cursor-pointer hover:text-indigo-600 transition-colors" onClick={() => addToast("Exchange & Return Guarantee in inbox", "info")}>Warranty Claims</span>
              <span className="cursor-pointer hover:text-indigo-600 transition-colors" onClick={() => addToast("Track parcel details online", "info")}>Carbon Freight tracking</span>
              <span className="cursor-pointer hover:text-indigo-600 transition-colors" onClick={() => addToast("Custom bulk catalog in mail", "info")}>B2B Corporate batches</span>
              <span className="cursor-pointer hover:text-indigo-600 transition-colors" onClick={() => addToast("All lines active on +1 800-AURA-LIV", "info")}>Customer Support</span>
            </div>
          </div>

          {/* Fineprint copyright details */}
          <div className="space-y-3">
            <h5 className="text-[10px] font-extrabold tracking-widest text-slate-400 uppercase">
              Sartorial Wardrobe
            </h5>
            <p className="text-[11px] text-slate-400 leading-relaxed font-normal">
              Designed with architectural precision. Fabricated strictly utilizing carbon-neutral workflows, organic cottons, and fair-wage studios.
            </p>
            <span className="block text-[9px] text-slate-400 font-semibold uppercase tracking-wider">
              AURA Living Concept © 2026. All rights preserved.
            </span>
          </div>
        </div>
      </footer>

      {/* Embedded Component Slide-over Drawer Portals & Modals */}
      <ProductDetails
        product={selectedProduct}
        isOpen={isDetailOpen}
        onClose={() => setIsDetailOpen(false)}
        onAddToCart={handleAddToCart}
        onToggleFavorite={handleToggleFavorite}
        isFavorite={selectedProduct ? !!favorites.find((fav) => fav.id === selectedProduct.id) : false}
      />

      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        cartItems={cart}
        onUpdateQuantity={handleUpdateCartQuantity}
        onRemoveItem={handleRemoveCartItem}
        onCheckout={() => {
          setIsCartOpen(false);
          setIsCheckoutOpen(true);
        }}
      />

      <FavoritesDrawer
        isOpen={isFavoritesOpen}
        onClose={() => setIsFavoritesOpen(false)}
        favorites={favorites}
        onRemoveFavorite={handleToggleFavorite}
        onAddToCart={(product) => {
          handleAddToCart(product);
          // Auto add to bag
        }}
        onViewDetails={handleViewDetails}
      />

      <CheckoutModal
        isOpen={isCheckoutOpen}
        onClose={() => setIsCheckoutOpen(false)}
        cartItems={cart}
        onOrderSuccess={handleOrderSuccess}
      />

      <StaffDeskModal
        isOpen={isStaffOpen}
        onClose={() => setIsStaffOpen(false)}
        onToast={addToast}
      />

      {/* Floating Messenger Quick Contact Buttons */}
      <div className="fixed bottom-4 right-4 z-45 flex flex-row sm:flex-col items-center sm:items-end gap-1.5 sm:gap-2.5 font-sans select-none">
        <span className="hidden sm:inline-block text-[9px] bg-slate-900 text-slate-100 px-2.5 py-1 rounded-md font-bold uppercase tracking-widest shadow-md border border-slate-800">
          সরাসরি অর্ডার // Direct Order
        </span>
        <a
          id="floating-all-socials-trigger"
          href="#social-hub-section"
          className="flex h-9 w-9 sm:h-auto sm:w-auto items-center justify-center sm:justify-start gap-1.5 sm:gap-2.5 rounded-full bg-indigo-600 text-white shadow-xl hover:bg-indigo-700 transition-all hover:scale-105 active:scale-95 cursor-pointer sm:px-4 sm:py-3 text-xs font-black uppercase tracking-wider"
          title="All Socials // সকল সোশ্যাল মিডিয়া"
        >
          <span className="relative flex h-1.5 w-1.5 shrink-0">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-indigo-300 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-1.5 w-1.5 bg-white"></span>
          </span>
          <Sparkles className="h-4 w-4 shrink-0 text-amber-300 animate-pulse" />
          <span className="hidden sm:inline">All Socials // সকল সোশ্যাল মিডিয়া</span>
        </a>
        <a
          id="floating-whatsapp-trigger"
          href="https://wa.me/8801871731341?text=Hello!%20I%20would%2520like%20to%20place%2520an%20order%20directly."
          target="_blank"
          rel="noopener noreferrer"
          className="flex h-9 w-9 sm:h-auto sm:w-auto items-center justify-center sm:justify-start gap-1.5 sm:gap-2.5 rounded-full bg-emerald-600 text-white shadow-xl hover:bg-emerald-700 transition-all hover:scale-105 active:scale-95 cursor-pointer sm:px-4 sm:py-3 text-xs font-black uppercase tracking-wider"
          title="WhatsApp: 01871731341"
        >
          <span className="relative flex h-1.5 w-1.5 shrink-0">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-300 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-1.5 w-1.5 bg-emerald-400"></span>
          </span>
          <MessageSquare className="h-4 w-4 shrink-0" />
          <span className="hidden sm:inline">WhatsApp: 01871731341</span>
        </a>
        <a
          id="floating-facebook-trigger"
          href="https://www.facebook.com/itzashiqvai999"
          target="_blank"
          rel="noopener noreferrer"
          className="flex h-9 w-9 sm:h-auto sm:w-auto items-center justify-center sm:justify-start gap-1.5 sm:gap-2 rounded-full bg-blue-600 text-white shadow-xl hover:bg-blue-700 transition-all hover:scale-105 active:scale-95 cursor-pointer sm:px-4 sm:py-3 text-xs font-black uppercase tracking-wider"
          title="Facebook Contact"
        >
          <Facebook className="h-4 w-4 shrink-0" />
          <span className="hidden sm:inline">Facebook Contact</span>
        </a>
      </div>

      {/* Toast Alert popups */}
      <ToastContainer toasts={toasts} onDismiss={removeToast} />
    </div>
  );
}

import React, { useState } from "react";
import { Product, Review } from "../types";
import { REVIEWS } from "../data";
import { X, Star, ShoppingBag, ShieldCheck, Truck, RefreshCw, Heart, MessageSquare, Facebook } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { useLocalization } from "../context/LocalizationContext";

interface ProductDetailsProps {
  product: Product | null;
  isOpen: boolean;
  onClose: () => void;
  onAddToCart: (product: Product, quantity: number) => void;
  onToggleFavorite: (product: Product) => void;
  isFavorite: boolean;
}

export const ProductDetails: React.FC<ProductDetailsProps> = ({
  product,
  isOpen,
  onClose,
  onAddToCart,
  onToggleFavorite,
  isFavorite,
}) => {
  const { formatPrice, t, language } = useLocalization();
  const [quantity, setQuantity] = useState(1);
  const [activeTab, setActiveTab] = useState<"details" | "specs" | "reviews">("details");

  if (!product) return null;

  const reviewsList: Review[] = REVIEWS[product.id] || [];

  const handleAddToCart = () => {
    onAddToCart(product, quantity);
    setQuantity(1); // Reset
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 overflow-hidden">
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-black/40 backdrop-blur-xs transition-opacity"
          />

          <div className="pointer-events-none fixed inset-y-0 right-0 flex max-w-full pl-10 md:pl-16">
            <motion.div
              initial={{ x: "100%" }}
              animate={{ x: 0 }}
              exit={{ x: "100%" }}
              transition={{ type: "spring", damping: 25, stiffness: 220 }}
              className="pointer-events-auto w-screen max-w-2xl"
            >
              <div className="flex h-full flex-col overflow-y-scroll bg-slate-50 shadow-2xl">
                {/* Header Section */}
                <div className="sticky top-0 z-15 flex items-center justify-between border-b border-slate-200 bg-white/95 backdrop-blur-md px-6 py-4">
                  <h2 className="text-base font-bold text-slate-900 uppercase tracking-widest">
                    AURA Archive // {product.category}
                  </h2>
                  <div className="flex items-center gap-3">
                    <button
                      id={`details-fav-btn`}
                      onClick={() => onToggleFavorite(product)}
                      className="flex h-9 w-9 items-center justify-center rounded-full border border-slate-200 bg-white text-slate-600 shadow-xs hover:bg-slate-50 hover:text-rose-500 transition-colors"
                    >
                      <Heart className={`h-4.5 w-4.5 ${isFavorite ? "fill-rose-500 text-rose-500" : ""}`} />
                    </button>
                    <button
                      id="details-close-btn"
                      onClick={onClose}
                      className="flex h-9 w-9 items-center justify-center rounded-full border border-slate-200 bg-white text-slate-500 shadow-xs hover:bg-slate-50 hover:text-slate-900 transition-colors"
                    >
                      <X className="h-4.5 w-4.5" />
                    </button>
                  </div>
                </div>

                {/* Substantive Showcase Body */}
                <div className="flex-1 p-6 md:p-8 space-y-8">
                  {/* Image Gallery Showcase */}
                  <div className="overflow-hidden rounded-xl border border-slate-200 bg-slate-100 flex items-center justify-center aspect-16/10">
                    <img
                      src={product.image}
                      alt={product.name}
                      className="h-full w-full object-cover"
                      referrerPolicy="no-referrer"
                    />
                  </div>

                  {/* High Quality Design Segment title info */}
                  <div>
                    <span className="text-xs font-semibold tracking-wider text-slate-400 uppercase">
                      {product.category === "Suits" ? t("cat.suits") : product.category === "Shirts" ? t("cat.shirts") : product.category === "Tees & Vests" ? t("cat.tees") : t("cat.casuals")}
                    </span>
                    <h1 className="mt-1 text-2xl md:text-3xl font-extrabold text-slate-900 tracking-tight leading-tight">
                      {language === "bn" && product.name.includes("Supima Cotton") ? "সুপিমা লাক্সারি কটন ক্রুনেক গেঞ্জি" :
                       language === "bn" && product.name.includes("Oxford Cotton") ? "অক্সফোর্ড বাটন-ডাউন কলার শার্ট" :
                       language === "bn" && product.name.includes("Heavyweight Organic") ? "ভারী সুতি জিপার হুডি জ্যাকেট" :
                       language === "bn" && product.name.includes("Sartorial Classic") ? "ক্লাসিক ইতালিয়ান ব্লেজার স্যুট" :
                       language === "bn" && product.name.includes("Ribbed Combed") ? "কম্বড রিঙ্গড আরামদায়ক গেঞ্জি" :
                       language === "bn" && product.name.includes("Linen Silk") ? "লিলেন সিল্ক ক্লাসিক ক্যাজুয়াল শার্ট" :
                       language === "bn" && product.name.includes("Cashmere Blend") ? "প্রিমিয়াম কাশ্মীরি ব্লেন্ড ব্লেজার পোশাক" : product.name}
                    </h1>
                    <p className="mt-2 text-sm italic text-slate-605 font-medium">
                      "{language === "bn" && product.tagline.includes("Seamless") ? "সরাসরি নিখুঁত ব্যাক-সিম ও উন্নত প্রিমিয়াম ফিনিশিং সুতি গেঞ্জি।" :
                        language === "bn" && product.tagline.includes("Heavyweight") ? "ভারী সুতি প্রিমিয়াম মেটাল জিপারযুক্ত জমকালো হুডি।" :
                        language === "bn" && product.tagline.includes("Double-Breasted") ? "ডাবল ব্রেস্টেড জ্যাকেট স্যুট নিখুঁত পোশাক কারিগরি।" :
                        language === "bn" && product.tagline.includes("Durable ribbed") ? "দীর্ঘস্থায়ী ডাবল প্রো-রিঙ্গড আরামদায়ক কালার গেঞ্জি।" :
                        language === "bn" && product.tagline.includes("Architectural") ? " can be used worldwide." :
                        language === "bn" && product.tagline.includes("Structured") ? "প্রিমিয়াম ইতালীয় খাঁটি পশমী কাপড় দ্বারা বোনা স্যুট।" : product.tagline}"
                    </p>
                    <div className="mt-4 flex items-center gap-6">
                      <span className="text-2xl font-black text-slate-950 font-mono">
                        {formatPrice(product.price)}
                      </span>
                      <div className="flex items-center gap-1.5 border-l border-slate-200 pl-6 text-sm text-slate-600">
                        <div className="flex items-center gap-0.5 text-amber-500">
                          {Array.from({ length: 5 }).map((_, i) => (
                            <Star
                              key={i}
                              className={`h-4 w-4 ${
                                i < Math.floor(product.rating)
                                  ? "fill-amber-500 stroke-amber-500"
                                  : "text-slate-300"
                              }`}
                            />
                          ))}
                        </div>
                        <span className="font-semibold text-slate-800">
                          {product.rating}
                        </span>
                        <span className="text-slate-400">
                          ({product.reviewCount} customer reviews)
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Interactive Details / Tech Specs / Reviews Selector Menu */}
                  <div className="border-b border-slate-200">
                    <nav className="-mb-px flex space-x-8" aria-label="Tabs">
                      {(["details", "specs", "reviews"] as const).map((tab) => (
                        <button
                          key={tab}
                          id={`tab-${tab}`}
                          onClick={() => setActiveTab(tab)}
                          className={`border-b-2 py-3 px-1 text-sm font-bold uppercase tracking-wider transition-all ${
                            activeTab === tab
                              ? "border-indigo-600 text-indigo-600"
                              : "border-transparent text-slate-400 hover:border-slate-300 hover:text-slate-600"
                          }`}
                        >
                          {tab}
                        </button>
                      ))}
                    </nav>
                  </div>

                  {/* Active tab rendered cleanly */}
                  <div className="min-h-48">
                    {activeTab === "details" && (
                      <div className="space-y-6">
                        <p className="text-sm leading-relaxed text-slate-600">
                          {product.description}
                        </p>
                        <div className="rounded-xl border border-slate-100 bg-white p-5 shadow-xs">
                          <h4 className="text-xs font-bold tracking-wider text-slate-900 uppercase mb-4">
                            Key Highlights
                          </h4>
                          <ul className="space-y-3">
                            {product.details.map((detail, index) => (
                              <li key={index} className="flex items-start gap-2.5 text-xs text-slate-600">
                                <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-indigo-600" />
                                <span className="leading-normal">{detail}</span>
                              </li>
                            ))}
                          </ul>
                        </div>
                      </div>
                    )}

                    {activeTab === "specs" && (
                      <div className="overflow-hidden rounded-xl border border-slate-200 bg-white shadow-xs">
                        <table className="min-w-full divide-y divide-slate-150">
                          <tbody className="divide-y divide-slate-100 divide-solid">
                            {product.specifications.map((spec, index) => (
                              <tr key={index} className={index % 2 === 0 ? "bg-slate-50/50" : "bg-white"}>
                                <td className="whitespace-nowrap py-3.5 pl-5 pr-3 text-xs font-bold uppercase tracking-wider text-slate-400">
                                  {spec.label}
                                </td>
                                <td className="py-3.5 pl-4 pr-5 text-xs font-medium text-slate-800">
                                  {spec.value}
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    )}

                    {activeTab === "reviews" && (
                      <div className="space-y-5">
                        {reviewsList.length === 0 ? (
                          <div className="rounded-xl border border-dashed border-slate-200 py-10 text-center">
                            <p className="text-xs text-slate-400 uppercase tracking-widest font-medium">
                              No Reviews Yet for this Batch
                            </p>
                          </div>
                        ) : (
                          reviewsList.map((review) => (
                            <div key={review.id} className="rounded-xl border border-slate-100 bg-white p-4 shadow-xs">
                              <div className="flex items-center justify-between gap-2">
                                <span className="text-xs font-bold text-slate-900">{review.userName}</span>
                                <span className="text-[10px] text-slate-400">{review.date}</span>
                              </div>
                              <div className="mt-1.5 flex items-center gap-0.5 text-amber-500">
                                {Array.from({ length: 5 }).map((_, i) => (
                                  <Star
                                    key={i}
                                    className={`h-3 w-3 ${
                                      i < review.rating ? "fill-amber-500 stroke-amber-500" : "text-slate-200"
                                    }`}
                                  />
                                ))}
                              </div>
                              <p className="mt-2.5 text-xs text-slate-600 leading-relaxed font-normal">
                                {review.comment}
                              </p>
                            </div>
                          ))
                        )}
                      </div>
                    )}
                  </div>

                  {/* Global Core Trust Factors */}
                  <div className="grid grid-cols-3 gap-4 border-t border-b border-slate-200 py-6">
                    <div className="flex flex-col items-center text-center p-2">
                      <ShieldCheck className="h-5 w-5 text-indigo-600" />
                      <span className="mt-2 text-[10px] font-bold text-slate-800 uppercase tracking-wider">
                        Secure Warranty
                      </span>
                      <span className="mt-1 text-[9px] text-slate-400">
                        10-year protection details
                      </span>
                    </div>
                    <div className="flex flex-col items-center text-center p-2">
                      <Truck className="h-5 w-5 text-indigo-600" />
                      <span className="mt-2 text-[10px] font-bold text-slate-800 uppercase tracking-wider">
                        Carbon-Neutral Shipping
                      </span>
                      <span className="mt-1 text-[9px] text-slate-400">
                        Delivered safely inside green packs
                      </span>
                    </div>
                    <div className="flex flex-col items-center text-center p-2">
                      <RefreshCw className="h-5 w-5 text-indigo-600" />
                      <span className="mt-2 text-[10px] font-bold text-slate-800 uppercase tracking-wider">
                        30-Day Returns
                      </span>
                      <span className="mt-1 text-[9px] text-slate-400">
                        Effortless return parcel pickup
                      </span>
                    </div>
                  </div>
                </div>

                {/* Footer Drawer Action Toolbar */}
                <div className="sticky bottom-0 z-15 border-t border-slate-200 bg-white px-6 py-5 space-y-4">
                  <div className="flex items-center justify-between gap-4">
                    {/* Quantity Picker */}
                    <div className="flex items-center rounded-lg border border-slate-200 px-1 bg-slate-50">
                      <button
                        id="qty-minus"
                        onClick={() => quantity > 1 && setQuantity(quantity - 1)}
                        className="flex h-9 w-9 items-center justify-center text-sm font-semibold text-slate-500 hover:text-slate-900 active:scale-90"
                      >
                        -
                      </button>
                      <span className="w-8 text-center text-xs font-bold text-slate-800">
                        {quantity}
                      </span>
                      <button
                        id="qty-plus"
                        onClick={() => quantity < product.stock && setQuantity(quantity + 1)}
                        className="flex h-9 w-9 items-center justify-center text-sm font-semibold text-slate-500 hover:text-slate-900 active:scale-90"
                      >
                        +
                      </button>
                    </div>

                    {/* Grand Buy Button */}
                    <button
                      id="details-to-cart-btn"
                      onClick={handleAddToCart}
                      className="flex-1 flex items-center justify-center gap-2.5 rounded-lg bg-indigo-600 py-3.5 text-xs font-bold uppercase tracking-wider text-white shadow-md transition-all hover:bg-indigo-700 active:scale-[0.98] cursor-pointer"
                    >
                      <ShoppingBag className="h-4 w-4" />
                      <span>{t("prod.addToCart")} // {formatPrice(product.price * quantity)}</span>
                    </button>
                  </div>

                  <div className="relative flex py-1 items-center">
                    <div className="flex-grow border-t border-slate-200"></div>
                    <span className="flex-shrink mx-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest bg-white px-2">
                      {language === "en" ? "Or Order Directly" : "অথবা সরাসরি মোবাইল অর্ডারিং"}
                    </span>
                    <div className="flex-grow border-t border-slate-200"></div>
                  </div>

                  <div className="grid grid-cols-2 gap-3 pb-1">
                    <a
                      id="details-order-whatsapp-btn"
                      href={`https://wa.me/8801871731341?text=${encodeURIComponent(
                        `Hello! I'd like to order the following product directly:\n\n` +
                        `Product: ${product.name}\n` +
                        `Category: ${product.category}\n` +
                        `Price: ${formatPrice(product.price)}\n` +
                        `Quantity: ${quantity}\n` +
                        `Subtotal: ${formatPrice(product.price * quantity)}\n\n` +
                        `Please guide me on the next delivery steps.`
                      )}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center justify-center gap-2 rounded-lg border border-emerald-200 bg-emerald-50 py-3 text-xs font-bold uppercase tracking-wider text-emerald-800 transition-all hover:bg-emerald-100 hover:border-emerald-300 active:scale-[0.98] cursor-pointer"
                    >
                      <MessageSquare className="h-4 w-4 text-emerald-600" />
                      WhatsApp
                    </a>
                    <a
                      id="details-order-facebook-btn"
                      href="https://www.facebook.com/itzashiqvai999"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center justify-center gap-2 rounded-lg border border-blue-200 bg-blue-50 py-3 text-xs font-bold uppercase tracking-wider text-blue-800 transition-all hover:bg-blue-100 hover:border-blue-300 active:scale-[0.98] cursor-pointer"
                    >
                      <Facebook className="h-4 w-4 text-blue-600" />
                      Facebook Page
                    </a>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      )}
    </AnimatePresence>
  );
};

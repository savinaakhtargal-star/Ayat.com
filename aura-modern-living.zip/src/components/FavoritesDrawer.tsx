import React from "react";
import { Product } from "../types";
import { X, Heart, ShoppingBag, Eye } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

interface FavoritesDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  favorites: Product[];
  onRemoveFavorite: (product: Product) => void;
  onAddToCart: (product: Product) => void;
  onViewDetails: (product: Product) => void;
}

export const FavoritesDrawer: React.FC<FavoritesDrawerProps> = ({
  isOpen,
  onClose,
  favorites,
  onRemoveFavorite,
  onAddToCart,
  onViewDetails,
}) => {
  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 overflow-hidden">
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-black/40 backdrop-blur-xs transition-opacity"
          />

          <div className="pointer-events-none fixed inset-y-0 right-0 flex max-w-full pl-10">
            <motion.div
              initial={{ x: "100%" }}
              animate={{ x: 0 }}
              exit={{ x: "100%" }}
              transition={{ type: "spring", damping: 25, stiffness: 220 }}
              className="pointer-events-auto w-screen max-w-md"
            >
              <div className="flex h-full flex-col bg-white shadow-2xl">
                {/* Favorites Header */}
                <div className="flex items-center justify-between border-b border-slate-100 bg-slate-50 px-5 py-4">
                  <div className="flex items-center gap-2">
                    <Heart className="h-5 w-5 text-rose-500 fill-rose-500" />
                    <h2 className="text-sm font-bold uppercase tracking-wider text-slate-900">
                      Saved Collection ({favorites.length})
                    </h2>
                  </div>
                  <button
                    id="favorites-close-btn"
                    onClick={onClose}
                    className="flex h-8 w-8 items-center justify-center rounded-full border border-slate-200 text-slate-400 hover:bg-slate-100 hover:text-slate-800 transition-colors"
                  >
                    <X className="h-4 w-4" />
                  </button>
                </div>

                {/* Favorites Content */}
                <div className="flex-1 overflow-y-auto p-5 space-y-4">
                  {favorites.length === 0 ? (
                    <div className="flex h-full flex-col items-center justify-center text-center space-y-4">
                      <div className="rounded-full bg-slate-50 p-6 flex items-center justify-center border border-dashed border-slate-200">
                        <Heart className="h-8 w-8 text-slate-300" />
                      </div>
                      <div className="space-y-1">
                        <p className="text-xs font-bold text-slate-800 uppercase tracking-wider">
                          No items favorited
                        </p>
                        <p className="text-[11px] text-slate-400 font-normal">
                          Click the heart insignia on catalog pieces to cache them.
                        </p>
                      </div>
                      <button
                        id="favorites-browse-btn"
                        onClick={onClose}
                        className="rounded-lg bg-indigo-600 px-5 py-2.5 text-xs font-bold uppercase tracking-wider text-white transition-all hover:bg-indigo-700"
                      >
                        Explore Gallery
                      </button>
                    </div>
                  ) : (
                    favorites.map((product) => (
                      <div
                        key={product.id}
                        className="flex items-center gap-4 rounded-xl border border-slate-100 bg-slate-50/50 p-3 transition-colors hover:bg-slate-100"
                      >
                        {/* Thumbnail */}
                        <div
                          onClick={() => {
                            onViewDetails(product);
                            onClose();
                          }}
                          className="h-16 w-16 shrink-0 overflow-hidden rounded-lg border border-slate-200 bg-white cursor-pointer"
                        >
                          <img
                            src={product.image}
                            alt={product.name}
                            className="h-full w-full object-cover"
                            referrerPolicy="no-referrer"
                          />
                        </div>

                        {/* Title details */}
                        <div className="flex-1 min-w-0">
                          <h4
                            onClick={() => {
                              onViewDetails(product);
                              onClose();
                            }}
                            className="truncate text-xs font-bold text-slate-900 cursor-pointer hover:text-indigo-600"
                          >
                            {product.name}
                          </h4>
                          <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">
                            ${product.price.toLocaleString()}
                          </span>

                          <div className="mt-2 flex items-center gap-3">
                            <button
                              id={`fav-del-${product.id}`}
                              onClick={() => onRemoveFavorite(product)}
                              className="text-[10px] text-slate-400 hover:text-rose-500 font-bold uppercase tracking-wider transition-colors cursor-pointer"
                            >
                              Remove Tag
                            </button>
                          </div>
                        </div>

                        {/* Fast add action */}
                        <div className="flex flex-col gap-1.5 shrink-0">
                          <button
                            id={`fav-to-cart-${product.id}`}
                            onClick={() => onAddToCart(product)}
                            className="flex h-8 w-8 items-center justify-center rounded-lg bg-indigo-600 text-white hover:bg-indigo-700 transition-colors"
                            title="Add to Shopping Bag"
                          >
                            <ShoppingBag className="h-3.5 w-3.5" />
                          </button>
                          <button
                            id={`fav-details-${product.id}`}
                            onClick={() => {
                              onViewDetails(product);
                              onClose();
                            }}
                            className="flex h-8 w-8 items-center justify-center rounded-lg border border-slate-200 bg-white text-slate-500 hover:bg-slate-50 hover:text-slate-950 transition-colors"
                            title="View Product Sheets"
                          >
                            <Eye className="h-3.5 w-3.5" />
                          </button>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      )}
    </AnimatePresence>
  );
};

import React, { useState } from "react";
import { CartItem, ShippingAddress, PaymentDetails } from "../types";
import { X, Check, ArrowRight, ArrowLeft, ShieldCheck, Mail, Calendar, Sparkles, MessageSquare, Facebook, Youtube, Send, Users, Gamepad2, Cpu, Smartphone, CreditCard } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { useLocalization } from "../context/LocalizationContext";

interface CheckoutModalProps {
  isOpen: boolean;
  onClose: () => void;
  cartItems: CartItem[];
  onOrderSuccess: (orderData?: any) => void;
}

export const CheckoutModal: React.FC<CheckoutModalProps> = ({
  isOpen,
  onClose,
  cartItems,
  onOrderSuccess,
}) => {
  const { language, currency, formatPrice, t } = useLocalization();

  const [step, setStep] = useState(1); // 1 = Shipping, 2 = Payment, 3 = Review, 4 = Success
  const [paymentMethod, setPaymentMethod] = useState<"direct" | "bkash" | "nagad" | "card">("direct");
  const [deliveryMethod, setDeliveryMethod] = useState<"pickup" | "delivery">("pickup");
  const [createdOrder, setCreatedOrder] = useState<any>(null);
  
  const [shipping, setShipping] = useState<ShippingAddress>({
    fullName: "",
    email: "",
    phone: "",
    street: "",
    city: "",
    state: "",
    zipCode: "1212",
    notes: "",
  });

  const [payment, setPayment] = useState<PaymentDetails>({
    cardName: "",
    cardNumber: "",
    expiryDate: "",
    cvv: "",
  });

  // bKash & Nagad custom states
  const [bkashNumber, setBkashNumber] = useState("");
  const [bkashTxid, setBkashTxid] = useState("");
  const [nagadNumber, setNagadNumber] = useState("");
  const [nagadTxid, setNagadTxid] = useState("");

  const [orderId, setOrderId] = useState("");
  const [deliveryDate, setDeliveryDate] = useState("");

  const subtotal = cartItems.reduce(
    (acc, item) => acc + item.product.price * item.quantity,
    0
  );
  
  // Free shipping over $300 USD
  const carbonShipping = subtotal >= 300 ? 0 : 25;
  const mockTax = Math.round(subtotal * 0.0825);
  const totalAmount = subtotal + carbonShipping + mockTax;

  const handleNextStep = () => {
    if (step < 3) {
      setStep(step + 1);
    } else if (step === 3) {
      const uniqueId = "AUR-" + Math.floor(100000 + Math.random() * 900000);
      setOrderId(uniqueId);

      const edDate = new Date();
      edDate.setDate(edDate.getDate() + 4);
      setDeliveryDate(edDate.toLocaleDateString(language === "bn" ? "bn-BD" : "en-US", {
        weekday: "long",
        month: "short",
        day: "numeric",
        year: "numeric"
      }));

      const orderObj = {
        id: uniqueId,
        shipping: { 
          ...shipping,
          notes: shipping.notes || "",
          street: deliveryMethod === "pickup" ? "In-Store Pickup (সরাসরি দোকান থেকে সংগ্রহ)" : shipping.street,
          city: deliveryMethod === "pickup" ? "Store Pickup (দোকান)" : shipping.city,
          state: deliveryMethod === "pickup" ? "Dhaka/Store" : shipping.state,
          zipCode: deliveryMethod === "pickup" ? "1212" : shipping.zipCode,
        },
        deliveryMethod: deliveryMethod,
        paymentMethod: paymentMethod === "direct" ? "Cash On Delivery" : paymentMethod === "bkash" ? "bKash" : paymentMethod === "nagad" ? "Nagad" : "Stripe Credit Card",
        items: cartItems.map(item => ({
          product: {
            id: item.product.id,
            name: item.product.name,
            price: item.product.price,
            image: item.product.image,
            category: item.product.category,
          },
          quantity: item.quantity,
        })),
        total: totalAmount,
        date: new Date().toLocaleString(language === "bn" ? "bn-BD" : "en-US", {
          month: "short",
          day: "numeric",
          year: "numeric",
          hour: "2-digit",
          minute: "2-digit"
        }),
        status: "Pending"
      };
      setCreatedOrder(orderObj);
      setStep(4);
    }
  };

  const handlePrevStep = () => {
    if (step > 1) {
      setStep(step - 1);
    }
  };

  const handleFieldChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>,
    type: "shipping" | "payment"
  ) => {
    const { name, value } = e.target;
    if (type === "shipping") {
      setShipping((prev) => ({ ...prev, [name]: value }));
    } else {
      setPayment((prev) => ({ ...prev, [name]: value }));
    }
  };

  const isFormValid = () => {
    if (step === 1) {
      return (
        shipping.fullName.trim() !== "" &&
        shipping.email.trim() !== "" &&
        shipping.street.trim() !== "" &&
        shipping.city.trim() !== "" &&
        shipping.state.trim() !== "" &&
        shipping.zipCode.trim() !== "" &&
        (shipping.phone ? shipping.phone.trim() !== "" : true)
      );
    }
    if (step === 2) {
      if (paymentMethod === "direct") return true;
      if (paymentMethod === "bkash") {
        return bkashNumber.trim().length >= 11 && bkashTxid.trim().length > 3;
      }
      if (paymentMethod === "nagad") {
        return nagadNumber.trim().length >= 11 && nagadTxid.trim().length > 3;
      }
      return (
        payment.cardName.trim() !== "" &&
        payment.cardNumber.trim() !== "" &&
        payment.expiryDate.trim() !== "" &&
        payment.cvv.trim() !== ""
      );
    }
    return true;
  };

  const handleFinalClose = () => {
    if (step === 4) {
      onOrderSuccess(createdOrder);
    }
    onClose();
    setStep(1);
    setCreatedOrder(null);
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 font-sans">
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={step === 4 ? handleFinalClose : onClose}
            className="absolute inset-0 bg-black/55 backdrop-blur-xs"
          />

          {/* Modal Container */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 15 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 15 }}
            transition={{ duration: 0.3 }}
            className="relative z-10 w-full max-w-2xl overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-2xl flex flex-col max-h-[90vh]"
          >
            {/* Header */}
            <div className="flex items-center justify-between border-b border-slate-200 bg-slate-50 px-6 py-4">
              <div className="flex flex-col">
                <span className="text-[10px] font-bold uppercase tracking-widest text-indigo-650">
                  {language === "en" ? "Secure Checkout Portal" : "সুরক্ষিত পেমেন্ট পোর্টাল // SSL Secured"}
                </span>
                <h3 className="text-sm font-extrabold uppercase tracking-widest text-slate-900 mt-0.5">
                  {step === 4 ? (language === "en" ? "Order Confirmed" : "অর্ডার সফল হয়েছে") : `${language === "en" ? "Checkout Flow" : "অর্ডার করুন"} (Step ${step} of 3)`}
                </h3>
              </div>
              <button
                id="checkout-close"
                onClick={handleFinalClose}
                className="flex h-8 w-8 items-center justify-center rounded-full border border-slate-200 text-slate-400 hover:bg-slate-100 hover:text-slate-800 transition-colors mb-0.5 cursor-pointer"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            {/* Stepper Progress bar (only for steps 1-3) */}
            {step < 4 && (
              <div className="grid grid-cols-3 bg-slate-50 border-b border-slate-100">
                <div
                  className={`py-3 text-center text-xs font-bold transition-colors ${
                    step >= 1 ? "text-indigo-600 bg-indigo-50/60" : "text-slate-400"
                  }`}
                >
                  1. {language === "en" ? "Shipping" : "ডেলিভারি তথ্য"}
                </div>
                <div
                  className={`py-3 text-center text-xs font-bold border-l border-r border-slate-200 transition-colors ${
                    step >= 2 ? "text-indigo-600 bg-indigo-50/60" : "text-slate-400"
                  }`}
                >
                  2. {language === "en" ? "Payment" : "মূল্য পরিশোধ"}
                </div>
                <div
                  className={`py-3 text-center text-xs font-bold transition-colors ${
                    step >= 3 ? "text-indigo-600 bg-indigo-50/60" : "text-slate-400"
                  }`}
                >
                  3. {language === "en" ? "Summary" : "অর্ডার কনফার্ম"}
                </div>
              </div>
            )}

            {/* Body */}
            <div className="flex-1 overflow-y-auto p-6 md:p-8">
              {step === 1 && (
                <div className="space-y-6">
                  {/* Direct Order Quick alternative notice */}
                  <div className="rounded-xl border border-indigo-150 bg-indigo-50/40 p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-xs">
                    <div className="space-y-0.5">
                      <p className="text-[10px] font-bold text-indigo-900 uppercase tracking-wider">
                        {language === "en" ? "Prefer ordering over WhatsApp or Facebook?" : "মেসেজে সরাসরি ঝটপট অর্ডার করতে চান?"}
                      </p>
                      <p className="text-[10px] text-slate-500 leading-normal font-normal">
                        {language === "en" ? "Skip the forms! Talk with our team directly via secure channels." : "কোনো ফর্ম ফিলআপ ছাড়াই আমাদের অফিশিয়াল হোয়াটসঅ্যাপ বা ফেসবুক মেসেঞ্জারে টিমকে জানান।"}
                      </p>
                    </div>
                    <div className="flex gap-2 shrink-0">
                      <a
                        href={`https://wa.me/8801871731341?text=${encodeURIComponent(
                          `Hello! I'd like to directly place an order for the items in my shopping bag:\n\n` +
                          cartItems.map(item => `• ${item.product.name} (x${item.quantity}) - ${formatPrice(item.product.price * item.quantity)}`).join("\n") +
                          `\n\nSubtotal: ${formatPrice(subtotal)}\nTotal: ${formatPrice(totalAmount)}\n\nPlease help me coordinate delivery directly.`
                        )}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center gap-1.5 rounded-lg bg-emerald-600 px-3 py-1.5 text-[10px] font-bold uppercase tracking-wider text-white shadow-xs transition-all hover:bg-emerald-700 active:scale-95 cursor-pointer"
                      >
                        <MessageSquare className="h-3.5 w-3.5 shrink-0" />
                        WhatsApp
                      </a>
                      <a
                        href="https://www.facebook.com/itzashiqvai999"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center gap-1.5 rounded-lg bg-blue-600 px-3 py-1.5 text-[10px] font-bold uppercase tracking-wider text-white shadow-xs transition-colors hover:bg-blue-700 active:scale-95 cursor-pointer"
                      >
                        <Facebook className="h-3.5 w-3.5 shrink-0" />
                        Facebook
                      </a>
                    </div>
                  </div>

                  <h4 className="text-xs font-bold uppercase tracking-wider text-slate-905 flex items-center gap-1.5 border-b border-slate-100 pb-2">
                    <span>১. কন্টাক্ট ও ডেলিভারি তথ্য // Contact & Delivery Info</span>
                  </h4>

                  {/* Delivery Selection Option Row */}
                  <div className="space-y-3 bg-slate-50 border border-slate-150 p-4 rounded-xl">
                    <span className="block text-[10px] font-black uppercase tracking-wider text-slate-400">
                      ডেলিভারি বা সংগ্রহ পদ্ধতি / Delivery or Pickup Method <span className="text-rose-500">*</span>
                    </span>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      {/* Option A: Pickup */}
                      <button
                        type="button"
                        onClick={() => {
                          setDeliveryMethod("pickup");
                        }}
                        className={`p-3.5 rounded-lg border text-left flex flex-col gap-1 transition-all cursor-pointer ${
                          deliveryMethod === "pickup"
                            ? "border-indigo-600 bg-indigo-50/40 ring-1 ring-indigo-500/20"
                            : "border-slate-200 bg-white hover:border-slate-350"
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <span className="text-[11px] font-extrabold text-slate-900 flex items-center gap-1.5">
                            <span className="h-2 w-2 rounded-full bg-indigo-600"></span>
                            নিজে এসে নিয়ে যাওয়া
                          </span>
                          <span className="text-[9px] font-bold text-indigo-600 uppercase tracking-wider bg-indigo-100 px-1.5 py-0.5 rounded">
                            Store Pickup
                          </span>
                        </div>
                        <p className="text-[10px] text-slate-500 font-normal leading-normal mt-1">
                          দোকানে এসে দেখে, ভালোমতো কাপড়ের কুয়ালিটি যাচাই-বাছাই করে নিজে নিয়ে যেতে পারবেন।
                        </p>
                      </button>

                      {/* Option B: Delivery */}
                      <button
                        type="button"
                        onClick={() => {
                          setDeliveryMethod("delivery");
                        }}
                        className={`p-3.5 rounded-lg border text-left flex flex-col gap-1 transition-all cursor-pointer ${
                          deliveryMethod === "delivery"
                            ? "border-indigo-600 bg-indigo-50/40 ring-1 ring-indigo-500/20"
                            : "border-slate-200 bg-white hover:border-slate-350"
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <span className="text-[11px] font-extrabold text-slate-900 flex items-center gap-1.5">
                            <span className="h-2 w-2 rounded-full bg-indigo-650"></span>
                            হোম ডেলিভারি
                          </span>
                          <span className="text-[9px] font-bold text-amber-600 uppercase tracking-wider bg-amber-100 px-1.5 py-0.5 rounded font-mono">
                            Home Delivery
                          </span>
                        </div>
                        <p className="text-[10px] text-slate-500 font-normal leading-normal mt-1">
                          অগ্রণী কুরিয়ার বা হোম ডেলিভারি সার্ভিসের মাধ্যমে বাংলাদেশের যেকোনো ঠিকানায় শিপমেন্ট পাঠানো হবে।
                        </p>
                      </button>
                    </div>
                  </div>

                  {/* Form fields */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-500 mb-1">
                        Full Name / পুরো নাম <span className="text-rose-500">*</span>
                      </label>
                      <input
                        id="shipping-fullName"
                        type="text"
                        name="fullName"
                        required
                        value={shipping.fullName}
                        onChange={(e) => handleFieldChange(e, "shipping")}
                        className="w-full rounded-md border border-slate-200 bg-white px-3.5 py-2.5 text-xs font-medium text-slate-800 shadow-xs focus:border-indigo-600 focus:outline-hidden"
                        placeholder="আপনার নাম লিখুন"
                      />
                    </div>

                    <div>
                      <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-500 mb-1">
                        Phone Number / মোবাইল নম্বর <span className="text-rose-500">*</span>
                      </label>
                      <input
                        id="shipping-phone"
                        type="tel"
                        name="phone"
                        required
                        value={shipping.phone}
                        onChange={(e) => handleFieldChange(e, "shipping")}
                        className="w-full rounded-md border border-slate-200 bg-white px-3.5 py-2.5 text-xs font-medium text-slate-800 shadow-xs focus:border-indigo-600 focus:outline-hidden font-mono"
                        placeholder="e.g. 01871731341"
                      />
                    </div>

                    <div className="sm:col-span-2">
                      <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-500 mb-1">
                        Email Address / ইমেইল ঠিকানা <span className="text-rose-500">*</span>
                      </label>
                      <input
                        id="shipping-email"
                        type="email"
                        name="email"
                        required
                        value={shipping.email}
                        onChange={(e) => handleFieldChange(e, "shipping")}
                        className="w-full rounded-md border border-slate-200 bg-white px-3.5 py-2.5 text-xs font-medium text-slate-800 shadow-xs focus:border-indigo-600 focus:outline-hidden font-mono"
                        placeholder="yourname@gmail.com"
                      />
                    </div>

                    {deliveryMethod === "delivery" ? (
                      <>
                        <div className="sm:col-span-2">
                          <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-500 mb-1">
                            Street Address / গ্রাম, রোড, জেলা ও ঠিকানার বিবরণ <span className="text-rose-500">*</span>
                          </label>
                          <input
                            id="shipping-street"
                            type="text"
                            name="street"
                            value={shipping.street === "In-Store Pickup (সরাসরি দোকান থেকে সংগ্রহ)" ? "" : shipping.street}
                            onChange={(e) => handleFieldChange(e, "shipping")}
                            className="w-full rounded-md border border-slate-200 bg-white px-3.5 py-2.5 text-xs font-medium text-slate-800 shadow-xs focus:border-indigo-600 focus:outline-hidden"
                            placeholder="বাড়ি নং, রোড, পোস্ট অফিস ও উপজেলার বিবরণ"
                          />
                        </div>

                        <div>
                          <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-500 mb-1">
                            City / শহর (যেমন: ঢাকা) <span className="text-rose-500">*</span>
                          </label>
                          <input
                            id="shipping-city"
                            type="text"
                            name="city"
                            value={shipping.city === "Store Pickup (দোকান)" ? "" : shipping.city}
                            onChange={(e) => handleFieldChange(e, "shipping")}
                            className="w-full rounded-md border border-slate-200 bg-white px-3.5 py-2.5 text-xs font-medium text-slate-800 shadow-xs focus:border-indigo-600 focus:outline-hidden"
                            placeholder="e.g. Dhaka"
                          />
                        </div>

                        <div className="grid grid-cols-2 gap-3">
                          <div>
                            <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-500 mb-1">
                              State / বিভাগ <span className="text-rose-500">*</span>
                            </label>
                            <input
                              id="shipping-state"
                              type="text"
                              name="state"
                              value={shipping.state === "Dhaka/Store" || shipping.state === "Dhaka" ? "Dhaka" : shipping.state}
                              onChange={(e) => handleFieldChange(e, "shipping")}
                              className="w-full rounded-md border border-slate-200 bg-white px-3.5 py-2.5 text-xs font-medium text-slate-800 shadow-xs focus:border-indigo-600 focus:outline-hidden"
                              placeholder="e.g. Dhaka"
                            />
                          </div>
                          <div>
                            <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-500 mb-1">
                              ZIP / পোস্ট কোড <span className="text-rose-500">*</span>
                            </label>
                            <input
                              id="shipping-zipCode"
                              type="text"
                              name="zipCode"
                              value={shipping.zipCode === "1212" ? "" : shipping.zipCode}
                              onChange={(e) => handleFieldChange(e, "shipping")}
                              className="w-full rounded-md border border-slate-200 bg-white px-3.5 py-2.5 text-xs font-medium text-slate-800 shadow-xs focus:border-indigo-600 focus:outline-hidden font-mono"
                              placeholder="e.g. 1212"
                            />
                          </div>
                        </div>
                      </>
                    ) : (
                      <div className="sm:col-span-2 rounded-xl border border-indigo-100 bg-indigo-50/50 p-4.5 space-y-2">
                        <p className="text-[11px] font-bold text-indigo-950 uppercase tracking-widest flex items-center gap-1.5">
                          <Check className="h-4 w-4 text-indigo-600 shrink-0" />
                          নিজে এসে সংগ্রহের সুবিধা অ্যাক্টিভ!
                        </p>
                        <p className="text-[10px] text-slate-600 leading-relaxed font-normal">
                          আপনি সরাসরি আমাদের দোকানে এসে কাপড় দেখে, নিখুঁতভাবে আপনার সুবিধামত যাচাই-বাছাই করে পছন্দ অনুযায়ী সব কাপড় নিজে নিয়ে যেতে পারবেন। কোনো অগ্রিম ঠিকানার বা বাড়তি ডেলিভারি ফি-এর একেবারেই প্রয়োজন নেই!
                        </p>
                        <p className="text-[9px] text-indigo-500 font-bold uppercase tracking-wider font-mono">
                          * Order Booking will be processed with your Name & Phone.
                        </p>
                      </div>
                    )}

                    <div className="sm:col-span-2">
                      <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-500 mb-1">
                        Special Delivery Instructions / বাড়তি কোনো তথ্য বা বিবরণ (Optional)
                      </label>
                      <textarea
                        id="shipping-notes"
                        name="notes"
                        value={shipping.notes || ""}
                        onChange={(e) => handleFieldChange(e, "shipping")}
                        className="w-full rounded-md border border-slate-200 bg-white px-3.5 py-2.5 text-xs font-medium text-slate-800 shadow-xs focus:border-indigo-600 focus:outline-hidden min-h-[60px]"
                        placeholder="আপনার অর্ডার সংক্রান্ত বাড়তি যেকোনো নির্দেশনা বা অন্যান্য প্রয়োজনীয় তথ্য এখানে দিন..."
                      />
                    </div>
                  </div>
                </div>
              )}

              {step === 2 && (
                <div className="space-y-6">
                  <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                    <h4 className="text-xs font-bold uppercase tracking-wider text-slate-900">
                      ২. পেমেন্ট পদ্ধতি নির্বাচন // Choose Order/Payment Method
                    </h4>
                  </div>

                  {/* Payment selection tabs */}
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-2.5 pb-2">
                    {/* COD Option */}
                    <button
                      id="opt-method-direct"
                      type="button"
                      onClick={() => setPaymentMethod("direct")}
                      className={`p-3 rounded-xl border text-left flex flex-col gap-1 transition-all cursor-pointer ${
                        paymentMethod === "direct"
                          ? "border-emerald-500 bg-emerald-50/50 ring-2 ring-emerald-500/10"
                          : "border-slate-200 bg-white hover:border-slate-300"
                      }`}
                    >
                      <span className="text-[9px] font-black uppercase tracking-wider text-emerald-800">
                        COD
                      </span>
                      <span className="text-[10px] font-bold text-slate-900">ক্যাশ অন ডেলিভারি</span>
                      <p className="text-[8px] text-slate-400 font-normal leading-none mt-0.5">পণ্য পেয়ে দিন</p>
                    </button>

                    {/* bKash Option */}
                    <button
                      id="opt-method-bkash"
                      type="button"
                      onClick={() => setPaymentMethod("bkash")}
                      className={`p-3 rounded-xl border text-left flex flex-col gap-1 transition-all cursor-pointer ${
                        paymentMethod === "bkash"
                          ? "border-pink-500 bg-pink-50/50 ring-2 ring-pink-500/10"
                          : "border-slate-200 bg-white hover:border-slate-300"
                      }`}
                    >
                      <span className="text-[9px] font-black uppercase tracking-wider text-pink-700 font-mono">
                        bKash Quick
                      </span>
                      <span className="text-[10px] font-bold text-slate-900 flex items-center gap-1">
                        বিকাশ ওয়ালেট
                      </span>
                      <p className="text-[8px] text-slate-400 font-normal leading-none mt-0.5">মাইলফলক ইনস্ট্যান্ট</p>
                    </button>

                    {/* Nagad Option */}
                    <button
                      id="opt-method-nagad"
                      type="button"
                      onClick={() => setPaymentMethod("nagad")}
                      className={`p-3 rounded-xl border text-left flex flex-col gap-1 transition-all cursor-pointer ${
                        paymentMethod === "nagad"
                          ? "border-orange-500 bg-orange-50/50 ring-2 ring-orange-500/10"
                          : "border-slate-200 bg-white hover:border-slate-300"
                      }`}
                    >
                      <span className="text-[9px] font-black uppercase tracking-wider text-orange-700 font-mono">
                        Nagad Fast
                      </span>
                      <span className="text-[10px] font-bold text-slate-900">নগদ অ্যাকাউন্ট</span>
                      <p className="text-[8px] text-slate-400 font-normal leading-none mt-0.5">সহজ ও দ্রুত পেমেন্ট</p>
                    </button>

                    {/* Card Option */}
                    <button
                      id="opt-method-card"
                      type="button"
                      onClick={() => setPaymentMethod("card")}
                      className={`p-3 rounded-xl border text-left flex flex-col gap-1 transition-all cursor-pointer ${
                        paymentMethod === "card"
                          ? "border-indigo-500 bg-indigo-50/50 ring-2 ring-indigo-500/10"
                          : "border-slate-200 bg-white hover:border-slate-300"
                      }`}
                    >
                      <span className="text-[9px] font-black uppercase tracking-wider text-indigo-805 font-mono">
                        Stripe Card
                      </span>
                      <span className="text-[10px] font-bold text-slate-900">কার্ড পেমেন্ট</span>
                      <p className="text-[8px] text-slate-400 font-normal leading-none mt-0.5">নিরাপদ ও আন্তর্জাতিক</p>
                    </button>
                  </div>

                  {/* COD Layout */}
                  {paymentMethod === "direct" && (
                    <div className="rounded-xl border border-emerald-100 bg-emerald-50/20 p-5 space-y-3">
                      <div className="flex items-center gap-2">
                        <div className="bg-emerald-100 p-1.5 rounded-lg text-emerald-600 shrink-0">
                          <Check className="h-4 w-4" />
                        </div>
                        <div>
                          <p className="text-[10px] font-extrabold text-emerald-950 uppercase tracking-wider">
                            সরাসরি অর্ডারের জন্য প্রস্তুত! // Cash On Delivery Enabled
                          </p>
                          <p className="text-[10px] text-slate-500 font-normal">
                            হাতে পেয়ে মূল্য পরিশোধ করার ক্যাশ অন ডেলিভারি সুবিধা। কোনো ক্রেডিট কার্ডের প্রয়োজন নেই।
                          </p>
                        </div>
                      </div>
                      <ul className="text-[10px] text-slate-600 space-y-1.5 pl-2.5 border-l-2 border-emerald-300 font-medium">
                        <li>• <strong>গ্রাহকের নাম:</strong> {shipping.fullName}</li>
                        <li>• <strong>মোবাইল নম্বর:</strong> <span className="font-mono">{shipping.phone || "Not specified"}</span></li>
                        <li>• <strong>ঠিকানার বিবরণ:</strong> {deliveryMethod === "pickup" ? "সংগ্রহ করা হবে সরাসরি দোকান থেকে" : `${shipping.street}, ${shipping.city}`}</li>
                      </ul>
                    </div>
                  )}

                  {/* bKash Layout */}
                  {paymentMethod === "bkash" && (
                    <div className="rounded-xl border border-pink-100 bg-pink-50/10 p-5 space-y-4">
                      <div className="flex items-center gap-3 bg-pink-500/10 p-3 rounded-lg border border-pink-200">
                        <Smartphone className="h-6 w-6 text-pink-600 shrink-0" />
                        <div>
                          <p className="text-[11px] font-bold text-pink-900 uppercase tracking-wider font-mono">
                            bKash Merchant Account Number
                          </p>
                          <p className="text-xs font-mono font-bold text-pink-600 tracking-wider">
                            Personal/Merchant: +880 1871-731341
                          </p>
                        </div>
                      </div>

                      <div className="p-3 bg-slate-50 rounded-lg text-[10px] text-slate-500 border border-slate-100 leading-relaxed font-normal">
                        অনুরগ্রহ করে উপরে উল্লেখিত বিকাশ নম্বরে ক্যাশ আউট অথবা সেন্ডমানি করে নিচে আপনার বিকাশ নম্বর এবং ট্রানজেকশন আইডি (TxID) প্রদান করুন।
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div>
                          <label className="block text-[10px] font-bold uppercase tracking-wider text-pink-800 mb-1">
                            Your bKash Wallet Number / আপনার বিকাশ নম্বর <span className="text-rose-500">*</span>
                          </label>
                          <input
                            id="bkash-num-input"
                            type="text"
                            value={bkashNumber}
                            onChange={(e) => setBkashNumber(e.target.value)}
                            className="w-full rounded-md border border-slate-200 bg-white px-3.5 py-2 text-xs font-medium text-slate-800 shadow-xs focus:border-pink-500 focus:outline-hidden font-mono"
                            placeholder="01XXXXXXXXX"
                          />
                        </div>
                        <div>
                          <label className="block text-[10px] font-bold uppercase tracking-wider text-pink-800 mb-1">
                            bKash Transaction ID (TxID) / ট্রানজেকশন আইডি <span className="text-rose-500">*</span>
                          </label>
                          <input
                            id="bkash-txid-input"
                            type="text"
                            value={bkashTxid}
                            onChange={(e) => setBkashTxid(e.target.value)}
                            className="w-full rounded-md border border-slate-200 bg-white px-3.5 py-2 text-xs font-medium text-slate-800 shadow-xs focus:border-pink-500 focus:outline-hidden font-mono"
                            placeholder="e.g. TR6XAW99"
                          />
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Nagad Layout */}
                  {paymentMethod === "nagad" && (
                    <div className="rounded-xl border border-orange-100 bg-orange-50/10 p-5 space-y-4">
                      <div className="flex items-center gap-3 bg-orange-500/10 p-3 rounded-lg border border-orange-200">
                        <Smartphone className="h-6 w-6 text-orange-600 shrink-0" />
                        <div>
                          <p className="text-[11px] font-bold text-orange-900 uppercase tracking-wider font-mono">
                            Nagad Merchant Account Number
                          </p>
                          <p className="text-xs font-mono font-bold text-orange-600 tracking-wider">
                            Account: +880 1871-731341
                          </p>
                        </div>
                      </div>

                      <div className="p-3 bg-slate-50 rounded-lg text-[10px] text-slate-500 border border-slate-100 leading-relaxed font-normal">
                        অনুরগ্রহ করে নগদ নম্বরে পেমেন্ট সম্পূর্ণ করে নিচে আপনার মোবাইল নম্বর এবং নগদ ট্রানজেকশন আইডি (TxID) টাইপ করুন।
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div>
                          <label className="block text-[10px] font-bold uppercase tracking-wider text-orange-850 mb-1">
                            Your Nagad Wallet Number / আপনার নগদ নম্বর <span className="text-rose-500">*</span>
                          </label>
                          <input
                            id="nagad-num-input"
                            type="text"
                            value={nagadNumber}
                            onChange={(e) => setNagadNumber(e.target.value)}
                            className="w-full rounded-md border border-slate-200 bg-white px-3.5 py-2 text-xs font-medium text-slate-800 shadow-xs focus:border-orange-500 focus:outline-hidden font-mono"
                            placeholder="01XXXXXXXXX"
                          />
                        </div>
                        <div>
                          <label className="block text-[10px] font-bold uppercase tracking-wider text-orange-850 mb-1">
                            Nagad Transaction ID (TxID) / ট্রানজেকশন আইডি <span className="text-rose-500">*</span>
                          </label>
                          <input
                            id="nagad-txid-input"
                            type="text"
                            value={nagadTxid}
                            onChange={(e) => setNagadTxid(e.target.value)}
                            className="w-full rounded-md border border-slate-200 bg-white px-3.5 py-2 text-xs font-medium text-slate-805 shadow-xs focus:border-orange-500 focus:outline-hidden font-mono"
                            placeholder="e.g. NG7ASV99"
                          />
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Card Layout */}
                  {paymentMethod === "card" && (
                    <div className="space-y-4">
                      <div>
                        <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1.5">
                          Cardholder Name
                        </label>
                        <input
                          id="payment-cardName"
                          type="text"
                          name="cardName"
                          value={payment.cardName}
                          onChange={(e) => handleFieldChange(e, "payment")}
                          className="w-full rounded-md border border-slate-200 bg-white px-3.5 py-2.5 text-xs font-medium text-slate-800 shadow-xs focus:border-indigo-600 focus:outline-hidden font-sans"
                          placeholder="Johnathan Doe"
                        />
                      </div>
                      <div>
                        <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1.5 font-mono">
                          Stripe Digital Card Number
                        </label>
                        <input
                          id="payment-cardNumber"
                          type="text"
                          name="cardNumber"
                          value={payment.cardNumber}
                          onChange={(e) => handleFieldChange(e, "payment")}
                          className="w-full rounded-md border border-slate-200 bg-white px-3.5 py-2.5 text-xs font-medium text-slate-800 shadow-xs focus:border-indigo-600 focus:outline-hidden font-mono"
                          placeholder="4111 2222 3333 4444"
                        />
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1.5">
                            Expiration (MM/YY)
                          </label>
                          <input
                            id="payment-expiryDate"
                            type="text"
                            name="expiryDate"
                            value={payment.expiryDate}
                            onChange={(e) => handleFieldChange(e, "payment")}
                            className="w-full rounded-md border border-slate-200 bg-white px-3.5 py-2.5 text-xs font-medium text-slate-800 shadow-xs focus:border-indigo-600 focus:outline-hidden font-mono"
                            placeholder="09/30"
                          />
                        </div>
                        <div>
                          <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1.5">
                            CVV Number
                          </label>
                          <input
                            id="payment-cvv"
                            type="password"
                            name="cvv"
                            value={payment.cvv}
                            onChange={(e) => handleFieldChange(e, "payment")}
                            maxLength={4}
                            className="w-full rounded-md border border-slate-200 bg-white px-3.5 py-2.5 text-xs font-medium text-slate-800 shadow-xs focus:border-indigo-600 focus:outline-hidden font-mono"
                            placeholder="•••"
                          />
                        </div>
                      </div>

                      <div className="rounded-xl bg-slate-50 border border-slate-150 p-4 flex gap-3">
                        <ShieldCheck className="h-5 w-5 text-emerald-600 shrink-0 mt-0.5" />
                        <div className="space-y-0.5 animate-pulse">
                          <p className="text-[10px] font-bold text-slate-800 uppercase tracking-wider">
                            Encrypted Stripe Virtual Gateway
                          </p>
                          <p className="text-[10px] text-slate-400 leading-normal font-normal">
                            Your credentials are securely sent straight to Stripe servers via 256-bit AES-encrypted token routes. We never store local logs.
                          </p>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              )}

              {step === 3 && (
                <div className="space-y-6">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-slate-900">
                    {language === "en" ? "Review and Finalize Your Shipment" : "অর্ডারের বিবরণ ও কনফার্মেশন"}
                  </h4>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {/* Shipping Recap */}
                    <div className="rounded-xl border border-slate-100 bg-slate-50/50 p-4 space-y-2">
                      <h5 className="text-[10px] font-extrabold text-slate-400 uppercase tracking-widest border-b border-slate-150 pb-1.5">
                        {language === "en" ? "Delivery Method & Address" : "ডেলিভারি ঠিকানা ও পদ্ধতি"}
                      </h5>
                      <div className="space-y-1.5 text-xs text-slate-705">
                        <p className="font-bold text-slate-850">{shipping.fullName}</p>
                        <p className="text-emerald-605 font-bold font-mono text-[11px]">{shipping.phone || "No phone provided"}</p>
                        
                        <div className="pt-1.5 pb-1">
                          {deliveryMethod === "pickup" ? (
                            <div className="inline-block rounded-md bg-indigo-50 border border-indigo-200 p-2 text-indigo-950 font-normal">
                              <span className="font-black text-[10px] uppercase text-indigo-700 block mb-0.5">সংগ্রহ পদ্ধতি:</span>
                              নিজে এসে নিয়ে যাওয়া (দোকানে দেখে যাচাই-বাছাই করা যাবে)
                            </div>
                          ) : (
                            <div className="inline-block rounded-md bg-amber-50 border border-amber-200 p-2 text-amber-950 font-normal">
                              <span className="font-black text-[10px] uppercase text-amber-700 block mb-0.5">সংগ্রহ পদ্ধতি:</span>
                              হোম ডেলিভারি (অগ্রণী বা কুরিয়ার যোগে ডেলিভারি)
                            </div>
                          )}
                        </div>

                        {deliveryMethod === "delivery" && (
                          <>
                            <p className="font-medium text-slate-600">{shipping.street}</p>
                            <p className="font-medium text-slate-605">
                              {shipping.city}, {shipping.state} {shipping.zipCode}
                            </p>
                          </>
                        )}
                        <p className="text-[10px] text-slate-400 mt-1.5 flex items-center gap-1.5 font-semibold font-mono">
                          <Mail className="h-3 w-3" />
                          {shipping.email}
                        </p>
                        {shipping.notes && (
                          <div className="bg-slate-100 p-2 rounded-lg text-[10px] text-slate-500 mt-2 italic font-normal">
                            Note: &ldquo;{shipping.notes}&rdquo;
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Payment Recap */}
                    <div className="rounded-xl border border-slate-100 bg-slate-50/50 p-4 space-y-2">
                      <h5 className="text-[10px] font-extrabold text-slate-400 uppercase tracking-widest border-b border-slate-150 pb-1.5">
                        {language === "en" ? "Selected Payment Method" : "নির্বাচিত পেমেন্ট গেটওয়ে"}
                      </h5>
                      <div className="space-y-1 text-xs text-slate-700">
                        {paymentMethod === "direct" && (
                          <div className="space-y-1">
                            <span className="font-extrabold text-emerald-700 uppercase tracking-wide text-[9px] bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded inline-block">
                              Cash on Delivery / ক্যাশ অন ডেলিভারি
                            </span>
                            <p className="text-[10px] text-slate-400 leading-normal font-normal">
                              অর্ডার বুকিং নিশ্চিত করা হবে। কাস্টমার সার্ভিস থেকে আপনাকে ভেরিফিকেশন কল করা হবে।
                            </p>
                          </div>
                        )}

                        {paymentMethod === "bkash" && (
                          <div className="space-y-1">
                            <span className="font-extrabold text-pink-700 uppercase tracking-wide text-[9px] bg-pink-50 border border-pink-200 px-2 py-0.5 rounded inline-block font-mono">
                              bKash Mobile Wallet
                            </span>
                            <p className="font-bold text-slate-800">বিকাশ ওয়ালেট: <span className="font-mono">{bkashNumber}</span></p>
                            <p className="font-mono text-slate-500 text-[11px]">TxID: {bkashTxid}</p>
                          </div>
                        )}

                        {paymentMethod === "nagad" && (
                          <div className="space-y-1">
                            <span className="font-extrabold text-orange-700 uppercase tracking-wide text-[9px] bg-orange-50 border border-orange-200 px-2 py-0.5 rounded inline-block font-mono">
                              Nagad Secure Mobile
                            </span>
                            <p className="font-bold text-slate-850">নগদ নম্বর: <span className="font-mono">{nagadNumber}</span></p>
                            <p className="font-mono text-slate-500 text-[11px]">TxID: {nagadTxid}</p>
                          </div>
                        )}

                        {paymentMethod === "card" && (
                          <div className="space-y-1">
                            <span className="font-extrabold text-indigo-700 uppercase tracking-wide text-[9px] bg-indigo-50 border border-indigo-200 px-2 py-0.5 rounded inline-block font-mono">
                              Stripe Credit Card
                            </span>
                            <p className="font-bold text-slate-800">{payment.cardName}</p>
                            <p className="font-mono text-slate-500 text-[11px]">Card: {payment.cardNumber.replace(/\d(?=\d{4})/g, "•")}</p>
                            <p className="text-[10px] text-indigo-500 font-bold uppercase tracking-wider block mt-1.5 animate-pulse">
                              Stripe Authorizer Synced
                            </p>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Summary List */}
                  <div className="divide-y divide-slate-150 rounded-xl border border-slate-200 overflow-hidden font-sans">
                    <div className="p-4 bg-slate-50/50">
                      <h5 className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-2">
                        Summary of Goods ({cartItems.length} items)
                      </h5>
                      <div className="max-h-28 overflow-y-auto space-y-2 pr-1.5">
                        {cartItems.map((item) => {
                          let nameToDisplay = item.product.name;
                          if (language === "bn") {
                            if (item.product.name.includes("Supima Cotton")) nameToDisplay = "সুপিমা লাক্সারি কটন ক্রুনেক গেঞ্জি";
                            else if (item.product.name.includes("Oxford Cotton")) nameToDisplay = "অক্সফোর্ড বাটন-ডাউন কলার শার্ট";
                            else if (item.product.name.includes("Heavyweight Organic")) nameToDisplay = "ভারী সুতি জিপার হুডি জ্যাকেট";
                            else if (item.product.name.includes("Sartorial Classic")) nameToDisplay = "ক্লাসিক ইতালিয়ান ব্লেজার স্যুট";
                            else if (item.product.name.includes("Ribbed Combed")) nameToDisplay = "কম্বড রিঙ্গড আরামদায়ক গেঞ্জি";
                            else if (item.product.name.includes("Linen Silk")) nameToDisplay = "লিলেন সিল্ক ক্লাসিক ক্যাজুয়াল শার্ট";
                            else if (item.product.name.includes("Cashmere Blend")) nameToDisplay = "প্রিমিয়াম কাশ্মীরি ব্লেন্ড ব্লেজার পোশাক";
                          }
                          return (
                            <div key={item.product.id} className="flex justify-between items-center text-xs">
                              <span className="text-slate-600">
                                {nameToDisplay} <strong className="text-slate-400 font-mono">x{item.quantity}</strong>
                              </span>
                              <span className="font-bold text-slate-800 font-mono">
                                {formatPrice(item.product.price * item.quantity)}
                              </span>
                            </div>
                          );
                        })}
                      </div>
                    </div>

                    {/* Cost Calculations */}
                    <div className="p-4 space-y-2 text-xs">
                      <div className="flex justify-between text-slate-500 font-semibold">
                        <span>{language === "en" ? "Combined Subtotal" : "সাবটোটাল মূল্য"}</span>
                        <span className="font-mono">{formatPrice(subtotal)}</span>
                      </div>
                      <div className="flex justify-between text-slate-500 font-semibold">
                        <span>{language === "en" ? "Eco-Freight Delivery" : "ডেলিভারি চার্জ"}</span>
                        <span className="font-mono">{carbonShipping === 0 ? t("cart.free") : formatPrice(25)}</span>
                      </div>
                      <div className="flex justify-between text-slate-500 font-semibold">
                        <span>{language === "en" ? "VAT (8.25%)" : "ভ্যাট ও ট্যাক্স (৮.২৫%)"}</span>
                        <span className="font-mono">{formatPrice(mockTax)}</span>
                      </div>
                      <div className="border-t border-slate-200 pt-2 flex justify-between text-sm font-black text-slate-900 uppercase tracking-wide">
                        <span>{language === "en" ? "Grand Total" : "সর্বমোট বকেয়া"}</span>
                        <span className="font-mono text-indigo-650 text-indigo-600 font-bold">{formatPrice(subtotal + carbonShipping + mockTax)}</span>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {step === 4 && (
                <div className="py-8 text-center space-y-6 max-w-md mx-auto font-sans">
                  <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-full bg-emerald-50 border border-emerald-200">
                    <Check className="h-6 w-6 text-emerald-600" />
                  </div>

                  <div className="space-y-2 text-center">
                    <h4 className="text-sm font-extrabold text-slate-900 uppercase tracking-widest flex items-center justify-center gap-1.5">
                      <Sparkles className="h-4.5 w-4.5 text-amber-500 animate-pulse" />
                      {language === "en" ? "Order Locked & Confirmed!" : "অর্ডার সফলভাবে বুকিং করা হয়েছে!"}
                    </h4>
                    <p className="text-xs text-slate-400 max-w-sm mx-auto leading-relaxed font-normal">
                      {language === "en" ? "Thank you for shopping. Your order dispatch tracking coordinates have been locked into our system database." : "ধন্যবাদ! আমাদের টিম আপনার অর্ডারটি সিস্টেমে নথিভুক্ত করেছে। অত্যন্ত দ্রুত আমাদের কাস্টমার ম্যানেজার আপনাকে নিশ্চিতকরণের জন্য কল করবেন।"}
                    </p>
                  </div>

                  {/* Receipt block */}
                  <div className="rounded-xl border border-slate-200 p-5 bg-slate-50 text-left space-y-4">
                    <div className="flex justify-between border-b border-slate-200 pb-3">
                      <div>
                        <span className="text-[9px] font-bold text-slate-400 uppercase tracking-wider block">
                          Tracking ID / ট্র্যাকিং আইডি
                        </span>
                        <span className="text-xs font-mono font-bold text-indigo-650 block">
                          {orderId}
                        </span>
                      </div>
                      <div className="text-right">
                        <span className="text-[9px] font-bold text-slate-400 uppercase tracking-wider block">
                          Total Amount Paid / মোট বিল
                        </span>
                        <span className="text-xs font-bold text-slate-900 block font-mono">
                          {formatPrice(totalAmount)}
                        </span>
                      </div>
                    </div>

                    <div className="space-y-3">
                      <span className="text-[9px] font-extrabold text-slate-400 uppercase tracking-widest block">
                        Estimated Dispatch Stages / ডেলিভারি পর্যায়
                      </span>

                      <div className="relative pl-6 space-y-4">
                        {/* vertical line */}
                        <div className="absolute left-1.5 top-1 bottom-1 w-0.5 bg-slate-200" />

                        {/* Node 1 */}
                        <div className="relative">
                          <Check className="absolute -left-6 top-0.5 h-3.5 w-3.5 rounded-full bg-emerald-600 p-0.5 text-white" />
                          <p className="text-[11px] font-bold text-slate-800">Order Booking Processing</p>
                          <p className="text-[9px] text-slate-405 font-semibold mb-0">AURA Archive Warehouse</p>
                        </div>

                        {/* Node 2 */}
                        <div className="relative">
                          <span className="absolute -left-5 top-1 h-1.5 w-1.5 rounded-full bg-indigo-600 animate-pill" />
                          <p className="text-[11px] font-bold text-slate-800">Quality Checklist & Pack</p>
                          <p className="text-[9px] text-slate-405 font-semibold mb-0">Scheduled dispatch within 24 hours</p>
                        </div>

                        {/* Node 3 */}
                        <div className="relative">
                          <span className="absolute -left-5 top-1 h-1.5 w-1.5 rounded-full bg-slate-200" />
                          <p className="text-[11px] font-bold text-slate-800">Eco-Freight Carrier Cargo Transit</p>
                          <p className="text-[9px] text-slate-450 font-semibold mb-0">To Chittagong, Dhaka or Countrywide</p>
                        </div>
                      </div>
                    </div>

                    <div className="pt-3 border-t border-slate-200 flex items-start gap-2.5">
                      <Calendar className="h-4 w-4 text-indigo-650 shrink-0 mt-0.5" />
                      <div className="space-y-0.5">
                        <span className="text-[9px] font-bold text-slate-400 uppercase tracking-wider block mb-0.5">
                          Estimated Delivery Time / সম্ভাব্য ডেলিভারি
                        </span>
                        <span className="text-xs font-bold text-slate-800 block">
                          {deliveryDate}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Direct Contact / Follow-up triggers */}
                  <div className="space-y-4 border-t border-slate-200 pt-5 text-left font-sans">
                    <p className="text-[10px] font-extrabold text-slate-400 uppercase tracking-widest">
                      অর্ডার ট্র্যাক করতে সরাসরি যোগাযোগ করুন // Tracker Follow-up Channels
                    </p>
                    <div className="flex flex-col sm:flex-row gap-2">
                      <a
                        id="success-whatsapp-btn"
                        href={`https://wa.me/8801871731341?text=${encodeURIComponent(
                          `Hello Model Team!\nI have placed an order directly via your store app:\n\n` +
                          `Order ID: ${orderId}\n` +
                          `Customer Name: ${shipping.fullName}\n` +
                          `Mobile: ${shipping.phone || "Not provided"}\n` +
                          `Payment Gateway: ${paymentMethod === "direct" ? "Cash On Delivery" : paymentMethod === "bkash" ? `bKash Wallet: ${bkashNumber} (TxId: ${bkashTxid})` : paymentMethod === "nagad" ? `Nagad Wallet: ${nagadNumber} (TxId: ${nagadTxid})` : "Stripe Card"}\n\n` +
                          `Items Ordered:\n` +
                          cartItems.map(item => `• ${item.product.name} (x${item.quantity}) - ${formatPrice(item.product.price * item.quantity)}`).join("\n") +
                          `\n\nGrand Total: ${formatPrice(totalAmount)}\n` +
                          `Special Instructions: ${shipping.notes || "None"}\n\n` +
                          `Please confirm receipt! Thank you.`
                        )}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex-1 flex items-center justify-center gap-2 rounded-lg bg-emerald-600 hover:bg-emerald-700 py-3 text-xs font-bold uppercase tracking-wider text-white shadow-xs transition-colors cursor-pointer"
                      >
                        <MessageSquare className="h-3.5 w-3.5" />
                        Send order details to WhatsApp
                      </a>
                      <a
                        id="success-facebook-btn"
                        href="https://www.facebook.com/itzashiqvai999"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex-1 flex items-center justify-center gap-2 rounded-lg bg-blue-600 hover:bg-blue-700 py-3 text-xs font-bold uppercase tracking-wider text-white shadow-xs transition-colors cursor-pointer"
                      >
                        <Facebook className="h-3.5 w-3.5" />
                        Message on Facebook
                      </a>
                    </div>

                    {/* Secondary Channel Matrix Grid */}
                    <div className="space-y-2">
                      <span className="text-[9px] font-bold text-slate-400 uppercase tracking-wider block">
                        Our Other Social Networks / অন্যান্য সামাজিক যোগাযোগ মাধ্যম
                      </span>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                        {/* TikTok button */}
                        <a
                          id="success-tiktok-btn"
                          href="https://www.tiktok.com/@gamingmuribaba?lang=en"
                          target="_blank"
                          rel="noopener noreferrer"
                          className="flex items-center gap-2 rounded-lg border border-slate-200 bg-white hover:border-slate-350 p-2 text-[11px] font-bold text-slate-800 transition-colors cursor-pointer"
                        >
                          <span className="p-1 rounded-md bg-slate-900 text-white shrink-0">
                            <Gamepad2 className="h-3.5 w-3.5" />
                          </span>
                          <div className="flex-1 min-w-0">
                            <span className="block text-slate-900 truncate">TikTok: @gamingmuribaba</span>
                            <span className="block text-[9px] text-slate-400 font-normal">আমাদের টিকটক প্রোফাইল</span>
                          </div>
                        </a>

                        {/* YouTube button */}
                        <a
                          id="success-youtube-btn"
                          href="https://www.youtube.com/channel/UCk1LD7EKbDd3ZQiFKo0OYpA"
                          target="_blank"
                          rel="noopener noreferrer"
                          className="flex items-center gap-2 rounded-lg border border-slate-200 bg-white hover:border-slate-350 p-2 text-[11px] font-bold text-slate-800 transition-colors cursor-pointer"
                        >
                          <span className="p-1 rounded-md bg-rose-600 text-white shrink-0">
                            <Youtube className="h-3.5 w-3.5" />
                          </span>
                          <div className="flex-1 min-w-0">
                            <span className="block text-slate-900 truncate">YouTube Channel</span>
                            <span className="block text-[9px] text-slate-400 font-normal">আমাদের অফিশিয়াল ইউটিউব</span>
                          </div>
                        </a>

                        {/* Discord button */}
                        <a
                          id="success-discord-btn"
                          href="https://discord.gg/sN4qwhtWsy"
                          target="_blank"
                          rel="noopener noreferrer"
                          className="flex items-center gap-2 rounded-lg border border-slate-200 bg-white hover:border-slate-350 p-2 text-[11px] font-bold text-slate-800 transition-all cursor-pointer"
                        >
                          <span className="p-1 rounded-md bg-indigo-600 text-white shrink-0">
                            <Users className="h-3.5 w-3.5" />
                          </span>
                          <div className="flex-1 min-w-0">
                            <span className="block text-slate-900 truncate">Discord Server</span>
                            <span className="block text-[9px] text-slate-400 font-normal">ডিসকর্ড জয়েন করুন</span>
                          </div>
                        </a>

                        {/* Telegram button */}
                        <a
                          id="success-telegram-btn"
                          href="https://t.me/uStweqRmfBthNzI1"
                          target="_blank"
                          rel="noopener noreferrer"
                          className="flex items-center gap-2 rounded-lg border border-slate-200 bg-white hover:border-slate-350 p-2 text-[11px] font-bold text-slate-800 transition-all cursor-pointer"
                        >
                          <span className="p-1 rounded-md bg-sky-500 text-white shrink-0">
                            <Send className="h-3.5 w-3.5" />
                          </span>
                          <div className="flex-1 min-w-0">
                            <span className="block text-slate-900 truncate">Telegram Feed</span>
                            <span className="block text-[9px] text-slate-400 font-normal">টেলিগ্রাম চ্যানেল</span>
                          </div>
                        </a>

                        {/* Discord Server Free Panel button */}
                        <a
                          id="success-freepanel-btn"
                          href="https://discord.gg/KMPyQ5QJHR"
                          target="_blank"
                          rel="noopener noreferrer"
                          className="sm:col-span-2 flex items-center gap-2 rounded-lg border border-teal-200 bg-teal-50/25 hover:border-teal-350 p-2 text-[11px] font-bold text-slate-800 transition-all cursor-pointer"
                        >
                          <span className="p-1 rounded-md bg-teal-600 text-white shrink-0">
                            <Cpu className="h-3.5 w-3.5" />
                          </span>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-1.5">
                              <span className="block text-teal-905 font-extrabold truncate">Discord Server Free Panel</span>
                              <span className="text-[8px] bg-teal-600 text-white font-black uppercase px-1 rounded-sm tracking-widest animate-pulse leading-none py-0.5 font-mono">FREE</span>
                            </div>
                            <span className="block text-[9px] text-teal-700 font-normal">আমাদের বিশেষ ডিসকর্ড সার্ভার ফ্রি প্যানেল</span>
                          </div>
                        </a>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Footer Form Navigation buttons */}
            {step < 4 && (
              <div className="sticky bottom-0 z-15 border-t border-slate-200 bg-slate-50 px-6 py-4 flex justify-between items-center bg-white shrink-0">
                {step > 1 ? (
                  <button
                    id="step-prev-btn"
                    onClick={handlePrevStep}
                    className="flex items-center gap-1 text-xs font-semibold uppercase tracking-wider text-slate-500 hover:text-slate-900 transition-colors cursor-pointer"
                  >
                    <ArrowLeft className="h-3.5 w-3.5" />
                    Back
                  </button>
                ) : (
                  <div />
                )}

                <button
                  id="checkout-advance-btn"
                  onClick={handleNextStep}
                  disabled={!isFormValid()}
                  className={`flex items-center gap-1.5 rounded-lg px-5 py-2.5 text-xs font-bold uppercase tracking-wider text-white shadow-sm transition-all cursor-pointer ${
                    isFormValid()
                      ? "bg-indigo-600 hover:bg-indigo-700 active:scale-95"
                      : "bg-slate-200 !text-slate-400 pointer-events-none"
                  }`}
                >
                  {step === 3 ? "Authorize & Submit Order" : "Continue"}
                  {step < 3 && <ArrowRight className="h-3.5 w-3.5" />}
                </button>
              </div>
            )}
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};

import React, { useState, useEffect } from "react";
import { X, Check, Search, ShieldCheck, Lock, LogOut, PackageCheck, ClipboardList, TrendingUp, Sparkles, UserCheck, FileText } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { 
  googleSignIn, 
  googleSignOut, 
  initAuth, 
  createInvoiceDocument 
} from "../lib/workspace";

interface OrderItem {
  product: {
    id: string;
    name: string;
    price: number;
    image: string;
    category: string;
  };
  quantity: number;
}

interface Order {
  id: string;
  shipping: {
    fullName: string;
    email: string;
    phone?: string;
    street: string;
    city: string;
    state: string;
    zipCode: string;
    notes?: string;
  };
  deliveryMethod?: "pickup" | "delivery";
  items: OrderItem[];
  total: number;
  date: string;
  status: "Pending" | "Confirmed";
}

interface StaffDeskModalProps {
  isOpen: boolean;
  onClose: () => void;
  onToast: (text: string, type: "success" | "info" | "heart") => void;
}

// Prepopulate some realistic clothing orders if none exist
const INITIAL_MOCK_ORDERS: Order[] = [
  {
    id: "AUR-832104",
    shipping: {
      fullName: "Savina Akhtar",
      email: "savinaakhtargal@gmail.com",
      phone: "01712345678",
      street: "House 45, Road 11, Banani",
      city: "Dhaka",
      state: "Dhaka Division",
      zipCode: "1213",
      notes: "Please call 30 minutes before delivery."
    },
    items: [
      {
        product: {
          id: "prod_4",
          name: "Ora Bespoke Sartorial Wool Suit",
          price: 780,
          image: "https://images.unsplash.com/photo-1594938298603-c8148c4dae35?auto=format&fit=crop&w=800&q=80",
          category: "Suits"
        },
        quantity: 1
      },
      {
        product: {
          id: "prod_1",
          name: "Aura Premium Heavyweight Cotton Tee",
          price: 65,
          image: "https://images.unsplash.com/photo-1521572267360-ee0c2909d518?auto=format&fit=crop&w=800&q=80",
          category: "Tees & Vests"
        },
        quantity: 1
      }
    ],
    total: 915,
    date: "Jun 3, 2026, 11:15 AM",
    status: "Pending"
  },
  {
    id: "AUR-290155",
    shipping: {
      fullName: "Rahat Chowdhury",
      email: "rahat.c@yahoo.com",
      phone: "01855998822",
      street: "Flat 4B, Shahi Eidgah",
      city: "Sylhet",
      state: "Sylhet Division",
      zipCode: "3100",
      notes: "Leave with security if not home"
    },
    items: [
      {
        product: {
          id: "prod_3",
          name: "Aura Tailored Poplin Linen Shirt",
          price: 135,
          image: "https://images.unsplash.com/photo-1596755094514-f87e34085b2c?auto=format&fit=crop&w=800&q=80",
          category: "Shirts"
        },
        quantity: 1
      },
      {
        product: {
          id: "prod_2",
          name: "Ora Ribbed Fitted Gengi Vest",
          price: 38,
          image: "https://images.unsplash.com/photo-1503342217505-b0a15ec3261c?auto=format&fit=crop&w=800&q=80",
          category: "Tees & Vests"
        },
        quantity: 2
      }
    ],
    total: 236,
    date: "Jun 3, 2026, 02:40 PM",
    status: "Pending"
  },
  {
    id: "AUR-450912",
    shipping: {
      fullName: "Tanvir Anjum",
      email: "tanvir.anjum@outlook.com",
      phone: "01911445566",
      street: "Halishahar, Ward 11",
      city: "Chittagong",
      state: "Chittagong Division",
      zipCode: "4000"
    },
    items: [
      {
        product: {
          id: "prod_6",
          name: "Ora Smart Technical Stretch Suit",
          price: 520,
          image: "https://images.unsplash.com/photo-1507679799987-c73779587ccf?auto=format&fit=crop&w=800&q=80",
          category: "Suits"
        },
        quantity: 1
      }
    ],
    total: 588,
    date: "Jun 2, 2026, 09:30 AM",
    status: "Confirmed"
  }
];

export const StaffDeskModal: React.FC<StaffDeskModalProps> = ({
  isOpen,
  onClose,
  onToast,
}) => {
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => {
    return localStorage.getItem("aura_staff_session") === "active";
  });
  const [pin, setPin] = useState("");
  const [pinError, setPinError] = useState("");
  const [orders, setOrders] = useState<Order[]>([]);
  const [search, setSearch] = useState("");

  const [googleUser, setGoogleUser] = useState<any>(null);
  const [googleToken, setGoogleToken] = useState<string | null>(null);
  const [isExportingMap, setIsExportingMap] = useState<Record<string, boolean>>({});
  const [exportedDocs, setExportedDocs] = useState<Record<string, string>>(() => {
    const stored = localStorage.getItem("aura_exported_docs");
    return stored ? JSON.parse(stored) : {};
  });

  // Track Google Docs Link auth state
  useEffect(() => {
    const unsubscribe = initAuth(
      (user, token) => {
        setGoogleUser(user);
        setGoogleToken(token);
      },
      () => {
        setGoogleUser(null);
        setGoogleToken(null);
      }
    );
    return () => unsubscribe();
  }, [isOpen]);

  // Load orders from local storage or pre-populate if empty
  useEffect(() => {
    if (isOpen) {
      const stored = localStorage.getItem("aura_orders");
      if (stored) {
        setOrders(JSON.parse(stored));
      } else {
        localStorage.setItem("aura_orders", JSON.stringify(INITIAL_MOCK_ORDERS));
        setOrders(INITIAL_MOCK_ORDERS);
      }
    }
  }, [isOpen]);

  const handleGoogleConnect = async () => {
    try {
      const res = await googleSignIn();
      if (res) {
        setGoogleUser(res.user);
        setGoogleToken(res.accessToken);
        onToast("Linked with Google Docs!", "success");
      }
    } catch (err: any) {
      onToast("Google link was canceled or failed.", "info");
    }
  };

  const handleGoogleDisconnect = async () => {
    await googleSignOut();
    setGoogleUser(null);
    setGoogleToken(null);
    onToast("Disconnected Google Docs successfully.", "info");
  };

  const handleExportToDocs = async (order: Order) => {
    let token = googleToken;
    
    if (!token) {
      const confirmed = window.confirm(
        `Creating Google Docs invoices requires signing in with Google. Would you like to link your account?`
      );
      if (!confirmed) return;
      
      try {
        const res = await googleSignIn();
        if (res) {
          setGoogleUser(res.user);
          setGoogleToken(res.accessToken);
          token = res.accessToken;
          onToast("Linked with Google Docs!", "success");
        } else {
          return;
        }
      } catch (err) {
        onToast("Authentication was cancelled.", "info");
        return;
      }
    }

    if (!token) return;

    setIsExportingMap(prev => ({ ...prev, [order.id]: true }));
    onToast(`Generating Google Doc Invoice for ${order.id}...`, "info");

    try {
      const result = await createInvoiceDocument(order, token);
      
      const updatedDocs = { ...exportedDocs, [order.id]: result.url };
      setExportedDocs(updatedDocs);
      localStorage.setItem("aura_exported_docs", JSON.stringify(updatedDocs));
      
      onToast(`Invoice exported to Google Docs successfully!`, "success");
    } catch (err: any) {
      console.error(err);
      onToast(`Failed to export invoice: ${err.message || err}`, "info");
      if (err.message && err.message.includes("401")) {
        setGoogleToken(null);
        setGoogleUser(null);
      }
    } finally {
      setIsExportingMap(prev => ({ ...prev, [order.id]: false }));
    }
  };

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    // Simple but secure desk code
    if (pin === "AURA2026" || pin === "1234") {
      setIsAuthenticated(true);
      localStorage.setItem("aura_staff_session", "active");
      setPin("");
      setPinError("");
      onToast("Successfully authenticated as Order Desk Staff", "success");
    } else {
      setPinError("Incorrect Clerk PIN. Access Denied.");
      onToast("Authentication failure", "info");
    }
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    localStorage.removeItem("aura_staff_session");
    onToast("Logged out of Order Desk", "info");
  };

  const confirmOrder = (orderId: string) => {
    const updated = orders.map((ord) => {
      if (ord.id === orderId) {
        return { ...ord, status: "Confirmed" as const };
      }
      return ord;
    });
    setOrders(updated);
    localStorage.setItem("aura_orders", JSON.stringify(updated));
    onToast(`Order ${orderId} successfully Confirmed & Dispatched!`, "success");
  };

  // Filter orders
  const filteredOrders = orders.filter((ord) => {
    const term = search.toLowerCase();
    return (
      ord.id.toLowerCase().includes(term) ||
      ord.shipping.fullName.toLowerCase().includes(term) ||
      (ord.shipping.phone && ord.shipping.phone.includes(term)) ||
      ord.shipping.city.toLowerCase().includes(term)
    );
  });

  const pendingCount = orders.filter(o => o.status === "Pending").length;
  const confirmedCount = orders.filter(o => o.status === "Confirmed").length;
  const totalRevenue = orders
    .filter(o => o.status === "Confirmed")
    .reduce((sum, o) => sum + o.total, 0);

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-slate-900/60 backdrop-blur-xs"
          />

          {/* Modal Shell */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 15 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 15 }}
            className="relative z-10 w-full max-w-4xl overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-2xl flex flex-col max-h-[85vh]"
          >
            {/* Header */}
            <div className="flex items-center justify-between border-b border-slate-200 bg-slate-900 px-6 py-4 text-white">
              <div className="flex items-center gap-2.5">
                <ShieldCheck className="h-5 w-5 text-indigo-400 shrink-0" />
                <div>
                  <span className="text-[9px] font-black uppercase tracking-widest text-indigo-300 block">
                    Security Level // AURA Clerk Console
                  </span>
                  <h3 className="text-xs font-black uppercase tracking-widest mt-0.5">
                    Order Confirmation desk
                  </h3>
                </div>
              </div>
              <div className="flex items-center gap-3">
                {isAuthenticated && (
                  <button
                    onClick={handleLogout}
                    className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border border-slate-705 text-[10px] uppercase tracking-wider font-extrabold text-slate-300 hover:bg-slate-800 hover:text-white transition-all cursor-pointer border-slate-700"
                    title="Sign Out"
                  >
                    <LogOut className="h-3 w-3" />
                    <span className="hidden sm:inline">Sign Out</span>
                  </button>
                )}
                <button
                  onClick={onClose}
                  className="flex h-8 w-8 items-center justify-center rounded-full border border-slate-700 text-slate-400 hover:bg-slate-800 hover:text-white transition-colors"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>
            </div>

            {/* Auth screen if not authenticated */}
            {!isAuthenticated ? (
              <div className="p-8 md:p-12 flex flex-col items-center justify-center max-w-sm mx-auto my-8 text-center space-y-6">
                <div className="h-12 w-12 rounded-full bg-slate-100 border border-slate-200 flex items-center justify-center text-slate-900 animate-pulse">
                  <Lock className="h-5 w-5" />
                </div>
                <div className="space-y-1.5">
                  <h4 className="text-sm font-bold uppercase tracking-wider text-slate-900">
                    Clerk Verification Required
                  </h4>
                  <p className="text-[11px] text-slate-500 leading-normal font-normal">
                    This panel is strictly limited to hired clerks tasked solely with order confirmation. Please verify your identity using the clerk credential PIN.
                  </p>
                </div>

                <form onSubmit={handleLogin} className="w-full space-y-3">
                  <div>
                    <input
                      type="password"
                      value={pin}
                      onChange={(e) => setPin(e.target.value)}
                      placeholder="Enter Staff PIN (e.g., AURA2026)"
                      className="w-full text-center tracking-widest font-mono rounded-lg border border-slate-200 bg-slate-50 px-4 py-3 text-sm font-bold text-slate-800 placeholder:text-slate-400 focus:bg-white focus:border-indigo-600 focus:outline-hidden"
                    />
                    {pinError && (
                      <p className="text-[10px] text-rose-500 font-bold mt-1.5 uppercase tracking-wider">
                        {pinError}
                      </p>
                    )}
                  </div>
                  <button
                    type="submit"
                    className="w-full rounded-lg bg-indigo-600 hover:bg-indigo-700 py-3 text-xs font-black uppercase tracking-wider text-white shadow-md active:scale-98 transition-all cursor-pointer"
                  >
                    Authenticate Console
                  </button>
                </form>

                <div className="rounded-lg bg-slate-50 border border-slate-150 p-3 pt-2 text-left">
                  <span className="text-[9px] font-black uppercase tracking-wider text-slate-405 block text-slate-400 mb-0.5">
                    Clerk Instruction Notice
                  </span>
                  <p className="text-[10px] text-slate-500 leading-relaxed font-normal">
                    Clerks may only authenticate and confirm client details. Staff members have absolutely zero access to configure inventory pricing or store archives.
                  </p>
                  <p className="text-[11px] text-indigo-600 font-bold mt-1">
                    👉 Hint for testing: Use pin <strong className="font-mono">AURA2026</strong> or <strong className="font-mono">1234</strong>
                  </p>
                </div>
              </div>
            ) : (
              /* Authenticated Order Manager Panel */
              <div className="flex-1 overflow-y-auto bg-slate-50 flex flex-col min-h-0">
                {/* Dashboard Stats */}
                <div className="grid grid-cols-3 divide-x divide-slate-200 border-b border-slate-200 bg-white">
                  <div className="p-4 flex flex-col items-center justify-center text-center">
                    <ClipboardList className="h-4 w-4 text-amber-500 mb-1" />
                    <span className="text-[9px] font-bold text-slate-450 uppercase tracking-widest select-none text-slate-400">
                      Pending Confirmation
                    </span>
                    <span className="text-xl font-extrabold font-mono text-slate-850 mt-0.5">
                      {pendingCount}
                    </span>
                  </div>

                  <div className="p-4 flex flex-col items-center justify-center text-center">
                    <PackageCheck className="h-4 w-4 text-emerald-500 mb-1" />
                    <span className="text-[9px] font-bold text-slate-450 uppercase tracking-widest select-none text-slate-400">
                      Orders Confirmed
                    </span>
                    <span className="text-xl font-extrabold font-mono text-slate-850 mt-0.5">
                      {confirmedCount}
                    </span>
                  </div>

                  <div className="p-4 flex flex-col items-center justify-center text-center">
                    <TrendingUp className="h-4 w-4 text-indigo-500 mb-1" />
                    <span className="text-[9px] font-bold text-slate-450 uppercase tracking-widest select-none text-slate-400">
                      Sartorial Revenue Log
                    </span>
                    <span className="text-xl font-extrabold font-mono text-indigo-600 mt-0.5">
                      ${totalRevenue.toLocaleString()}
                    </span>
                  </div>
                </div>

                {/* Info guidance block */}
                <div className="px-6 py-2.5 bg-indigo-50 border-b border-indigo-100 flex items-center justify-between gap-4">
                  <div className="flex items-center gap-2 text-indigo-950">
                    <UserCheck className="h-4 w-4 shrink-0 text-indigo-600" />
                    <p className="text-[10px] text-indigo-900 leading-normal font-medium">
                      <strong>Hired Clerk Workspace:</strong> Verify the customer phone registers and address details below. Click &ldquo;Confirm and Dispatch&rdquo; to lock of processing. You cannot delete orders or change catalogs.
                    </p>
                  </div>
                </div>

                {/* Google Docs Connection Status Strip */}
                <div className="px-6 py-3 bg-slate-900 border-b border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-white">
                  <div className="flex items-center gap-2.5">
                    <div className={`h-2.5 w-2.5 rounded-full ${googleUser ? "bg-emerald-500 animate-pulse" : "bg-blue-500 animate-pulse"}`}></div>
                    <div>
                      <p className="text-[10px] uppercase font-black tracking-widest text-indigo-300">Google Docs Workspace Sync</p>
                      {googleUser ? (
                        <p className="text-[11px] font-bold text-emerald-400">
                          Connected as: {googleUser.email}
                        </p>
                      ) : (
                        <p className="text-[11px] text-slate-400 font-normal">
                          Not integrated. Link your Google account to auto-generate beautiful printable Invoice Docs.
                        </p>
                      )}
                    </div>
                  </div>
                  <div>
                    {googleUser ? (
                      <button
                        onClick={handleGoogleDisconnect}
                        className="text-[10px] font-black uppercase tracking-widest bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 px-3 py-1.5 rounded-lg border border-rose-500/20 transition-all cursor-pointer"
                      >
                        Unlink Google
                      </button>
                    ) : (
                      <button
                        onClick={handleGoogleConnect}
                        className="text-[10px] font-black uppercase tracking-widest bg-blue-600 hover:bg-blue-700 text-white px-3.5 py-1.5 rounded-lg transition-all flex items-center gap-1.5 cursor-pointer shadow-xs"
                      >
                        <FileText className="h-3.5 w-3.5" />
                        Link Google Docs
                      </button>
                    )}
                  </div>
                </div>

                {/* Main panel action bar */}
                <div className="p-4 bg-white border-b border-slate-200">
                  <div className="relative max-w-sm">
                    <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
                    <input
                      type="text"
                      value={search}
                      onChange={(e) => setSearch(e.target.value)}
                      placeholder="Search by client name, tracking, phone or city..."
                      className="w-full rounded-lg border border-slate-200 pl-9 pr-4 py-2 text-xs font-semibold text-slate-800 placeholder:text-slate-400 focus:border-indigo-600 focus:outline-hidden"
                    />
                  </div>
                </div>

                {/* Orders scrollable list */}
                <div className="flex-1 p-6 space-y-4">
                  {filteredOrders.length === 0 ? (
                    <div className="bg-white border rounded-xl p-12 text-center text-slate-400 space-y-2">
                      <ClipboardList className="h-8 w-8 mx-auto text-slate-300" />
                      <p className="text-xs font-bold uppercase tracking-wider text-slate-700">No orders cataloged</p>
                      <p className="text-[11px] text-slate-400 leading-relaxed font-normal">
                        No orders matched your search criteria. Placed client checkouts will show up here dynamically.
                      </p>
                    </div>
                  ) : (
                    filteredOrders.map((ord) => (
                      <div
                        key={ord.id}
                        className={`bg-white border rounded-xl shadow-xs overflow-hidden transition-all duration-250 ${
                          ord.status === "Pending"
                            ? "border-amber-150 ring-2 ring-amber-500/5"
                            : "border-slate-200 hover:border-slate-300"
                        }`}
                      >
                        {/* Order info bar */}
                        <div className="bg-slate-50 px-4 py-3 border-b flex flex-wrap items-center justify-between gap-3">
                          <div className="flex items-center gap-2">
                            <span className="text-[10px] font-black font-mono bg-slate-900 text-white px-2 py-0.5 rounded-sm">
                              {ord.id}
                            </span>
                            <span className="text-[10px] text-slate-400 font-semibold">
                              Registered: {ord.date}
                            </span>
                          </div>

                          <div className="flex items-center gap-2">
                            {ord.status === "Pending" ? (
                              <span className="inline-flex items-center gap-1 rounded-full bg-amber-50 border border-amber-200 px-2.5 py-0.5 text-[9px] font-black text-amber-700 uppercase tracking-wider">
                                <span className="h-1.5 w-1.5 rounded-full bg-amber-500 animate-ping mr-0.5" />
                                Awaiting Clerical Ok
                              </span>
                            ) : (
                              <span className="inline-flex items-center gap-1 rounded-full bg-emerald-50 border border-emerald-200 px-2.5 py-0.5 text-[9px] font-black text-emerald-800 uppercase tracking-wider">
                                <Check className="h-3 w-3" />
                                Confirmed & Dispatch Ready
                              </span>
                            )}
                          </div>
                        </div>

                        {/* Customer & Item grids */}
                        <div className="p-4 sm:p-5 grid grid-cols-1 md:grid-cols-12 gap-6">
                          {/* Left: Customer info cards */}
                          <div className="md:col-span-5 space-y-3">
                            <h5 className="text-[10px] font-black text-slate-400 uppercase tracking-widest border-b pb-1">
                              Client Logistics Summary
                            </h5>
                            <div className="space-y-1.5 text-xs text-slate-700">
                              <p className="font-bold text-slate-905">{ord.shipping.fullName}</p>
                              <p className="text-emerald-705 font-extrabold text-[11px] font-mono select-all bg-emerald-50 rounded px-1.5 py-0.5 inline-block">
                                📞 Phone: {ord.shipping.phone || "Not Specified"}
                              </p>
                              <p className="text-[11px] font-normal text-slate-500 font-mono mt-0.5 select-all">
                                ✉ Email: {ord.shipping.email}
                              </p>
                              <div className="mt-2 text-slate-600 leading-relaxed font-semibold space-y-1">
                                <p className="text-[10px] uppercase font-bold tracking-widest text-slate-400 mb-0.5">Shipping Address & Method</p>
                                <div className="pb-1">
                                  {ord.deliveryMethod === "pickup" ? (
                                    <span className="inline-flex items-center gap-1.5 rounded-md bg-indigo-55 bg-indigo-50 border border-indigo-200 px-2 py-1 text-[10px] font-bold text-indigo-700">
                                      নিজে এসে নিয়ে যাওয়া (Store Pickup)
                                    </span>
                                  ) : (
                                    <span className="inline-flex items-center gap-1.5 rounded-md bg-amber-55 bg-amber-50 border border-amber-200 px-2 py-1 text-[10px] font-bold text-amber-700">
                                      হোম ডেলিভারি সুবিধা (Home Delivery)
                                    </span>
                                  )}
                                </div>
                                <div className="text-[11px] text-slate-705 font-medium leading-relaxed">
                                  {ord.shipping.street === "In-Store Pickup (সরাসরি দোকান থেকে সংগ্রহ)" ? (
                                    <span className="text-slate-500 italic">দোকানে এসে দেখে ও যাচাই করে সংগ্রহ করবেন</span>
                                  ) : (
                                    `${ord.shipping.street}, ${ord.shipping.city}, ${ord.shipping.state} ${ord.shipping.zipCode}`
                                  )}
                                </div>
                              </div>
                              {ord.shipping.notes && (
                                <div className="bg-amber-50/75 border border-amber-100 p-2 rounded-lg text-[10px] text-amber-800 leading-normal font-normal">
                                  <strong>Customer Notes:</strong> &ldquo;{ord.shipping.notes}&rdquo;
                                </div>
                              )}
                            </div>
                          </div>

                          {/* Center: List of Clothing Goods */}
                          <div className="md:col-span-4 space-y-3">
                            <h5 className="text-[10px] font-black text-slate-400 uppercase tracking-widest border-b pb-1">
                              Invoiced Clothing Items
                            </h5>
                            <div className="space-y-2.5 max-h-40 overflow-y-auto pr-1">
                              {ord.items.map((item, idx) => (
                                <div key={idx} className="flex gap-2 text-xs">
                                  <img
                                    src={item.product.image}
                                    alt={item.product.name}
                                    className="h-10 w-10 object-cover rounded-md border shrink-0 bg-slate-50"
                                    referrerPolicy="no-referrer"
                                  />
                                  <div className="min-w-0 flex-1">
                                    <p className="font-bold text-slate-900 truncate">{item.product.name}</p>
                                    <p className="text-[10px] text-slate-400 font-semibold uppercase tracking-wider">
                                      {item.product.category} // ${item.product.price} x {item.quantity}
                                    </p>
                                  </div>
                                </div>
                              ))}
                            </div>
                          </div>

                          {/* Right: Pricing Action panel */}
                          <div className="md:col-span-3 flex flex-col justify-between items-stretch border-t md:border-t-0 md:border-l border-slate-100 pt-4 md:pt-0 md:pl-5">
                            <div className="space-y-1 text-center md:text-right">
                              <span className="text-[9px] font-bold text-slate-405 uppercase tracking-widest block text-slate-400">
                                Total Grand Invoiced
                              </span>
                              <span className="text-xl font-black font-mono text-slate-900 block">
                                ${ord.total.toLocaleString()}
                              </span>
                              <span className="text-[9px] font-bold uppercase tracking-wider text-emerald-600 block pl-1.5">
                                COD Authorized Freight
                              </span>
                            </div>

                            <div className="pt-4 space-y-2">
                              {exportedDocs[ord.id] ? (
                                <a
                                  href={exportedDocs[ord.id]}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  className="w-full rounded-lg bg-indigo-50 hover:bg-indigo-100 border border-indigo-200 text-indigo-700 py-2.5 text-[10px] font-black uppercase tracking-widest transition-all cursor-pointer flex items-center justify-center gap-1.5"
                                >
                                  <FileText className="h-3.5 w-3.5 text-indigo-600" />
                                  View Google Doc
                                </a>
                              ) : (
                                <button
                                  onClick={() => handleExportToDocs(ord)}
                                  disabled={isExportingMap[ord.id]}
                                  className="w-full rounded-lg bg-blue-50/50 hover:bg-blue-50 border border-blue-200 text-blue-700 hover:text-blue-800 py-2.5 text-[10px] font-black uppercase tracking-widest transition-all cursor-pointer flex items-center justify-center gap-1.5 disabled:opacity-50"
                                >
                                  {isExportingMap[ord.id] ? (
                                    <>
                                      <span className="h-3.5 w-3.5 animate-spin rounded-full border-2 border-blue-600 border-t-transparent" />
                                      Creating Doc...
                                    </>
                                  ) : (
                                    <>
                                      <FileText className="h-3.5 w-3.5 text-blue-600" />
                                      Export to Google Doc
                                    </>
                                  )}
                                </button>
                              )}

                              {ord.status === "Pending" ? (
                                <button
                                  onClick={() => confirmOrder(ord.id)}
                                  className="w-full rounded-lg bg-emerald-600 hover:bg-emerald-700 hover:shadow-md text-white py-2.5 text-[10px] font-black uppercase tracking-widest active:scale-97 transition-all cursor-pointer flex items-center justify-center gap-1.5"
                                >
                                  <Check className="h-3.5 w-3.5" />
                                  Confirm Order
                                </button>
                              ) : (
                                <div className="rounded-lg bg-slate-100 border border-slate-200 py-2.5 text-center text-[10px] font-black uppercase tracking-widest text-slate-400 flex items-center justify-center gap-1 select-none">
                                  <Check className="h-3.5 w-3.5 text-emerald-600" />
                                  Dispatch Confirmed
                                </div>
                              )}
                            </div>
                          </div>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>
            )}
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};

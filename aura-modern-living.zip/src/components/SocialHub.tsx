import React from "react";
import {
  Facebook,
  Youtube,
  Send,
  MessageSquare,
  Users,
  Gamepad2,
  Cpu,
  ArrowUpRight,
} from "lucide-react";

export interface SocialChannel {
  id: string;
  title: string;
  bengaliTitle: string;
  url: string;
  description: string;
  bengaliDescription: string;
  username: string;
  color: string;
  hoverBg: string;
  ringColor: string;
  borderColor: string;
  icon: React.ComponentType<any>;
}

export const SOCIAL_CHANNELS: SocialChannel[] = [
  {
    id: "facebook",
    title: "Facebook Profile",
    bengaliTitle: "ফেসবুক প্রোফাইল",
    url: "https://www.facebook.com/itzashiqvai999",
    description: "Connect with us on Facebook for direct updates, queries, and living ideas.",
    bengaliDescription: "আমাদের ফেসবুক প্রোফাইলে যুক্ত হয়ে সরাসরি কথা বলুন এবং আপডেট পান।",
    username: "@itzashiqvai999",
    color: "bg-blue-600",
    hoverBg: "hover:bg-blue-700",
    ringColor: "focus:ring-blue-500/20",
    borderColor: "border-blue-100",
    icon: Facebook,
  },
  {
    id: "whatsapp",
    title: "WhatsApp Channel",
    bengaliTitle: "হোয়াটসঅ্যাপ সাপোর্ট",
    url: "https://wa.me/8801871731341?text=Hello!%20I%20am%20interested%20in%20ordering.",
    description: "Fast 24/7 direct-order hotline and customer support channel.",
    bengaliDescription: "২৪/৭ সরাসরি অর্ডার হটলাইন এবং কাস্টমার সাপোর্ট সার্ভিস নম্বর।",
    username: "01871731341",
    color: "bg-emerald-600",
    hoverBg: "hover:bg-emerald-700",
    ringColor: "focus:ring-emerald-500/20",
    borderColor: "border-emerald-100",
    icon: MessageSquare,
  },
  {
    id: "youtube",
    title: "YouTube Channel",
    bengaliTitle: "ইউটিউব চ্যানেল",
    url: "https://www.youtube.com/channel/UCk1LD7EKbDd3ZQiFKo0OYpA",
    description: "Watch luxury product showcases, room tours, and minimalist walkthroughs.",
    bengaliDescription: "পণ্য প্রদর্শনীর ভিডিও, আধুনিক ঘর সাজানোর আইডিয়া ও ভিডিও ট্যুর দেখুন।",
    username: "Gaming Muri Baba",
    color: "bg-rose-600",
    hoverBg: "hover:bg-rose-700",
    ringColor: "focus:ring-rose-500/20",
    borderColor: "border-rose-100",
    icon: Youtube,
  },
  {
    id: "tiktok",
    title: "TikTok Account",
    bengaliTitle: "টিকটক প্রোফাইল",
    url: "https://www.tiktok.com/@gamingmuribaba?lang=en",
    description: "Bite-sized aesthetic clips, unboxing experiences, and quick designs.",
    bengaliDescription: "মজার ও চমৎকার শর্ট ক্লিপ, নতুন পণ্য আনবক্সিং এবং ঝটপট ডিজাইন আইডিয়া।",
    username: "@gamingmuribaba",
    color: "bg-slate-900",
    hoverBg: "hover:bg-slate-950",
    ringColor: "focus:ring-slate-550/20",
    borderColor: "border-slate-800",
    icon: Gamepad2,
  },
  {
    id: "discord",
    title: "Official Discord Community",
    bengaliTitle: "ডিসকর্ড কমিউনিটি",
    url: "https://discord.gg/sN4qwhtWsy",
    description: "Join the official discussion group with design creators and active buyers.",
    bengaliDescription: "নিবেদিত ডিজাইনার, ক্রিয়েটর ও ক্রেতাদের অফিশিয়াল আড্ডার আসরে যোগ দিন।",
    username: "discord.gg/sN4qwhtWsy",
    color: "bg-indigo-600",
    hoverBg: "hover:bg-indigo-700",
    ringColor: "focus:ring-indigo-500/20",
    borderColor: "border-indigo-100",
    icon: Users,
  },
  {
    id: "telegram",
    title: "Telegram Channel",
    bengaliTitle: "টেলিগ্রাম চ্যানেল",
    url: "https://t.me/uStweqRmfBthNzI1",
    description: "Instant feeds on warehouse drops, flash sales, and active discount codes.",
    bengaliDescription: "নতুন পণ্য স্টক, লিমিটেড ফ্ল্যাশ সেল ও ডিসকাউন্ট কোডের প্রথম খবর পাবেন এখানে।",
    username: "t.me/uStweqRmfBthNzI1",
    color: "bg-sky-500",
    hoverBg: "hover:bg-sky-600",
    ringColor: "focus:ring-sky-500/20",
    borderColor: "border-sky-100",
    icon: Send,
  },
  {
    id: "discord-panel",
    title: "Discord Free Panel",
    bengaliTitle: "ফ্রি প্যানেল ডিসকর্ড",
    url: "https://discord.gg/KMPyQ5QJHR",
    description: "Access our exclusive custom builder panel, free presets, and toolsets.",
    bengaliDescription: "বিশেষ কাস্টম বিল্ডার প্যানেল, প্রিসেট ফাইল এবং ডেকোরেশন টুলসেট ব্যবহারের জন্য।",
    username: "discord.gg/KMPyQ5QJHR",
    color: "bg-teal-605",
    hoverBg: "hover:bg-teal-700",
    ringColor: "focus:ring-teal-500/20",
    borderColor: "border-teal-100",
    icon: Cpu,
  },
];

export const SocialHub: React.FC = () => {
  return (
    <section id="social-hub-section" className="scroll-mt-24 space-y-8 py-3 select-none">
      <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-4 border-b border-slate-200 pb-5">
        <div className="space-y-1.5">
          <div className="flex items-center gap-2">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-indigo-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-indigo-500 animate-pulse"></span>
            </span>
            <span className="text-[10px] font-extrabold text-indigo-650 tracking-widest uppercase">
              সোশ্যাল চ্যানেল ও সরাসরি যোগাযোগ // Connect with Us
            </span>
          </div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight uppercase">
            আমাদের সোশ্যাল কানেক্ট হাব // Social Hub
          </h2>
          <p className="text-xs text-slate-500 max-w-xl leading-relaxed font-normal">
            অর্ডার সংক্রান্ত আপডেট, নতুন ডিজাইন রিলিজ এবং সরাসরি সাপোর্টের জন্য নিচের সোশ্যাল হ্যান্ডল আমাদের সাথে যুক্ত হতে পারেন।
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
        {SOCIAL_CHANNELS.map((channel) => {
          const IconComponent = channel.icon;
          return (
            <a
              key={channel.id}
              href={channel.url}
              target="_blank"
              rel="noopener noreferrer"
              className="group block relative rounded-2xl border border-slate-200 bg-white p-5 shadow-xs transition-all duration-300 hover:shadow-md hover:border-slate-350 hover:-translate-y-0.5 cursor-pointer"
            >
              <div className="flex items-start justify-between gap-3 mb-3.5">
                <div className={`p-2 rounded-xl text-white ${channel.id === "discord-panel" ? "bg-teal-600" : channel.color} shadow-xs shrink-0 transition-transform group-hover:scale-105`}>
                  <IconComponent className="h-5 w-5" />
                </div>
                <div className="rounded-full bg-slate-50 p-1.5 text-slate-400 group-hover:bg-slate-100 group-hover:text-indigo-600 transition-colors">
                  <ArrowUpRight className="h-3.5 w-3.5" />
                </div>
              </div>

              <div className="space-y-1.5">
                <div className="flex flex-col">
                  <span className="text-[13px] font-extrabold text-slate-900 tracking-tight group-hover:text-indigo-600 transition-colors leading-snug">
                    {channel.bengaliTitle}
                  </span>
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest leading-none mt-0.5">
                    {channel.title}
                  </span>
                </div>

                <p className="text-[11px] text-slate-505 text-slate-600 font-normal leading-relaxed min-h-[50px]">
                  {channel.bengaliDescription}
                </p>

                <div className="pt-2.5 flex items-center justify-between border-t border-slate-50">
                  <span className="font-mono text-[10px] font-bold text-indigo-650 bg-slate-50 border border-slate-100 px-2 py-0.5 rounded-md group-hover:bg-indigo-50/40 group-hover:border-indigo-150 transition-all">
                    {channel.username}
                  </span>
                  <span className="text-[10px] font-bold uppercase text-slate-400 group-hover:text-indigo-650 transition-colors">
                    visit →
                  </span>
                </div>
              </div>
            </a>
          );
        })}
      </div>
    </section>
  );
};

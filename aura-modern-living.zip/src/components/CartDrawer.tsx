import React from "react";
import { CartItem } from "../types";
import { X, Trash2, ShoppingBag, CreditCard, ArrowRight, MessageSquare, Facebook } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { useLocalization } from "../context/LocalizationContext";

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  cartItems: CartItem[];
  onUpdateQuantity: (productId: string, quantity: number) => void;
  onRemoveItem: (productId: string) => void;
  onCheckout: () => void;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  onClose,
  cartItems,
  onUpdateQuantity,
  onRemoveItem,
  onCheckout,
}) => {
  const { formatPrice, t, language } = useLocalization();

  const subtotal = cartItems.reduce(
    (acc, item) => acc + item.product.price * item.quantity,
    0
  );

  const totalQty = cartItems.reduce((acc, item) => acc + item.quantity, 0);

  // Free shipping threshold is $300 USD or equivalent
  const freeShippingThresholdUsd = 300;
  const isFreeShipping = subtotal >= freeShippingThresholdUsd;
  const remainingForFreeShippingUsd = freeShippingThresholdUsd - subtotal;

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 overflow-hidden font-sans">
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-black/40 backdrop-blur-xs transition-opacity"
          />

          <div className="pointer-events-none fixed inset-y-0 right-0 flex max-w-full pl-10">
            <motion.div
              initial={{ x: "100%" }}
              animate={{ x: 0 }}
              exit={{ x: "100%" }}
              transition={{ type: "spring", damping: 25, stiffness: 220 }}
              className="pointer-events-auto w-screen max-w-md"
            >
              <div className="flex h-full flex-col bg-white shadow-2xl">
                {/* Cart Header */}
                <div className="flex items-center justify-between border-b border-slate-100 bg-slate-50 px-5 py-4">
                  <div className="flex items-center gap-2">
                    <ShoppingBag className="h-5 w-5 text-slate-900" />
                    <h2 className="text-sm font-bold uppercase tracking-wider text-slate-900">
                      {t("cart.title")} ({totalQty})
                    </h2>
                  </div>
                  <button
                    id="cart-close-btn"
                    onClick={onClose}
                    className="flex h-8 w-8 items-center justify-center rounded-full border border-slate-200 text-slate-400 hover:bg-slate-100 hover:text-slate-800 transition-colors cursor-pointer"
                  >
                    <X className="h-4 w-4" />
                  </button>
                </div>

                {/* Free Shipping Dynamic Indicator */}
                {totalQty > 0 && (
                  <div className="bg-slate-50 border-b border-slate-100 px-5 py-3">
                    {isFreeShipping ? (
                      <p className="text-[11px] font-bold text-emerald-600 uppercase tracking-wide flex items-center gap-1">
                        ✨ {language === "en" ? "Your order qualifies for free carbon-neutral shipping!" : "অভিনন্দন! আপনি ফ্রি শিপিং সুবিধা পেয়েছেন!"}
                      </p>
                    ) : (
                      <div className="space-y-1.5">
                        <p className="text-[11px] font-bold text-slate-600 uppercase tracking-wide">
                          {language === "en" ? "Spend" : "আর মাত্র"}{" "}
                          <strong className="text-slate-900 font-mono">
                            {formatPrice(remainingForFreeShippingUsd)}
                          </strong>{" "}
                          {language === "en" ? "more for free shipping" : "মূল্যের পণ্য নিয়ে নিন এবং সম্পূর্ণ ফ্রি ডেলিভারি পান"}
                        </p>
                        <div className="h-1.5 w-full overflow-hidden rounded-full bg-slate-200">
                          <div
                            style={{
                              width: `${Math.min((subtotal / freeShippingThresholdUsd) * 100, 100)}%`,
                            }}
                            className="h-full rounded-full bg-indigo-600 transition-all duration-300"
                          />
                        </div>
                      </div>
                    )}
                  </div>
                )}

                {/* Bag Content */}
                <div className="flex-1 overflow-y-auto p-5 space-y-4">
                  {cartItems.length === 0 ? (
                    <div className="flex h-full flex-col items-center justify-center text-center space-y-4">
                      <div className="rounded-full bg-slate-50 p-6 flex items-center justify-center border border-dashed border-slate-200">
                        <ShoppingBag className="h-8 w-8 text-slate-350" />
                      </div>
                      <div className="space-y-1 block">
                        <p className="text-xs font-bold text-slate-850 uppercase tracking-wider">
                          {t("cart.empty")}
                        </p>
                        <p className="text-[11px] text-slate-400 font-normal">
                          {language === "en" ? "Save beautifully crafted pieces into your sanctuary." : "আমাদের চমৎকার কালেকশন থেকে আপনার পছন্দের পোশাক ব্যাগ-এ যুক্ত করুন।"}
                        </p>
                      </div>
                      <button
                        id="cart-browse-btn"
                        onClick={onClose}
                        className="rounded-lg bg-indigo-600 px-5 py-2.5 text-xs font-bold uppercase tracking-wider text-white transition-all hover:bg-indigo-700 hover:scale-105 cursor-pointer"
                      >
                        {language === "en" ? "Keep Browsing" : "পোশাক দেখতে থাকুন"}
                      </button>
                    </div>
                  ) : (
                    cartItems.map((item) => {
                      // Localized dynamic name
                      let dynamicName = item.product.name;
                      if (language === "bn") {
                        if (item.product.name.includes("Supima Cotton")) dynamicName = "সুপিমা লাক্সারি কটন ক্রুনেক গেঞ্জি";
                        else if (item.product.name.includes("Oxford Cotton")) dynamicName = "অক্সফোর্ড বাটন-ডাউন কলার শার্ট";
                        else if (item.product.name.includes("Heavyweight Organic")) dynamicName = "ভারী সুতি জিপার হুডি জ্যাকেট";
                        else if (item.product.name.includes("Sartorial Classic")) dynamicName = "ক্লাসিক ইতালিয়ান ব্লেজার স্যুট";
                        else if (item.product.name.includes("Ribbed Combed")) dynamicName = "কম্বড রিঙ্গড আরামদায়ক গেঞ্জি";
                        else if (item.product.name.includes("Linen Silk")) dynamicName = "লিলেন সিল্ক ক্লাসিক ক্যাজুয়াল শার্ট";
                        else if (item.product.name.includes("Cashmere Blend")) dynamicName = "প্রিমিয়াম কাশ্মীরি ব্লেন্ড ব্লেজার পোশাক";
                      }

                      return (
                        <div
                          key={item.product.id}
                          className="flex items-center gap-4 rounded-xl border border-slate-100 bg-slate-50/50 p-3 transition-colors hover:bg-slate-100"
                        >
                          {/* Thumbnail */}
                          <div className="h-16 w-16 shrink-0 overflow-hidden rounded-lg border border-slate-200 bg-white">
                            <img
                              src={item.product.image}
                              alt={item.product.name}
                              className="h-full w-full object-cover"
                              referrerPolicy="no-referrer"
                            />
                          </div>

                          {/* Title & Quantity adjustments */}
                          <div className="flex-1 min-w-0">
                            <h4 className="truncate text-xs font-bold text-slate-900">
                              {dynamicName}
                            </h4>
                            <span className="text-[9px] text-slate-400 capitalize tracking-wider font-semibold">
                              {item.product.category === "Suits" ? t("cat.suits") : item.product.category === "Shirts" ? t("cat.shirts") : item.product.category === "Tees & Vests" ? t("cat.tees") : t("cat.casuals")}
                            </span>

                            <div className="mt-2 flex items-center gap-3">
                              {/* Embedded Stepper */}
                              <div className="flex items-center rounded-md border border-slate-200 bg-white px-0.5">
                                <button
                                  id={`cart-minus-${item.product.id}`}
                                  onClick={() =>
                                    onUpdateQuantity(
                                      item.product.id,
                                      item.quantity - 1
                                    )
                                  }
                                  className="flex h-6 w-6 items-center justify-center text-xs font-semibold text-slate-400 hover:text-slate-800 cursor-pointer"
                                >
                                  -
                                </button>
                                <span className="w-6 text-center text-[11px] font-bold text-slate-850">
                                  {item.quantity}
                                </span>
                                <button
                                  id={`cart-plus-${item.product.id}`}
                                  onClick={() =>
                                    onUpdateQuantity(
                                      item.product.id,
                                      item.quantity + 1
                                    )
                                  }
                                  className="flex h-6 w-6 items-center justify-center text-xs font-semibold text-slate-400 hover:text-slate-800 cursor-pointer"
                                >
                                  +
                                </button>
                              </div>

                              <button
                                id={`cart-del-${item.product.id}`}
                                onClick={() => onRemoveItem(item.product.id)}
                                className="text-slate-400 hover:text-rose-500 transition-colors cursor-pointer"
                              >
                                <Trash2 className="h-3.5 w-3.5" />
                              </button>
                            </div>
                          </div>

                          {/* Summary Price */}
                          <div className="text-right shrink-0">
                            <span className="text-xs font-bold text-slate-900 block font-mono">
                              {formatPrice(item.product.price * item.quantity)}
                            </span>
                            {item.quantity > 1 && (
                              <span className="text-[9px] text-slate-400 block mt-0.5 font-mono">
                                {formatPrice(item.product.price)} each
                              </span>
                            )}
                          </div>
                        </div>
                      );
                    })
                  )}
                </div>

                {/* Cart checkout footer drawer */}
                {cartItems.length > 0 && (
                  <div className="border-t border-slate-100 bg-slate-50 p-5 space-y-4 shrink-0">
                    <div className="space-y-1.5">
                      <div className="flex items-center justify-between text-xs text-slate-500 font-semibold">
                        <span>{t("cart.subtotal")}</span>
                        <span className="font-mono">{formatPrice(subtotal)}</span>
                      </div>
                      <div className="flex items-center justify-between text-xs text-slate-500 font-semibold">
                        <span>{t("cart.shipping")}</span>
                        <span className="font-mono">{isFreeShipping ? t("cart.free") : formatPrice(25)}</span>
                      </div>
                      <div className="border-t border-slate-200/80 pt-2 flex items-center justify-between text-sm font-bold text-slate-900">
                        <span>{t("cart.total")}</span>
                        <span className="font-mono text-indigo-600">
                          {formatPrice(isFreeShipping ? subtotal : subtotal + 25)}
                        </span>
                      </div>
                    </div>

                    <button
                      id="cart-checkout-btn"
                      onClick={onCheckout}
                      className="w-full flex items-center justify-center gap-2 rounded-lg bg-indigo-600 py-3.5 text-xs font-bold uppercase tracking-wider text-white shadow-md transition-all hover:bg-indigo-700 active:scale-[0.98] cursor-pointer"
                    >
                      <CreditCard className="h-4 w-4" />
                      {t("cart.checkout")}
                      <ArrowRight className="h-3.5 w-3.5 ml-0.5 animate-pulse" />
                    </button>

                    <div className="relative flex py-1 items-center">
                      <div className="flex-grow border-t border-slate-200"></div>
                      <span className="flex-shrink mx-4 text-[9px] font-bold text-slate-400 uppercase tracking-widest bg-slate-50 px-2">
                        {language === "en" ? "Or Order Directly" : "অথবা সরাসরি মোবাইল অর্ডারিং"}
                      </span>
                      <div className="flex-grow border-t border-slate-200"></div>
                    </div>

                    <div className="grid grid-cols-2 gap-3 pb-1">
                      <a
                        id="cart-order-whatsapp-btn"
                        href={`https://wa.me/8801871731341?text=${encodeURIComponent(
                          `Hello! I'd like to directly order my shopping bag items:\n\n` +
                          cartItems.map(item => `• ${item.product.name} (x${item.quantity}) - ${formatPrice(item.product.price * item.quantity)}`).join("\n") +
                          `\n\nOriginal Subtotal: ${formatPrice(subtotal)}\n` +
                          `Shipping: ${isFreeShipping ? "FREE" : formatPrice(25)}\n` +
                          `Estimated Total: ${formatPrice(isFreeShipping ? subtotal : subtotal + 25)}\n\n` +
                          `Please let me know how to proceed with payment and delivery details.`
                        )}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center justify-center gap-2 rounded-lg border border-emerald-200 bg-emerald-50 py-3 text-xs font-bold uppercase tracking-wider text-emerald-800 transition-all hover:bg-emerald-100 hover:border-emerald-300 active:scale-[0.98] cursor-pointer"
                      >
                        <MessageSquare className="h-4 w-4 text-emerald-600" />
                        WhatsApp
                      </a>
                      <a
                        id="cart-order-facebook-btn"
                        href="https://www.facebook.com/itzashiqvai999"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center justify-center gap-2 rounded-lg border border-blue-200 bg-blue-50 py-3 text-xs font-bold uppercase tracking-wider text-blue-800 transition-all hover:bg-blue-100 hover:border-blue-300 active:scale-[0.98] cursor-pointer"
                      >
                        <Facebook className="h-4 w-4 text-blue-600" />
                        Facebook Page
                      </a>
                    </div>
                  </div>
                )}
              </div>
            </motion.div>
          </div>
        </div>
      )}
    </AnimatePresence>
  );
};

import React from "react";
import { Product } from "../types";
import { Star, Eye, ShoppingBag, Heart } from "lucide-react";
import { motion } from "motion/react";
import { useLocalization } from "../context/LocalizationContext";

interface ProductCardProps {
  product: Product;
  onViewDetails: (product: Product) => void;
  onAddToCart: (product: Product) => void;
  onToggleFavorite: (product: Product) => void;
  isFavorite: boolean;
}

export const ProductCard: React.FC<ProductCardProps> = ({
  product,
  onViewDetails,
  onAddToCart,
  onToggleFavorite,
  isFavorite,
}) => {
  const { formatPrice, t, language } = useLocalization();

  // Localized Category mapping
  let categoryLabel = product.category;
  if (product.category === "Suits") categoryLabel = t("cat.suits") as any;
  if (product.category === "Shirts") categoryLabel = t("cat.shirts") as any;
  if (product.category === "Tees & Vests") categoryLabel = t("cat.tees") as any;
  if (product.category === "Premium Casuals") categoryLabel = t("cat.casuals") as any;

  return (
    <motion.div
      id={`product-card-${product.id}`}
      layout
      initial={{ opacity: 0, y: 15 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -15 }}
      transition={{ duration: 0.35, ease: "easeOut" }}
      className="group relative flex flex-col overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm transition-all duration-300 hover:shadow-lg hover:border-indigo-300"
    >
      {/* Favorite Button */}
      <button
        id={`fav-btn-${product.id}`}
        onClick={(e) => {
          e.stopPropagation();
          onToggleFavorite(product);
        }}
        className="absolute top-4 right-4 z-10 flex h-9 w-9 items-center justify-center rounded-full border border-slate-200 bg-white/95 backdrop-blur-xs text-slate-500 shadow-sm transition-all duration-200 hover:scale-105 hover:bg-white hover:text-rose-500 active:scale-95"
      >
        <Heart
          className={`h-4 w-4 ${isFavorite ? "fill-rose-500 text-rose-500" : ""}`}
        />
      </button>

      {/* Product Image & Badges */}
      <div
        onClick={() => onViewDetails(product)}
        className="relative aspect-4/3 w-full cursor-pointer overflow-hidden bg-slate-50"
      >
        <img
          src={product.image}
          alt={product.name}
          className="h-full w-full object-cover transition-transform duration-700 ease-out group-hover:scale-105"
          referrerPolicy="no-referrer"
        />

        {/* Hot / Popular Badge */}
        {product.isPopular && (
          <span className="absolute top-4 left-4 rounded-full bg-indigo-600 px-2.5 py-1 text-[10px] font-bold tracking-wider text-white uppercase shadow-sm">
            {t("prod.bestSeller")}
          </span>
        )}

        {/* Low Stock Badge */}
        {product.stock <= 5 && (
          <span className="absolute bottom-4 left-4 rounded-full bg-amber-500 px-2.5 py-1 text-[10px] font-bold tracking-wider text-white uppercase shadow-sm">
            {t("prod.onlyLeft").replace("{n}", product.stock.toString())}
          </span>
        )}

        {/* Hover Action Overlay */}
        <div className="absolute inset-x-0 bottom-0 flex translate-y-full items-center justify-center gap-3 bg-gradient-to-t from-black/25 via-black/5 to-transparent p-4 opacity-0 transition-all duration-300 group-hover:translate-y-0 group-hover:opacity-100">
          <button
            id={`quick-view-over-${product.id}`}
            onClick={(e) => {
              e.stopPropagation();
              onViewDetails(product);
            }}
            className="flex h-10 items-center justify-center gap-1.5 rounded-lg border border-slate-200 bg-white px-4 text-xs font-semibold text-slate-700 shadow-sm transition-all hover:bg-slate-50"
          >
            <Eye className="h-3.5 w-3.5" />
            {t("prod.detailView")}
          </button>
        </div>
      </div>

      {/* Product Information */}
      <div className="flex flex-1 flex-col p-5">
        <div className="flex items-center justify-between gap-1 text-[10px] font-bold tracking-wider text-slate-400 uppercase">
          <span>{categoryLabel}</span>
          <div className="flex items-center gap-1 text-amber-500">
            <Star className="h-3 w-3 fill-amber-500 stroke-amber-500" />
            <span className="text-slate-600 font-bold">{product.rating}</span>
          </div>
        </div>

        <h3
          onClick={() => onViewDetails(product)}
          className="mt-2 text-[15px] font-bold text-slate-900 cursor-pointer hover:text-indigo-600 leading-tight transition-colors"
        >
          {language === "bn" && product.name.includes("Supima Cotton") ? "সুপিমা লাক্সারি কটন ক্রুনেক গেঞ্জি" :
           language === "bn" && product.name.includes("Oxford Cotton") ? "অক্সফোর্ড বাটন-ডাউন কলার শার্ট" :
           language === "bn" && product.name.includes("Heavyweight Organic") ? "ভারী সুতি জিপার হুডি জ্যাকেট" :
           language === "bn" && product.name.includes("Sartorial Classic") ? "ক্লাসিক ইতালিয়ান ব্লেজার স্যুট" :
           language === "bn" && product.name.includes("Ribbed Combed") ? "কম্বড রিঙ্গড আরামদায়ক গেঞ্জি" :
           language === "bn" && product.name.includes("Linen Silk") ? "লিলেন সিল্ক ক্লাসিক ক্যাজুয়াল শার্ট" :
           language === "bn" && product.name.includes("Cashmere Blend") ? "প্রিমিয়াম কাশ্মীরি ব্লেন্ড ব্লেজার পোশাক" : product.name}
        </h3>

        <p className="mt-1 flex-1 text-xs text-slate-500 line-clamp-2 leading-relaxed font-normal font-sans">
          {language === "bn" && product.tagline.includes("Seamless") ? "সরাসরি নিখুঁত ব্যাক-সিম ও উন্নত প্রিমিয়াম ফিনিশিং সুতি গেঞ্জি।" :
           language === "bn" && product.tagline.includes("Heavyweight") ? "ভারী সুতি প্রিমিয়াম মেটাল জিপারযুক্ত জমকালো হুডি।" :
           language === "bn" && product.tagline.includes("Double-Breasted") ? "ডাবল ব্রেস্টেড জ্যাকেট স্যুট নিখুঁত পোশাক কারিগরি।" :
           language === "bn" && product.tagline.includes("Durable ribbed") ? "দীর্ঘস্থায়ী ডাবল প্রো-রিঙ্গড আরামদায়ক কালার গেঞ্জি।" :
           language === "bn" && product.tagline.includes("Architectural") ? "আধুনিক জ্যামিতিক নকশার প্রিমিয়াম লিনেন কারিগরি।" :
           language === "bn" && product.tagline.includes("Structured") ? "প্রিমিয়াম ইতালীয় খাঁটি পশমী কাপড় দ্বারা বোনা স্যুট।" : product.tagline}
        </p>

        {/* Price & Purchase Drawer Action */}
        <div className="mt-4 flex items-center justify-between border-t border-slate-100 pt-4">
          <span className="text-base font-extrabold text-slate-900 font-mono">
            {formatPrice(product.price)}
          </span>

          <button
            id={`add-to-cart-${product.id}`}
            onClick={(e) => {
              e.stopPropagation();
              onViewDetails(product);
            }}
            className="flex items-center gap-1.5 rounded-lg bg-indigo-600 px-3.5 py-2 text-xs font-bold text-white shadow-sm transition-all duration-200 hover:bg-indigo-700 active:scale-95 cursor-pointer"
          >
            <ShoppingBag className="h-3.5 w-3.5" />
            {t("prod.addToCart")}
          </button>
        </div>
      </div>
    </motion.div>
  );
};

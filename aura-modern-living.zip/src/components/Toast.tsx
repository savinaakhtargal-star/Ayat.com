import React, { useEffect } from "react";
import { CheckCircle2, AlertCircle, X, Heart } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

export interface ToastMessage {
  id: string;
  text: string;
  type: "success" | "info" | "heart";
}

interface ToastContainerProps {
  toasts: ToastMessage[];
  onDismiss: (id: string) => void;
}

export const ToastContainer: React.FC<ToastContainerProps> = ({ toasts, onDismiss }) => {
  return (
    <div className="fixed bottom-6 left-6 z-50 flex flex-col gap-2.5 max-w-sm pointer-events-none">
      <AnimatePresence>
        {toasts.map((toast) => (
          <ToastItem key={toast.id} toast={toast} onDismiss={onDismiss} />
        ))}
      </AnimatePresence>
    </div>
  );
};

interface ToastItemProps {
  toast: ToastMessage;
  onDismiss: (id: string) => void;
}

const ToastItem: React.FC<ToastItemProps> = ({ toast, onDismiss }) => {
  useEffect(() => {
    const timer = setTimeout(() => {
      onDismiss(toast.id);
    }, 4000);
    return () => clearTimeout(timer);
  }, [toast.id, onDismiss]);

  return (
    <motion.div
      layout
      initial={{ opacity: 0, x: -20, y: 10 }}
      animate={{ opacity: 1, x: 0, y: 0 }}
      exit={{ opacity: 0, x: -20, scale: 0.95 }}
      transition={{ duration: 0.25, ease: "easeOut" }}
      className="pointer-events-auto flex items-center justify-between gap-3.5 rounded-xl border border-slate-200 bg-white/95 backdrop-blur-xs p-4 shadow-xl shadow-slate-200/40"
    >
      <div className="flex items-center gap-2.5">
        {toast.type === "success" && (
          <CheckCircle2 className="h-4.5 w-4.5 shrink-0 text-emerald-600" />
        )}
        {toast.type === "info" && (
          <AlertCircle className="h-4.5 w-4.5 shrink-0 text-indigo-600" />
        )}
        {toast.type === "heart" && (
          <Heart className="h-4.5 w-4.5 shrink-0 text-rose-500 fill-rose-500" />
        )}
        <p className="text-[11px] font-bold text-slate-800 uppercase tracking-wider">
          {toast.text}
        </p>
      </div>
      <button
        id={`toast-dismiss-${toast.id}`}
        onClick={() => onDismiss(toast.id)}
        className="text-slate-400 hover:text-slate-700 transition-colors shrink-0 cursor-pointer"
      >
        <X className="h-3.5 w-3.5" />
      </button>
    </motion.div>
  );
};

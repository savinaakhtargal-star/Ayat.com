import { initializeApp } from "firebase/app";
import { 
  getAuth, 
  signInWithPopup, 
  GoogleAuthProvider, 
  onAuthStateChanged, 
  User 
} from "firebase/auth";
import firebaseConfig from "../../firebase-applet-config.json";

// Initialize Firebase App
const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);

// Use GoogleAuthProvider and set required scope
const provider = new GoogleAuthProvider();
provider.addScope("https://www.googleapis.com/auth/docs");

let isSigningIn = false;
let cachedAccessToken: string | null = null;

// Initialize Google Sign-in state listener
export const initAuth = (
  onAuthSuccess?: (user: User, token: string) => void,
  onAuthFailure?: () => void
) => {
  return onAuthStateChanged(auth, async (user) => {
    if (user) {
      if (cachedAccessToken) {
        if (onAuthSuccess) onAuthSuccess(user, cachedAccessToken);
      } else {
        // If we don't have token cached but user is logged in, we need them to trigger sign-in to get new credentials
        if (onAuthFailure) onAuthFailure();
      }
    } else {
      cachedAccessToken = null;
      if (onAuthFailure) onAuthFailure();
    }
  });
};

// Sign-in with Google to request Google Docs consent
export const googleSignIn = async (): Promise<{ user: User; accessToken: string } | null> => {
  try {
    isSigningIn = true;
    const result = await signInWithPopup(auth, provider);
    const credential = GoogleAuthProvider.credentialFromResult(result);
    if (!credential?.accessToken) {
      throw new Error("Unable to obtain Google API access token from sign-in.");
    }
    cachedAccessToken = credential.accessToken;
    return { user: result.user, accessToken: cachedAccessToken };
  } catch (error) {
    console.error("Google Sign-In Error:", error);
    throw error;
  } finally {
    isSigningIn = false;
  }
};

// Log out Google integration
export const googleSignOut = async () => {
  await auth.signOut();
  cachedAccessToken = null;
};

// Retrieve cached access token
export const getAccessToken = (): string | null => {
  return cachedAccessToken;
};

// Core interface matching modal structure
export interface InvoiceItem {
  product: {
    id: string;
    name: string;
    price: number;
    image: string;
    category: string;
  };
  quantity: number;
}

export interface InvoiceOrder {
  id: string;
  shipping: {
    fullName: string;
    email: string;
    phone?: string;
    street: string;
    city: string;
    state: string;
    zipCode: string;
    notes?: string;
  };
  deliveryMethod?: "pickup" | "delivery";
  items: InvoiceItem[];
  total: number;
  date: string;
  status: "Pending" | "Confirmed";
}

/**
 * Creates a fully designed Invoice in Google Docs via the Docs API.
 * Uses batchUpdate to construct styled headings, tables, or item checklists.
 */
export const createInvoiceDocument = async (
  order: InvoiceOrder,
  accessToken: string
): Promise<{ docId: string; url: string }> => {
  // Step 1: Create an empty document with a title
  const createResponse = await fetch("https://docs.googleapis.com/v1/documents", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${accessToken}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      title: `EMR Clothing Order Invoice - ${order.id}`
    })
  });

  if (!createResponse.ok) {
    const errorData = await createResponse.json().catch(() => ({}));
    throw new Error(
      errorData.error?.message || `Failed to create document: ${createResponse.statusText}`
    );
  }

  const docData = await createResponse.json();
  const documentId = docData.documentId;

  // Step 2: Build a comprehensive structured document with headers, bold attributes, item lines, and notes
  const dateStr = order.date;
  const isPickup = order.deliveryMethod === "pickup";

  // Build the textual body
  let invoiceText = "";
  invoiceText += "========================================================\n";
  invoiceText += "                     EMR CLOTHING BRAND                 \n";
  invoiceText += "========================================================\n\n";
  
  invoiceText += `ORDER INVOICE: ${order.id}\n`;
  invoiceText += `Invoice Date: ${dateStr}\n`;
  invoiceText += `Processing Status: ${order.status.toUpperCase()}\n\n`;

  invoiceText += "--------------------------------------------------------\n";
  invoiceText += "CUSTOMER & DELIVERY INFORMATION\n";
  invoiceText += "--------------------------------------------------------\n";
  invoiceText += `Name: ${order.shipping.fullName}\n`;
  invoiceText += `Phone: ${order.shipping.phone || "Not Specified"}\n`;
  invoiceText += `Email: ${order.shipping.email}\n`;
  
  if (isPickup) {
    invoiceText += "Delivery Method: Store Pickup (নিজে এসে নিয়ে যাওয়া)\n";
    invoiceText += "Details: Customers will inspect, preview and pick up clothing selection live from the outlet.\n";
  } else {
    invoiceText += "Delivery Method: Home Delivery (হোম ডেলিভারি সুবিধা)\n";
    invoiceText += `Shipping Address: ${order.shipping.street}, ${order.shipping.city}, ${order.shipping.state} ${order.shipping.zipCode}\n`;
  }
  
  if (order.shipping.notes) {
    invoiceText += `Special Instructions: "${order.shipping.notes}"\n`;
  }
  invoiceText += "\n";

  invoiceText += "--------------------------------------------------------\n";
  invoiceText += "INVOICED CLOTHING ITEMS\n";
  invoiceText += "--------------------------------------------------------\n";
  
  order.items.forEach((item, index) => {
    const itemTotal = item.product.price * item.quantity;
    invoiceText += `${index + 1}. ${item.product.name}\n`;
    invoiceText += `   Category: ${item.product.category}\n`;
    invoiceText += `   Quantity: ${item.quantity} x $${item.product.price}  -->  Subtotal: $${itemTotal}\n\n`;
  });

  invoiceText += "========================================================\n";
  invoiceText += `GRAND TOTAL INVOICED: $${order.total.toLocaleString()}\n`;
  invoiceText += "========================================================\n\n";
  
  invoiceText += "Thank you for shopping at EMR Clothing!\n";
  invoiceText += "We are committed to delivering the ultimate clothing choices, premium fabrics, and flawless service.\n";
  invoiceText += "For any support or questions, contact us via social hubs or chat.\n";

  // Send batch update to insert the structured content at index 1 (the beginning of the blank document)
  const updateResponse = await fetch(
    `https://docs.googleapis.com/v1/documents/${documentId}:batchUpdate`,
    {
      method: "POST",
      headers: {
        Authorization: `Bearer ${accessToken}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        requests: [
          {
            insertText: {
              index: 1,
              text: invoiceText
            }
          }
        ]
      })
    }
  );

  if (!updateResponse.ok) {
    const errorData = await updateResponse.json().catch(() => ({}));
    throw new Error(
      errorData.error?.message || `Failed to write invoice content: ${updateResponse.statusText}`
    );
  }

  return {
    docId: documentId,
    url: `https://docs.google.com/document/d/${documentId}/edit`
  };
};

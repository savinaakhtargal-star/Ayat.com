import React, { createContext, useContext, useState, useEffect } from "react";

export type LanguageType = "en" | "bn";
export type CurrencyType = "USD" | "BDT" | "EUR" | "GBP";

interface LocalizationContextType {
  language: LanguageType;
  setLanguage: (lang: LanguageType) => void;
  currency: CurrencyType;
  setCurrency: (currency: CurrencyType) => void;
  rates: Record<CurrencyType, number>;
  formatPrice: (usdAmount: number, raw?: boolean) => string | number;
  currencySymbol: string;
  t: (key: string) => string;
}

const EXCHANGE_RATES: Record<CurrencyType, number> = {
  USD: 1.0,
  BDT: 117.5,
  EUR: 0.92,
  GBP: 0.78,
};

const CURRENCY_SYMBOLS: Record<CurrencyType, string> = {
  USD: "$",
  BDT: "৳",
  EUR: "€",
  GBP: "£",
};

const TRANSLATIONS: Record<LanguageType, Record<string, string>> = {
  en: {
    // Header & Hero
    "app.title": "EMR Clothing Studio",
    "app.subtitle": "Bespoke Minimalist Sartorial Excellence",
    "hero.tagline": "Architectural Tailoring & Heavyweight Combed Yarns",
    "hero.cta": "Explore Capsule Collection",
    "banner.freeShipping": "Enjoy free shipping on all orders of $300 (or equivalent) or more globally",
    "banner.sub": "Secure international dispatch, duties paid at checkout with credit cards, bKash or Nagad.",

    // Categories & Filtering
    "cat.all": "All Capsules",
    "cat.suits": "Suits",
    "cat.shirts": "Shirts",
    "cat.tees": "Tees & Vests",
    "cat.casuals": "Premium Casuals",
    "filter.sortBy": "Sort Collection",
    "filter.popular": "Popularity",
    "filter.rating": "Rating: High to Low",
    "filter.priceLow": "Price: Low to High",
    "filter.priceHigh": "Price: High to Low",
    "search.placeholder": "Search architectural pieces, cotton blend tees...",

    // Product Info
    "prod.bestSeller": "Best Seller",
    "prod.onlyLeft": "Only {n} left in vault",
    "prod.detailView": "Detail View",
    "prod.addToCart": "Add to Bag",
    "prod.added": "Added to Bag",
    "prod.inVault": "Verified Vault Stock",
    "prod.outOfStock": "Sold Out",

    // Drawers & Cart
    "cart.title": "Your Shopping Bag",
    "cart.empty": "Your shopping bag is completely empty.",
    "cart.subtotal": "Items Subtotal",
    "cart.shipping": "International Insured Shipping",
    "cart.tax": "Estimated Duties (8.25%)",
    "cart.total": "Estimated Total",
    "cart.checkout": "Proceed to Certified Checkout",
    "cart.free": "FREE",

    // Checkout Flow
    "check.secure": "Secure Portal // 256-Bit SSL Certificate",
    "check.step1": "1. Shipping & Delivery",
    "check.step2": "2. Verified Payment",
    "check.step3": "3. Checkout Review",
    "check.step4": "4. Order Locked & Placed",
    "check.pickup": "In-Store Pickup (Dhaka Showroom)",
    "check.pickupSub": "No pre-payment or delivery fee required. Inspect apparel firsthand.",
    "check.delivery": "Worldwide Insured Home Delivery",
    "check.deliverySub": "Dispatched via DHL Express / Pathfinder globally within 3-4 business days.",
    "check.fullName": "Full Name / গ্ৰাহকের সম্পূর্ণ নাম",
    "check.email": "Email Address / ইমেইল ঠিকানা",
    "check.phone": "Mobile Number / মোবাইল নম্বর",
    "check.street": "Street Address & House / রাস্তার নাম ও বাসা",
    "check.city": "City / জেলা",
    "check.state": "State / Division / বিভাগ",
    "check.zip": "Zip / Postal Code / পোস্টাল কোড",
    "check.notes": "Special Delivery Instructions (Optional)",
    "check.notesPlaceholder": "Add delivery directions or garment sizing preferences...",
    
    // Payment Options BDT / International
    "pay.method": "Select Verified Checkout Gateway",
    "pay.cod": "Cash on Delivery",
    "pay.codDesc": "Pay with cash at your doorstep upon arrival. Available for all cities.",
    "pay.bkash": "bKash QuickWallet (Instant Payment)",
    "pay.bkashDesc": "Pay securely using instant bKash personal or merchant transfer.",
    "pay.nagad": "Nagad FastSecure (Instant Checkout)",
    "pay.nagadDesc": "Fast, safe payment gateway via Nagad digital financial wallet.",
    "pay.stripe": "Credit / Debit Card (Visa, Mastercard, Amex, Stripe)",
    "pay.stripeDesc": "Processed instantly with high-grade Stripe 3D-secure network.",
    "pay.cardName": "Cardholder Name",
    "pay.cardNumber": "Credit Card Number",
    "pay.expiry": "Expiration (MM/YY)",
    "pay.cvv": "CVV Code",
    "pay.orderLocked": "Your order coordinates have been locked inside our dispatch database.",
    "pay.thankYou": "Order finalized successfully! We are preparing your secure parcel.",
    "pay.continue": "Continue to Next Step",
    "pay.back": "Back Step",
    "pay.lockedAndPlaced": "Securely Lock & Place Order",
    
    // Staff & Footer
    "staff.desk": "Officer Desk",
    "staff.clerk": "Hired Clerk Workspace",
    "staff.clerkDesc": "Verify customer phone registers & click dispatch. Locked process.",
    "footer.warranty": "Exchange & Return Guarantee in inbox",
    "footer.allRights": "All Rights Reserved. Verified global merchant of EMR Studios.",
  },
  bn: {
    // Header & Hero
    "app.title": "ইএমআর ক্লোথিং স্টুডিও",
    "app.subtitle": "ন্যূনতম আধুনিক ও আন্তর্জাতিক শৈল্পিক পোশাকের সংগ্রহ",
    "hero.tagline": "বিশেষ সুতি এবং প্রিমিয়াম টেকসই ফাইবারের নিখুঁত কারিগরি",
    "hero.cta": "ক্যাপসুল কালেকশন দেখুন",
    "banner.freeShipping": "বিশ্বের যেকোনো প্রান্তে $৩০০ (বা সমপরিমাণ) অর্ডারে সম্পূর্ণ ফ্রি ডেলিভারি",
    "banner.sub": "নিরাপদ আন্তর্জাতিক শিপিং, চেকআউটে ক্রেডিট কার্ড, বিকাশ বা রকেট/নগদ দ্বারা পেমেন্ট করুন।",

    // Categories & Filtering
    "cat.all": "সব কালেকশন",
    "cat.suits": "স্যুট সেট",
    "cat.shirts": "প্রিমিয়াম শার্ট",
    "cat.tees": "টি-শার্ট এবং গেঞ্জি",
    "cat.casuals": "প্রিমিয়াম ক্যাজুয়ালস",
    "filter.sortBy": "সাজানোর নিয়ম",
    "filter.popular": "জনপ্রিয়তা",
    "filter.rating": "রেটিং: সর্বোচ্চ থেকে সর্বনিম্ন",
    "filter.priceLow": "মূল্য: কম থেকে বেশি",
    "filter.priceHigh": "মূল্য: বেশি থেকে কম",
    "search.placeholder": "প্রিমিয়াম সুতির টি-শার্ট, ব্লেজার ইত্যাদি খুঁজুন...",

    // Product Info
    "prod.bestSeller": "সেরা বিক্রীত পণ্য",
    "prod.onlyLeft": "বাকি আছে মাত্র {n} টি পিস",
    "prod.detailView": "বিস্তারিত দেখুন",
    "prod.addToCart": "কার্টে রাখুন",
    "prod.added": "কার্টে যুক্ত হয়েছে",
    "prod.inVault": "স্টক নিশ্চিত রয়েছে",
    "prod.outOfStock": "স্টক শেষ",

    // Drawers & Cart
    "cart.title": "আপনার শপিং ব্যাগ",
    "cart.empty": "আপনার শপিং ব্যাগটি সম্পূর্ণ খালি আছে।",
    "cart.subtotal": "উপ-মোট মূল্য",
    "cart.shipping": "আন্তর্জাতিক বীমাকৃত ডেলিভারি ফি",
    "cart.tax": "ভ্যাট ও ট্যাক্স (৮.২৫%)",
    "cart.total": "সর্বমোট মূল্য",
    "cart.checkout": "নিরাপদ চেকআউটে এগিয়ে যান",
    "cart.free": "ফ্রি",

    // Checkout Flow
    "check.secure": "নিরাপদ পোর্টাল // ২৫৬-বিট SSL এনক্রিপশন যুক্ত ট্র্যাকিং",
    "check.step1": "১. শিপিং ও ডেলিভারি তথ্য",
    "check.step2": "২. পেমেন্ট ভেরিফিকেশন",
    "check.step3": "৩. অর্ডারের বিবরণী রিভিউ",
    "check.step4": "৪. অর্ডার সফলভাবে সংরক্ষিত",
    "check.pickup": "সরাসরি শোরুম থেকে সংগ্রহ করুন (ঢাকা শোরুম)",
    "check.pickupSub": "কোনো ডেলিভারি চার্জ বা অগ্রিম পেমেন্ট নেই। কাপড় দেখেশুনে পছন্দ করুন।",
    "check.delivery": "আন্তর্জাতিকভাবে হোম ডেলিভারি",
    "check.deliverySub": "ডিএইচএল এক্সপ্রেস (DHL) দ্বারা ৩-৪ কার্যদিবসের মধ্যে বিশ্বের যেকোনো দেশে হোম ডেলিভারি।",
    "check.fullName": "গ্ৰাহকের সম্পূর্ণ নাম",
    "check.email": "ইমেইল ঠিকানা",
    "check.phone": "মোবাইল নম্বর",
    "check.street": "রাস্তা এবং বাসার ঠিকানা",
    "check.city": "শহর / জেলা",
    "check.state": "বিভাগ / অঞ্চল",
    "check.zip": "পোস্টাল কোড / জিপ",
    "check.notes": "ডেলিভারি সংক্রান্ত নির্দেশনা (ঐচ্ছিক)",
    "check.notesPlaceholder": "সাইজ বা ডেলিভারির সময় সম্পর্কে কিছু লিখতে চাইলে লিখুন...",

    // Payment Options BDT / International
    "pay.method": "আপনার সুবিধাজনক পেমেন্ট পদ্ধতি নির্বাচন করুন",
    "pay.cod": "ক্যাশ অন ডেলিভারি (COD)",
    "pay.codDesc": "পণ্যটি হাতে পাওয়ার পর ডেলিভারি ম্যানের কাছে মূল্য পরিশোধ করুন।",
    "pay.bkash": "বিকাশ ওয়ালেট (bKash Instant)",
    "pay.bkashDesc": "আপনার পার্সোনাল মোবাইল পেমেন্ট অথবা মার্চেন্ট পেমেন্ট ব্যবহার করে বিকাশ করুন।",
    "pay.nagad": "নগদ ওয়ালেট (Nagad FastPay)",
    "pay.nagadDesc": "দ্রুত ও নিরাপদ নগদ ডিজিটাল ওয়ালেট ট্র্যান্সফারের মাধ্যমে পেমেন্ট করুন।",
    "pay.stripe": "ক্রেডিট বা ডেবিট কার্ড (ভিসা, মাস্টারকার্ড, অ্যামেক্স)",
    "pay.stripeDesc": "নিরাপদ কার্ড চেকআউট বা স্ট্রাইপ পেমেন্ট গেটওয়ের মাধ্যমে পেমেন্ট সম্পন্ন করুন।",
    "pay.cardName": "কার্ড ব্যবহারকারীর নাম",
    "pay.cardNumber": "১৬ সংখ্যার কার্ড নম্বর",
    "pay.expiry": "মেয়াদ উত্তীর্ণের তারিখ (MM/YY)",
    "pay.cvv": "সিভিভি নম্বর (CVV Code)",
    "pay.orderLocked": "আপনার অর্ডারের বিবরণীটি নিরাপদে আমাদের রেজিস্টারে লক এবং যুক্ত করা হয়েছে।",
    "pay.thankYou": "অর্ডারটি চূড়ান্ত হয়েছে! আমরা আপনার পণ্যগুলো দ্রুত প্রেরণের জন্য প্রস্তুত করছি।",
    "pay.continue": "পরবর্তী ধাপে যান",
    "pay.back": "পূর্ববর্তী ধাপে ফিরুন",
    "pay.lockedAndPlaced": "অর্ডার লক ও চূড়ান্ত নিশ্চিত করুন",

    // Staff & Footer
    "staff.desk": "অফিসার ডেস্ক",
    "staff.clerk": "হায়ার্ড ক্লার্ক ইন্টারফেস",
    "staff.clerkDesc": "গ্রাহকের মোবাইল ট্র্যাকিং যাচাই করে কনফার্ম করুন। অর্ডার লক করা থাকবে।",
    "footer.warranty": "অর্ডার ইনবক্সে রিটার্ন ও ওয়ারেন্টি গ্যারান্টি পেয়ে যাবেন",
    "footer.allRights": "সর্বস্বত্ব সংরক্ষিত। ইএমআর গ্রুপ স্টুডিওর অনুমোদিত বিশ্বব্যাপী ব্র্যান্ডিং।",
  },
};

const LocalizationContext = createContext<LocalizationContextType | undefined>(undefined);

export const LocalizationProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [language, setLanguage] = useState<LanguageType>("en");
  const [currency, setCurrency] = useState<CurrencyType>("USD");

  // Load configuration preferences from localStorage on mount
  useEffect(() => {
    const savedLang = localStorage.getItem("preferredLanguage") as LanguageType;
    const savedCur = localStorage.getItem("preferredCurrency") as CurrencyType;
    if (savedLang && (savedLang === "en" || savedLang === "bn")) {
      setLanguage(savedLang);
    }
    if (savedCur && ["USD", "BDT", "EUR", "GBP"].includes(savedCur)) {
      setCurrency(savedCur);
    }
  }, []);

  const handleSetLanguage = (lang: LanguageType) => {
    setLanguage(lang);
    localStorage.setItem("preferredLanguage", lang);
  };

  const handleSetCurrency = (cur: CurrencyType) => {
    setCurrency(cur);
    localStorage.setItem("preferredCurrency", cur);
  };

  const formatPrice = (usdAmount: number, raw?: boolean) => {
    const rate = EXCHANGE_RATES[currency];
    const converted = Math.round(usdAmount * rate);

    if (raw) {
      return converted;
    }

    const symbol = CURRENCY_SYMBOLS[currency];
    
    if (currency === "BDT") {
      return `${symbol}${converted.toLocaleString("en-BD")}`;
    } else if (currency === "EUR") {
      return `${symbol}${converted.toLocaleString("de-DE")}`;
    } else if (currency === "GBP") {
      return `${symbol}${converted.toLocaleString("en-GB")}`;
    }
    return `${symbol}${converted.toLocaleString("en-US")}`;
  };

  const t = (key: string): string => {
    const translation = TRANSLATIONS[language]?.[key] || TRANSLATIONS["en"]?.[key];
    if (!translation) return key;
    return translation;
  };

  return (
    <LocalizationContext.Provider
      value={{
        language,
        setLanguage: handleSetLanguage,
        currency,
        setCurrency: handleSetCurrency,
        rates: EXCHANGE_RATES,
        formatPrice,
        currencySymbol: CURRENCY_SYMBOLS[currency],
        t,
      }}
    >
      {children}
    </LocalizationContext.Provider>
  );
};

export const useLocalization = () => {
  const context = useContext(LocalizationContext);
  if (context === undefined) {
    throw new Error("useLocalization must be used within a LocalizationProvider");
  }
  return context;
};
